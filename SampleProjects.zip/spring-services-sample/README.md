## Spring-services-sample microservice
=========================
Author: Kranthi Kiran
Created on: 17-Nov-16
Description: Sample project that provides RESTful APIs on products shopstore

#Features:


#Installing & local setup:


URL: 

References:
=======

