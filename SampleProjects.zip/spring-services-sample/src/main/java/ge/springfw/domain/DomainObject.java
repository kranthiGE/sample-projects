package ge.springfw.domain;

/**
 * Created by kranthi on 15-Jul-16
 */
public interface DomainObject {

    Integer getId();

    void setId(Integer id);
}
