package ge.springfw.services;

import ge.springfw.domain.Product;

/**
 * Created by kranthi on 15-Jul-16
 */
public interface ProductService extends CRUDService<Product> {

}
