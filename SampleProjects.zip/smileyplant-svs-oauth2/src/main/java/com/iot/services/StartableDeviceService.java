package com.iot.services;

public interface StartableDeviceService extends DeviceService {

	void start();
	
	void stop();
}
