package com.iot.services;

import com.iot.model.Device;

public interface DeviceService extends CRUDService<Device> { }
