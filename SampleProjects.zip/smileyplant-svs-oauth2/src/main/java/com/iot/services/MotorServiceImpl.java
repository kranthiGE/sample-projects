package com.iot.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.iot.model.Device;
import com.iot.repositories.DeviceRepository;

public class MotorServiceImpl implements StartableDeviceService  {

	private DeviceRepository repo;
	
	@Autowired
	public void setRepo(DeviceRepository repo) {
		this.repo = repo;
	}

	@Override
	public List<?> listAll() {
		List<Device> devices = new ArrayList<>();
		repo.findAll().forEach(devices::add);//find and add all the devices data into list
		return devices;
	}

	@Override
	public Device getById(Integer id) {
		return repo.findOne(id);
	}

	@Override
	public Device saveOrUpdate(Device domainObject) {
		return repo.save(domainObject);
	}

	@Override
	public void delete(Integer id) {
		repo.delete(id);
	}

	@Override
	public void start() {
		Device device = getByDeviceName("Water Pump");
		device.setState(1);
		saveOrUpdate(device);
	}

	@Override
	public void stop() {
		Device device = getByDeviceName("Water Pump");
		device.setState(0);
		saveOrUpdate(device);
	}

	@Override
	public Device getByDeviceName(String name) {
		return repo.getByName(name);
	}
	
}
