package com.iot.services;

import java.util.List;

/**
 * Created by kranthi on 10-Nov-16
 */
public interface CRUDService<T> {
    List<?> listAll();

    T getById(Integer id);
    
    T getByDeviceName(String name);

    T saveOrUpdate(T domainObject);

    void delete(Integer id);
}
