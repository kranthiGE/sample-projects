package com.iot.repositories;

import org.springframework.data.repository.CrudRepository;

import com.iot.model.Device;

public interface DeviceRepository extends CrudRepository<Device, Integer> {

	Device getByName(String name);
}
