package com.iot.bootstrap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.iot.model.Device;
import com.iot.services.StartableDeviceService;

@Component
public class JpaBootstrapData implements ApplicationListener<ContextRefreshedEvent> {

	private StartableDeviceService irrigationService;
	
	@Autowired
	public void setIrrigationService(StartableDeviceService irrigationService) {
		this.irrigationService = irrigationService;
	}

	@Override
	public void onApplicationEvent(ContextRefreshedEvent arg0) {
		loadDevices();
	}

	private void loadDevices(){
		//Motor device
		Device motor = new Device();
		motor.setName("Water Pump");
		motor.setId(101);
		motor.setState(0);
		irrigationService.saveOrUpdate(motor);
	}
}
