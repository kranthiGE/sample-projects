package com.iot.model;

/**
 * Created by kranthi on 10-Nov-16
 */
public interface DomainObject {

	Integer getId();
	
	void setId(Integer id);
}
