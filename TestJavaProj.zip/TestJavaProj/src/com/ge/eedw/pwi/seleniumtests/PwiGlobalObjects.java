package com.ge.eedw.pwi.seleniumtests;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class PwiGlobalObjects {
	
	private static Properties props = null;
	
	private static DesiredCapabilities capabilities;
	
	private static WebDriver driver;
	
	private static String fromEmail = null;
	
	private static String toEmail = null;
	
	private static String smtpServer = null;
	
	public static String getFromEmail() {
		return fromEmail;
	}

	public static String getToEmail() {
		return toEmail;
	}

	public static String getSmtpServer() {
		return smtpServer;
	}

	public static void InitGlobalObjects(String propsFilePath)
	{		
		props = new Properties();
		try{
			props.load(new FileInputStream(new File(propsFilePath)));//C:\\Users\\nggmnvq\\ActiveProcess\\ActiveProcessWorkSpace\\TestJavaProj\\src\\com\\ge\\eedw\\seleniumtest\\pagedata.properties	
			loadDriver();
			if(props.getProperty("fromemail") != null){
				fromEmail = props.getProperty("fromemail");
			}
			if(props.getProperty("smtpserver") != null){
				smtpServer = props.getProperty("smtpserver");
			}
			if(props.getProperty("toemail") != null){
				toEmail = props.getProperty("toemail");
			}
		}
		catch(IOException ex){
			System.err.println(ex);
		}
	}
	
	private static void loadDriver(){
		if(props != null && props.getProperty("driver").equals("IE")){
			capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			System.setProperty("webdriver.ie.driver", props.getProperty("driverPath"));
			driver = new InternetExplorerDriver(capabilities);
		}
	}
	
	public static Properties getPageData(){
		return props != null ? props : null;		
	}
	
	public static WebDriver getDriver(){
		loadDriver();
		return driver != null ? driver : null;
	}
	
	public static DesiredCapabilities getCapabilities(){
		return capabilities;
	}
	
	public static void closeQuitDriver(){
		driver.close();
		driver.quit();
	}
	
}
