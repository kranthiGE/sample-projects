package com.ge.eedw.pwi.seleniumtests;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.LoadableComponent;

import com.ge.eedw.availability.Application;
import com.ge.eedw.seleniumtest.GlobalObjects;

public class PwiSsoLoginPage extends LoadableComponent<PwiSsoLoginPage> {

	private WebDriver driver;
	
	private Application app;
	
	//@FindBy(how = How.ID_OR_NAME, using = "username")
	//@FindBy(how = How.XPATH, using = "//input[regexpi:contains(@name,'username')]")
	private WebElement username;
	
	//@FindBy(how = How.ID_OR_NAME, using = "password")
	//@FindBy(how = How.XPATH, using = "//input[regexpi:contains(@name,'password')]")
	private WebElement password;
		
	private void loadElements(){
		try{
			username = driver.findElement(By.name("username"));
		}
		catch(NoSuchElementException elEx){			
			username = driver.findElement(By.name("USERNAME"));
		}
		try{
			password = driver.findElement(By.name("password"));
		}
		catch(NoSuchElementException elEx){		
			password = driver.findElement(By.name("PASSWORD"));
		}
	}
	
	@Override
	protected void load(){
		driver.get(GlobalObjects.getPageData().getProperty("legalPage"));
	}
	
	@Override
	protected void isLoaded() {
		System.out.println("Current URL: " + driver.getCurrentUrl() );
	}
	
	public PwiSsoLoginPage(WebDriver driver){
		this.driver = driver;			
	}
	
	public PwiSsoLoginPage(WebDriver driver, Application app){
		this.driver = driver;		
		this.app = app;
		if(!driver.getTitle().contains("SSO Login - GE Infrastructure")){
			throw new IllegalStateException("This is not a SSO login page...");
		}
	}
	
	private PwiHomePageObject submit(){
		password.submit();
		return new PwiHomePageObject(driver, app);
	}
	
	public boolean submitLoginCredentials(String userName, String passWord, String title, String url){
		loadElements();
		username.clear();		
		if(username != null && password != null){
			username.sendKeys(userName);
			password.sendKeys(passWord);
		}		
		return submit().isPageLoaded(url);//.isTitleExist(title);
	}
	
}
