package com.ge.eedw.availability;

import java.util.ArrayList;
import java.util.List;

public class ApplicationData implements AppAvailState {

	private List<AppAvailObserver> observers = null;
	private List<AppAvailObserver> deleteObservers = null;
	private List<Application> emailList = null;
	
	
	public ApplicationData(){
		observers = new ArrayList<AppAvailObserver>();
		deleteObservers = new ArrayList<AppAvailObserver>();
		emailList = new ArrayList<Application>();
	}
	
	public void clearEmailList(){
		emailList.clear();
	}
	
	public List<Application> getEmailList(){
		return emailList;
	}
	
	public void addEmailList(Application o){
		emailList.add(o);
	}
	
	public void addApplObserver(AppAvailObserver o){
		observers.add(o);
	}
	
	public void regDeletes(AppAvailObserver o){
		deleteObservers.add(o);
	}
	
	public void removeApplObserver(AppAvailObserver o){
		int index = observers.indexOf(o);
		if(index != -1)			
			observers.remove(index);
	}
	
	public void notifyApplObserver(){
		for (AppAvailObserver edwObserver : observers) {
			edwObserver.checkApplLink();
		}
		for (AppAvailObserver edwObserver : deleteObservers) {
			removeApplObserver(edwObserver);
		}
	}
	
	public void runApplication(){
		notifyApplObserver();
	}
	
	public List<AppAvailObserver> getKeyList(){
		return observers;
	}
	
}
