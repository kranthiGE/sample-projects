package com.ge.eedw.availability;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Calendar;

import com.ge.eedw.availability.seleniumtest.TestGlobalObjects;

public class AppAvailbilityTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		//start the logger
		//AppAvaillogger.InitLogger();
		
		if(args == null || args.length < 2 ){
			
			System.err.println("No input file with list of applications");
			System.err.println("Usage: AppAvailbilityTest <Appls_URLs_File_path> <Webdriver_path_settings_file_path>");
			//AppAvaillogger.exitLogger();
			return;
		}
		AppAvailState state = new ApplicationData();
		ApplAvailability avail = null;
		boolean runContinuous = false;
		
		
		
		//Read input file arguments - applUrls.txt and pagedata.properties 
		readInputAppFile(args[0], avail, state);
		try{				
			do{
				//Initialize selenium driver & other global system properties
				TestGlobalObjects.InitGlobalObjects(args[1]);
				
				runContinuous = true;
				//force shutdown
				if(TestGlobalObjects.isForceShutdown()){
					runContinuous = false;
					System.out.println("Force shutdown");
				}
				else{
					//load the IE, Chrome selenium driver
					TestGlobalObjects.loadDriver();
					
					state.runApplication();
					
					//Send email with app status
					EmailUtils email = new EmailUtils(TestGlobalObjects.getToEmail(),TestGlobalObjects.getFromEmail(), TestGlobalObjects.getSmtpServer());
					email.sendEmail(state.getEmailList());
			
					//close & quit the selenium driver
					TestGlobalObjects.closeQuitDriver();
					System.out.println("An iteration completed at " + Calendar.getInstance().getTime());
					Thread.sleep(TestGlobalObjects.getSleepTime());
				}
			}while(runContinuous);
		}
		catch(Exception iEx){
			System.err.println(iEx);
		}
	}
	
	
	
	private static void readInputAppFile(String inputFile, ApplAvailability avail, AppAvailState data){
		BufferedReader inputStream = null;
		try {
		      inputStream = new BufferedReader(new FileReader(inputFile));
	    } catch (FileNotFoundException e) {
	      System.err.println("File does not exist" + e);
	    }
	    String line;
	    try{
		    while((line = inputStream.readLine()) != null){
		    	String[] dataLines = line.split("%,");
		    	if(dataLines.length > 0){
			    	Application app = new Application();
			    	app.setAppName(dataLines[0]);
			    	app.setAppUrl(dataLines[1]);
			    	app.setUserName(dataLines[2]);
			    	app.setPassword(dataLines[3]);
			    	app.setAppComponentText(dataLines[4]);
			    	avail = new ApplAvailability(data, app);
		    	}
		    	else
		    		System.err.println("Input file does not have application name and URL");
		    }
	    } catch (IOException ioe) {
		      System.err.println("File does not exist" + ioe);
		}
	}

}
