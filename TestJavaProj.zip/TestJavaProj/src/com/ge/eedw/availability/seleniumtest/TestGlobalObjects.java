package com.ge.eedw.availability.seleniumtest;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class TestGlobalObjects {
	
	private static Properties props = null;
	
	private static DesiredCapabilities capabilities;
	
	private static WebDriver driver;
	
	private static String fromEmail = null;
	
	private static String toEmail = null;
	
	private static String smtpServer = null;
	
	private static String shutdownLocation = null;
	
	private static long sleepTime;
	
	private static String driverPath = null;
	
	private static String driverType = null;
	
	public static String getDriverType() {
		return driverType;
	}

	public static String getDriverPath() {
		return driverPath;
	}

	public static String getFromEmail() {
		return fromEmail;
	}

	public static long getSleepTime() {
		return sleepTime;
	}

	public static String getToEmail() {
		return toEmail;
	}

	public static String getSmtpServer() {
		return smtpServer;
	}

	public static String getShutdownLocation() {
		return shutdownLocation;
	}
	
	public static void InitGlobalObjects(String propsFilePath)
	{		
		props = new Properties();
		try{
			props.load(new FileInputStream(new File(propsFilePath)));//C:\\Users\\nggmnvq\\ActiveProcess\\ActiveProcessWorkSpace\\TestJavaProj\\src\\com\\ge\\eedw\\seleniumtest\\pagedata.properties	
			if(props.getProperty("fromemail") != null){
				fromEmail = props.getProperty("fromemail");
			}
			if(props.getProperty("smtpserver") != null){
				smtpServer = props.getProperty("smtpserver");
			}
			if(props.getProperty("toemail") != null){
				toEmail = props.getProperty("toemail");
			}
			if(props.getProperty("shutdownLocation") != null)
				shutdownLocation = props.getProperty("shutdownLocation");
			else
				shutdownLocation = System.getProperty("user.dir");
			if(props.getProperty("sleeptime") != null)
				sleepTime = Long.valueOf(props.getProperty("sleeptime"));
			else
				sleepTime = 60000;
			if(props.getProperty("driver") != null){
				driverType = props.getProperty("driver");
			}		
			if(props.getProperty("driverPath") != null){
				driverPath = props.getProperty("driverPath");
			}	
		}
		catch(IOException ex){
			System.err.println(ex);
		}
	}
	
	public static void loadDriver() 
		throws AvailAppException
	{
		if(driverType != null && driverType.equalsIgnoreCase("ie")){
			capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			System.setProperty("webdriver.ie.driver", driverPath);
			driver = new InternetExplorerDriver(capabilities);
		}
		else if(driverType.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", driverPath);
			driver = new ChromeDriver();
		}
		else
			throw new AvailAppException("Invalid driver specified");
	}
	
	public static Properties getPageData(){
		return props != null ? props : null;		
	}
	
	public static WebDriver getDriver(){
		//loadDriver();
		return driver != null ? driver : null;
	}
	
	public static DesiredCapabilities getCapabilities(){
		return capabilities;
	}
	
	public static void closeQuitDriver(){
		if(driver != null){
			driver.quit();
		}
	}
	
	/**
	 * This method checks if shutdown file has been placed to forcedly shutdown the scheduler to check for data availability
	 * 
	 */
	public static boolean isForceShutdown(){
		String shutDownLoc = null;
		boolean isShutdown = false;
		File shutDownDir = null;
		File[] listOfFiles = null;
		String fileName = null;
		
		shutDownLoc = getShutdownLocation();
		shutDownDir = new File(shutDownLoc);
		listOfFiles = shutDownDir.listFiles();
		
		if (null != listOfFiles) {
			for (int i = 0; i < listOfFiles.length; i++) {
				fileName = listOfFiles[i].getName();
				if (fileName.equalsIgnoreCase("shutdown")) {
					isShutdown = true;
				}
			}
		}		
		return isShutdown;
	}
	
}
