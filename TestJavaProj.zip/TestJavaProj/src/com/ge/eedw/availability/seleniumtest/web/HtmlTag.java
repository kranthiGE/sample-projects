package com.ge.eedw.availability.seleniumtest.web;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;

public class HtmlTag extends WebComponent {

	public HtmlTag(WebDriver driver, String id, String isXPath){
		this.driver = driver;
		this.compName = "HtmlTag";
		this.idXPath = isXPath;
		this.id = id;
		//check if HtmlTag exists for the given id
		element = getWebElementById();
	}
	
	public HtmlTag(WebDriver driver, String id, String isXPath, String value){
		this.driver = driver;
		this.compName = "HtmlTag";
		this.idXPath = isXPath;
		this.id = id;
		//check if HtmlTag exists for the given id
		element = getWebElementById();
		this.value = value; 
	}
	
	public Map doAction(){
		//could be mouseover on div/span or get attribute values
		isAttributeExist = element.getAttribute("innerText").contains(value) ? true : false;	
		Map returnData = new HashMap();
		returnData.put("attributeAction", isAttributeExist);
		return returnData;
	}	
	
}

