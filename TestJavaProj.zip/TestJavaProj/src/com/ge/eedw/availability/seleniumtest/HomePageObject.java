package com.ge.eedw.availability.seleniumtest;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ge.eedw.availability.AppAvaillogger;
import com.ge.eedw.availability.Application;

public class HomePageObject extends LoadableComponent<HomePageObject>{

	private final WebDriver driver;
	
	Application app = null;
		
	public HomePageObject(WebDriver driver, Application app){
		this.driver = driver;
		this.app = app;
	}
	
	@Override
	protected void load(){
		driver.get(app.getAppUrl());
	}
	
	@Override
	protected void isLoaded() throws Error{
		AppAvaillogger.Log("Current URL loaded: " + driver.getCurrentUrl());
		//isTitleExist(app.getAppName());
	}
	
	public boolean isPageLoaded(String currentUrl){
		ExpectedCondition<Boolean> expectation = new
		ExpectedCondition<Boolean>() {
	        public Boolean apply(WebDriver driver) {
	          return ((JavascriptExecutor)driver).executeScript("return document.readyState").equals("complete");
	        }
	      };

	     Wait<WebDriver> wait = new WebDriverWait(driver,60);
	      try {
	              wait.until(expectation);
	      } catch(Throwable error) {
	              System.err.println("Timeout waiting for Page Load Request to complete.");
	              return false;
	      }
		return cleanUrl(driver.getCurrentUrl()).equals(currentUrl) ? true : false;
	}
	
	public boolean isTitleExist(String title){
		boolean isExist = false;
		if(driver.getTitle().contains(title)){
			isExist = true;
		}
		return isExist;
	}
	
	private String cleanUrl(String url){
		int idx = url.indexOf("jsessionid");
		if(idx > 0){
			url = url.substring(0, idx-1);
		}
		return url;
	}
}
