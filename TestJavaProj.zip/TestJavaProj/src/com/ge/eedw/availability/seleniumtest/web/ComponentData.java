package com.ge.eedw.availability.seleniumtest.web;

import java.util.HashMap;
import java.util.Map;

public class ComponentData {
	/*title:value=PLMR home page
	* button:id=btnAccept;xpath=//input[starts-with(@value,'Email Report')];value=Accept
	* textBox:id=txtBoxNumber;value=342224
	**/
	
	private Map<String, String> parsedData = new HashMap<String, String>();
	
	private WebComponent.componentType type = null;
		
	public WebComponent.componentType getType() {
		return type;
	}
				
	public ComponentData(String inputText){
		parseInput(inputText);
	}

	private void parseInput(String inputText){
		String[] dataLines = inputText.split(":");
		if(dataLines != null && dataLines.length > 0){
			this.type = WebComponent.componentType.getComponentType(dataLines[0]);
			String[] temp = dataLines[1].split(";");
			for(String s : temp){
				String[] keyVal = s.split("=");
				if(keyVal.length > 0)
					parsedData.put(WebComponent.componentAttributes.getComponentAttribute(keyVal[0]), keyVal[1]);
			}
		}
	}

	public Map<String, String> getParsedData() {
		return parsedData;
	}
}
