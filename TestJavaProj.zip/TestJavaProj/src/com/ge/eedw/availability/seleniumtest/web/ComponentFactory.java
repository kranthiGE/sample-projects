package com.ge.eedw.availability.seleniumtest.web;

import java.util.Map;

import org.openqa.selenium.WebDriver;

public class ComponentFactory {
	
	public static boolean isAttributeAction = false;
	
	private static WebComponent component = null;
	
	public static WebComponent createComponent(WebDriver driver, String input) throws WebElementException{		
		
		ComponentData data = new ComponentData(input);
		switch(data.getType()){
		case button:
			component = new Button(driver, data.getParsedData().get(WebComponent.componentAttributes.id), data.getParsedData().get(WebComponent.componentAttributes.xpath.name()));
			break;
		case textbox:
			break;
		case htmltag:
			component = new HtmlTag(driver, data.getParsedData().get(WebComponent.componentAttributes.id), data.getParsedData().get(WebComponent.componentAttributes.xpath.name()));
			break;
		case title:
			isAttributeAction = true;
			component = new HtmlTag(driver, data.getParsedData().get(WebComponent.componentAttributes.id), data.getParsedData().get(WebComponent.componentAttributes.xpath.name()), data.getParsedData().get(WebComponent.componentAttributes.value.name()));
			break;
		default:
				break;
		}
		if(component.element == null)
			component = null;
		return component;
	}
	
	public static Map createAndPerformComponent(WebDriver driver, String input) throws WebElementException{
		return createComponent(driver, input).doAction();
	}
	
	
	
	public static boolean getAttributeExist(){
		return component.isAttributeExist;
	}
	
}
