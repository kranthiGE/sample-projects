package com.ge.eedw.availability.seleniumtest;

public class AvailAppException extends Exception {

	String errorCode;
	String errorMsg;
	/**
	 * 
	 */
	private static final long serialVersionUID = 8908137924297590891L;

	public AvailAppException(){
		super();
	}
	
	public AvailAppException(String msg){
		super(msg);
	}
	
	public AvailAppException(String code, String msg){
		this.errorCode = code;
		this.errorMsg = msg;
	}
	
	/**
	 * @return the errorMsg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * @param errorMsg the errorMsg to set
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
}
