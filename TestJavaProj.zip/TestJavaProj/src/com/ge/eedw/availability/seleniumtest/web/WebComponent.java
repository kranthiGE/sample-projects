package com.ge.eedw.availability.seleniumtest.web;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

public abstract class WebComponent {

	// enum for selecting the component type
	public enum componentType{		
		button(1),
		textbox(2),
		label(3),
		menu(4),
		combo(5),
		listbox(6),
		htmltag(7),
		title(8);
		int keyOrdinal = 0;
		
		componentType(int ord) {
	        this.keyOrdinal = ord;
	    }
		
	    public static componentType byOrdinal(int ord) {
	        for (componentType key : componentType.values()) {
	            if (key.keyOrdinal == ord) {
	                return key;
	            } 
	        }
	        return null;
	    }  
	    
	    public static componentType getComponentType(String compName){
	    	for (componentType key : componentType.values()) {
	    		if(key.name().equals(compName)){
	    			return key;
	    		}	    			
	    	}
	    	return null;
	    }
	}
	
	public enum componentAttributes{		
		id,
		xpath,
		name,
		value;
		
	    public static String getComponentAttribute(String compName){
	    	for (componentAttributes key : componentAttributes.values()) {
	    		if(key.name().equalsIgnoreCase(compName)){
	    			return key.name();
	    		}	    			
	    	}
	    	return null;
	    }
	}
	
	WebElement element;
	protected WebDriver driver;
	String compName;
	String id;
	String value;
	String text;
	String idXPath;
	
	boolean isAttributeExist = false;
	
	protected WebElement getWebElementById(){
		WebElement webElement1 = null;		
		if(idXPath != null){
			waitElementExists(1, idXPath);
			webElement1 = driver.findElement(By.xpath(idXPath));
		}
		else if(id != null){
			waitElementExists(0, id);
			webElement1 = driver.findElement(By.id(id));
		}
		return webElement1;
	}
	
	private void waitElementExists(final int ByType, final String value){
		WebDriverWait myWait = new WebDriverWait(driver, 80);
	    ExpectedCondition<Boolean> conditionToCheck = new ExpectedCondition<Boolean>() {
	        @Override
	        public Boolean apply(WebDriver input) {
	        	if(ByType == 0)
	        		return (input.findElements(By.id(value)).size() > 0);	        	
	        	else
	        		return (input.findElements(By.xpath(value)).size() > 0);
	        }
	    };
	    myWait.until(conditionToCheck);
	}
	
	protected String getInnerText(){
		return element != null ? element.getAttribute("innerText") : null;
	}
	
	public String getCompName(){
		return compName;
	}
	
	public String getId(){
		return id ;
	}
		
	protected abstract Map doAction();
	
}
