package com.ge.eedw.availability.seleniumtest.web;

public class WebElementException extends Exception {
	/**
	 * Throws WebElementException without parameter
	 * 
	 * @param
	 */
	public WebElementException() {
		super();
	}

	public WebElementException(String msg, Throwable cause) {
		super(msg, cause);
	}

	public WebElementException(Throwable cause) {
		super(cause);
	}

	/**
	 * Throws WebElementException by the parameter message
	 * 
	 * @param message
	 */
	public WebElementException(String msg) {

		super(msg);

	}
}
