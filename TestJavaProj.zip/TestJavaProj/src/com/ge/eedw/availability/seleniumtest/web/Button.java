package com.ge.eedw.availability.seleniumtest.web;

import java.util.Map;

import org.openqa.selenium.WebDriver;

public class Button extends WebComponent{

	public Button(WebDriver driver, String id, String isXPath) {
		this.driver = driver;
		this.compName = "Button";		
		this.idXPath = isXPath;		
		this.id = id;
		//check if button exists for the given id
		element = getWebElementById();
	}
	
	protected Map doAction(){
		element.click();
		return null;
	}	
	
}
