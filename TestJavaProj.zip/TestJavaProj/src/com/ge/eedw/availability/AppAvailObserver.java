package com.ge.eedw.availability;

public interface AppAvailObserver {
	//check if application is running
	void checkApplLink();
}
