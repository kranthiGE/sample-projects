package com.ge.eedw.availability;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class AppAvaillogger {

private static PrintStream mLogStream = null;
	
	// Format to print the time in log file
	private static final DateFormat LOG_DATE_FORMAT=new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	
	private static String UserHome = System.getProperty("user.home");
	
	private static long mLastEmailSendTime = 0;
	
	private static final long MS_PER_DAY = 24*60*60*1000;
	
	public static void InitLogger()
	{
		try{
			File edwDataFile = new File(UserHome + File.separator + "AppAvailbility" + File.separator + "appData.log");
					
			// Open the file in append mode
			mLogStream = new PrintStream(new FileOutputStream(edwDataFile, true));
			
			Calendar cal = Calendar.getInstance();
			
			mLastEmailSendTime =  System.currentTimeMillis() - cal.getTimeInMillis();
			
		}
		catch (FileNotFoundException e)
		{
			mLogStream = null;
		}
	}
	
	public static void Log(String message)
	{			
		StringBuilder write_line = new StringBuilder();
		write_line.append(LOG_DATE_FORMAT.format(new Date())).append(":  ").append(message);
		
		mLogStream.println(write_line.toString());
		mLogStream.flush();
		
		long cur_time = System.currentTimeMillis();
		//check the last email send time is greater than 24 hours and send a status email 
		if((cur_time - mLastEmailSendTime) >= MS_PER_DAY)
		{
			//send email with current status
		}
	}
	
	public static void exitLogger(){
		mLogStream.close();
		mLogStream = null;
	}
}
