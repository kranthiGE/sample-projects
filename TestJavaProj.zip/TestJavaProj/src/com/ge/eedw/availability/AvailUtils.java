package com.ge.eedw.availability;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.Message.RecipientType;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.sound.midi.SysexMessage;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.ge.eedw.availability.seleniumtest.SsoLoginPage;
import com.ge.eedw.availability.seleniumtest.TestGlobalObjects;
import com.ge.eedw.availability.seleniumtest.web.ComponentFactory;
import com.ge.eedw.availability.seleniumtest.web.HtmlTag;
import com.ge.eedw.availability.seleniumtest.web.WebComponent;
import com.ge.eedw.availability.seleniumtest.web.WebElementException;

public class AvailUtils {

	public AvailUtils(){
		
	}
	
	public static boolean runUrl(Application app){
		boolean isRunning = false;
		HttpURLConnection con = null;
		try{
			final URL url = new URL(app.getAppUrl());
			con = (HttpURLConnection)url.openConnection();
			if(app.getAppUrl().contains("wsdl"))
				con.setRequestMethod("GET");
			else
				con.setRequestMethod("HEAD");
			int responseCode = con.getResponseCode();
			if(responseCode == 200 || responseCode == 302){
				isRunning = true;
			}
		}
		catch(MalformedURLException malEx){
			System.err.println(malEx);
		}
		catch(IOException ioEx){
			System.err.println(ioEx);
		}
		finally{
			if(con != null)
				con.disconnect();
		}
		return isRunning;
	}
	
	public static boolean runSeleniumTest(Application app){
		boolean statusFlag =false; 
		if(app.getAppUrl().contains("www") || app.getAppUrl().contains("wsdl"))
			return true;		
		WebDriver driver = TestGlobalObjects.getDriver();
		if(driver != null){
			driver.get(app.getAppUrl());
			try{
				SsoLoginPage login = PageFactory.initElements(driver, SsoLoginPage.class);
				login.submitLoginCredentials(app.getUserName(), app.getPassword(), app.getAppName(), app.getAppUrl());
			}
			catch(NoSuchElementException elex){
				System.err.println(elex);
			}
				 
			try{
				HashMap returnData = (HashMap)ComponentFactory.createAndPerformComponent(driver, app.getAppComponentText());
				if(ComponentFactory.isAttributeAction)
					statusFlag = Boolean.parseBoolean(returnData.get("attributeAction").toString());
				else
					statusFlag = true;
			}catch(WebElementException webEx){
				System.err.println(webEx);
				statusFlag = false;
			}
			catch(Exception ex){
				System.err.println(ex);
				statusFlag = false;
			}
			finally{
				if(driver != null){
					driver.close();
					driver.quit();
				}
			}
		}		
		return statusFlag;
	}
	
	
}
