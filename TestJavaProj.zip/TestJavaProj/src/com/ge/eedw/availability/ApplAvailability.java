package com.ge.eedw.availability;

public class ApplAvailability implements AppAvailObserver, AppAvailDisplay {
	
	private boolean isAppRunning = false;
	
	Application app = null;
	
	AppAvailState state = null;

	public ApplAvailability(AppAvailState state, Application app){
		this.app = app;
		this.state = state;
		state.addApplObserver(this);
		state.addEmailList(this.app);
	}
	
	public void checkApplLink(){		
		//check if app is running and flag it
		if(AvailUtils.runUrl(app)){
			isAppRunning = AvailUtils.runSeleniumTest(app);
			app.setAppRunning(isAppRunning);
		}
		displayResult();
	}
	
	public void displayResult(){
		if(app.isAppRunning()){
			System.out.println("Appl running successfully");
			/*if(app.isEmailRequiredNextTime()){
				EmailUtils email = new EmailUtils("kranthi.kiran@ge.com","ae@ge.com", "bsemsx01.ae.ge.com");
				email.sendEmail("Application: " + app.getAppName() + " was up ", "Application: " + app.getAppName() + " was up & running with URL: "+ app.getAppUrl(), EmailUtils.emailType.availability);
			}
			app.setEmailRequiredNextTime(false);*/
			
		}
		else{
			System.out.println("Appl not running");
			/*app.setEmailRequiredNextTime(true);
			EmailUtils email = new EmailUtils("kranthi.kiran@ge.com","ae@ge.com", "bsemsx01.ae.ge.com");
			email.sendEmail("Application: " + app.getAppName() + " was down ", "Application: " + app.getAppName() + " not running and was down with URL: "+ app.getAppUrl(), EmailUtils.emailType.availability);*/
		}
		
		
	}
	
}
