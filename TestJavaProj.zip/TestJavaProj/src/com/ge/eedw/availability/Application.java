package com.ge.eedw.availability;

import com.ge.passwordutils.DecryptPassword;

public class Application {

	private String appName = null;
	
	private String appUrl = null;
	
	private String userName = null;
	
	private String password = null;
	
	private boolean isAppRunning = false;
	
	private boolean isEmailRequiredNextTime = false; 
	
	private String appComponentText = null;
	
	private String emailMessage = null;
	
	public String getEmailMessage() {
		return emailMessage;
	}

	public void setEmailMessage(String emailMessage) {
		this.emailMessage = emailMessage;
	}

	public String getAppComponentText() {
		return appComponentText;
	}

	public void setAppComponentText(String appComponentText) {
		this.appComponentText = appComponentText;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getAppUrl() {
		return appUrl;
	}

	public void setAppUrl(String appUrl) {
		this.appUrl = appUrl;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return getEncryptedPassword(password);
	}
	
	public String getEncryptedPassword(String pwd){
		return DecryptPassword.decrypt("y86Ys3NXtSDZMbrxl8QCpLVr1eVGEy+1", pwd);
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isAppRunning() {
		return isAppRunning;
	}

	public void setAppRunning(boolean isAppRunning) {
		this.isAppRunning = isAppRunning;
	}

	public boolean isEmailRequiredNextTime() {
		return isEmailRequiredNextTime;
	}

	public void setEmailRequiredNextTime(boolean isEmailRequiredNextTime) {
		this.isEmailRequiredNextTime = isEmailRequiredNextTime;
	}
	
}
