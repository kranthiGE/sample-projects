package com.ge.eedw.availability;

import java.util.List;

public interface AppAvailState {
	void addApplObserver(AppAvailObserver o);
	void addEmailList(Application o);
	void removeApplObserver(AppAvailObserver o);
	void notifyApplObserver();
	void regDeletes(AppAvailObserver o);
	void runApplication();
	void clearEmailList();
	List<Application> getEmailList();
}
