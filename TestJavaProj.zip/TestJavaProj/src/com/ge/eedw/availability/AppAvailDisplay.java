package com.ge.eedw.availability;

public interface AppAvailDisplay {
	void displayResult();
}
