package com.ge.eedw.availability;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.Message.RecipientType;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailUtils {

	String strBody = null, fromAdd = null;
	
	private String toAdd = null;
	
	String host = null;
	
	public List<String> getEmailIds(){
		String[] toArr = toAdd.split(",");
		return new ArrayList<String>(Arrays.asList(toArr));
	}
	
	final static String strMsgFirst = "<head>" +
			"<title></title>" +
			"<STYLE type=text/css>" +
			".blackBold{COLOR: black;FONT-FAMILY: Arial, Helvetica, san-serif;;FONT-SIZE: 9pt;FONT-WEIGHT: bold;LINE-HEIGHT: 9pt}" +
			".bluebigbold{COLOR: #213C5A;FONT-FAMILY: Arial, Helvetica, san-serif;;FONT-SIZE: 12pt;FONT-WEIGHT: bold;LINE-HEIGHT: 10pt}" +
			".ajaxBlueBold{COLOR: #84AEDE;FONT-FAMILY: Arial, Helvetica, san-serif;FONT-SIZE: 10pt;FONT-WEIGHT: bold;LINE-HEIGHT: 11pt}" +
			".ajaxGreenBold{ COLOR: #00A263;FONT-FAMILY: Arial, Helvetica, san-serif; FONT-SIZE: 8pt; FONT-WEIGHT: bold;  LINE-HEIGHT: 8pt}" +
			".redBold{    COLOR: #ff0000;    FONT-FAMILY: Arial, Helvetica, san-serif;    FONT-SIZE: 8pt;    FONT-WEIGHT: bold;    LINE-HEIGHT: 8pt}" +
			"</STYLE>" +
			"</head><body>" +
			"<table cellpadding='4' cellspacing='0' border='0' width='65%'>" +
			"<tr><td><font class='bluebigbold'>GE EEDW - Application(s) list & availability </font></td></tr><tr>" +
			"<td style='BORDER-TOP: #213c5a 1px solid; BORDER-RIGHT: #213c5a 1px solid; BORDER-LEFT: #213c5a 1px solid; BORDER-BOTTOM: #213c5a 1px solid'>" +
			"<table cellpadding='0' cellspacing='0' border='1' width='100%'>" +
			"<tr bgcolor='#E5E4E2'><td class='ajaxBlueBold'>Name</td><td class='ajaxBlueBold'>URL</td><td class='ajaxBlueBold'>Status</td></tr>";
	
	final static String strMsgLast = "<tr><td>&nbsp;</td></tr>" +
			"</table></td></tr></table>" +
			"&nbsp;" +
			"<font class='blackBold'>Note:  *** This is a system generated email from EEDW team, do not reply *** " +
			"<li>" +
			"<ul>Application checks the availability as per the configuration settings provided</ul>" +
			"<ul>Tool considers an application as down, also if homepage takes more than 60 sec to open</ul>" +
			"</ul>" +
			"</li>" +
			"</font></body></html>";
			
	public EmailUtils(String toAdd, String fromAdd, String host){
		this.toAdd = toAdd;
		this.host = host;
		this.fromAdd = fromAdd;
	}
	
	// enum for selecting the email type
	public enum emailType{
		availability
	}
	
	private String createHtmlEmailMsg(String msg){
		strBody = "" + msg;
		return strBody;
	}
	
	public void sendEmail(List<Application> emailData){
		StringBuilder subject = new StringBuilder();
		StringBuilder message = new StringBuilder();
		subject.append("Application(s) availability status report");
		message.append(strMsgFirst);
		for(Application app : emailData){
			message.append("<tr><td>").append(app.getAppName()).append("</td><td><a href='").append(app.getAppUrl()).append("'>").append(app.getAppUrl());
			if(app.isAppRunning())
				message.append("</a></td><td class='ajaxGreenBold'>Up</td></tr>");
			else
				message.append("</a></td><td class='redBold'>Down</td></tr>");
		}
		message.append(strMsgLast);
		sendEmail(subject.toString(), message.toString(), EmailUtils.emailType.availability);
	}
	
	public void sendEmail(String subject, String message, EmailUtils.emailType type){
		if(type.equals(EmailUtils.emailType.availability)){
			try
			{
				Properties props = new Properties();
				props.put("mail.smtp.host", host);
				Session session = Session.getInstance(props);
				InternetAddress fromAddress = null;
				InternetAddress toAddress = null;
				
				Message msg = new MimeMessage(session);
				fromAddress = new InternetAddress(fromAdd);
				for (String toEmailId : getEmailIds()) {
					toAddress = new InternetAddress(toEmailId);
					msg.setFrom(fromAddress);
					msg.setRecipient(RecipientType.TO, toAddress);
			        msg.setSubject(subject);
			        msg.setContent(createHtmlEmailMsg(message), "text/html");		            
			        msg.setSentDate(new Date());            
			        Transport.send(msg);
				}
			}
			catch(MessagingException ex)
			{
				
			}
			catch(Exception ex)
			{
				
			}
		}
	}
}
