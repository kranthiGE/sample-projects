package com.ge.eedw.seleniumtest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.LoadableComponent;

public class HomePage extends LoadableComponent<HomePage>{
	
	private final WebDriver driver;
	
	@FindBy(how = How.XPATH, using = "//div/div[text() = 'PLM Search']")
	private WebElement selectPLMSearch;
	
	@FindBy(how = How.XPATH, using = "//div/span[text() = 'Cost Change Summary']")
	private WebElement selectCSR;
	
	public HomePage(WebDriver driver){
		this.driver = driver;
	}
	
	@Override
	protected void load(){
		driver.get(GlobalObjects.getPageData().getProperty("homePage"));
	}
	
	@Override
	protected void isLoaded() throws Error{
		System.out.println("Current URL: " + driver.getCurrentUrl() );
	}
	
	public void selectCostChangeSummaryReport(){
		Actions mouseOver = (new Actions(driver)).moveToElement(selectPLMSearch);
		mouseOver.perform();
		selectCSR.click();
	}
}
