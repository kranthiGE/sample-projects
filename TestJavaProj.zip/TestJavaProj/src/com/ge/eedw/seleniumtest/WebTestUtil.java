package com.ge.eedw.seleniumtest;

import java.io.File;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.Augmenter;

public class WebTestUtil {
	
	//capture screen shot and save in the given path
	public static File captureScreenShot(WebDriver driver){
		File screenshot = null;
		try{			
			screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			System.out.println(screenshot.getAbsolutePath());
		}
		catch(Exception ex){}
		finally{
			driver.close();			
		}
		return screenshot;
	}
}
