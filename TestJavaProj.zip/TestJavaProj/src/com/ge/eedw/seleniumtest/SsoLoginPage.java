package com.ge.eedw.seleniumtest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class SsoLoginPage {

	private final WebDriver driver;
	
	@FindBy(how = How.ID_OR_NAME, using = "USERNAME")
	private WebElement username;
	
	@FindBy(how = How.ID_OR_NAME, using = "PASSWORD")
	private WebElement password;
	
	public SsoLoginPage(WebDriver driver){
		this.driver = driver;
		
		if(!driver.getTitle().contains("SSO Login - GE Infrastructure")){
			throw new IllegalStateException("This is not a SSO login page...");
		}
	}
	
	private PlmrLegalPage submit(){
		password.submit();
		return new PlmrLegalPage(driver);
	}
	
	public PlmrLegalPage submitLoginCredentials(String userName, String passWord){
		if(userName != null && passWord != null){
			username.sendKeys(username.getText() != null ? username.getText() : userName);
			password.sendKeys(passWord);
			return submit();
		}
		else
			return null;
	}
	
}
