package com.ge.eedw.seleniumtest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.Wait;

import com.sun.jna.Function;

public class CostChangeSumReport extends LoadableComponent<HomePage>{
	
	private final WebDriver driver;
	
	@FindBy(how = How.XPATH, using = "//input[starts-with(@value,'Email Report')]")
	private WebElement btnSubmitEmailRpt;
	
	@FindBy(id="costchngSearch:contractName")
	private WebElement txtAreaCost;
	
	public CostChangeSumReport(WebDriver driver){
		this.driver = driver;
	}
	
	@Override
	protected void load(){
		driver.get(GlobalObjects.getPageData().getProperty("CCSReport"));
	}
	
	@Override
	protected void isLoaded() throws Error{
		System.out.println("Current URL: " + driver.getCurrentUrl() );
	}
	
	private void submitActualContractNo(){
		txtAreaCost.sendKeys("723427");
	}
	
	private void submitWildCardContractNo(){
		
	}
	
	private void waitAndClickOk(){
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(60, TimeUnit.SECONDS).pollingEvery(5, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);
		Alert alert = wait.until(ExpectedConditions.alertIsPresent());
		if(alert.getText().contains("report generation is in process")){
			alert.accept();
		}
	}
		
	public void submitEmailReport(){
		submitActualContractNo();
		btnSubmitEmailRpt.click();
		//WebTestUtil.captureScreenShot(driver);
		waitAndClickOk();
	}
	
	
}
