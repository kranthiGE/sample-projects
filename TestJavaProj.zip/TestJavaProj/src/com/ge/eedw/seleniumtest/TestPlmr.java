package com.ge.eedw.seleniumtest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.PageFactory;

public class TestPlmr {

	public static void main(String[] args){
		testPageObjects();
	
	}
	
	public static void testbasic(){
		WebElement acceptBtn = null;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		System.setProperty("webdriver.ie.driver", "C:\\Users\\nggmnvq\\Softwares\\Selenium\\IEDriverServer.exe");
		
		WebDriver driver = new InternetExplorerDriver(capabilities);
		
		driver.get("http://dev.energy.ge.com/plmrptg/pages/legalPage.jsf");
		
		WebElement pwd = driver.findElement(By.name("PASSWORD"));
		
		WebElement webElement1 = driver.findElement(By.xpath("//input[starts-with(@value,'Log')]"));
		System.out.println(webElement1.getAttribute("value"));
		//enter the sso password
		//pwd.sendKeys("");
		//pwd.submit(); 
		
		
		/*List<WebElement> elements = driver.findElements(By.tagName("input"));
		for (WebElement webElement : elements) {
			 if(webElement.getAttribute("value").equals("Accept")){
				 acceptBtn = webElement;
				 acceptBtn.click();
				 break;
			 }
		}	*/	
		driver.close();//.quit();
		driver.quit();
	}
	
	public static void testPageObjects(){
		try{
			GlobalObjects.InitGlobalObjects();
			WebDriver driver = GlobalObjects.getDriver();
			if(driver != null){
				driver.get(GlobalObjects.getPageData().getProperty("legalPage"));
				
				SsoLoginPage login = PageFactory.initElements(driver, SsoLoginPage.class);
				
				PlmrLegalPage legalPage = login.submitLoginCredentials(GlobalObjects.getPageData().getProperty("uid"), GlobalObjects.getPageData().getProperty("pwd"));
				
				PageFactory.initElements(driver, legalPage);
				
				legalPage.acceptNotice();
				
				HomePage home = PageFactory.initElements(driver, HomePage.class);		
				
				home.selectCostChangeSummaryReport();
				
				CostChangeSumReport ccsRpt =  PageFactory.initElements(driver, CostChangeSumReport.class);
				
				ccsRpt.submitEmailReport();
			}
		}
		catch(Exception ex){System.err.println(ex);}
		finally{
			GlobalObjects.closeQuitDriver();	
		}		
	}
}
