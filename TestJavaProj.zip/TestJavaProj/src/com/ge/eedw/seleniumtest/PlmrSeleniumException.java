package com.ge.eedw.seleniumtest;

public class PlmrSeleniumException  extends Exception {
	
	public PlmrSeleniumException() {
		super();
	}

	public PlmrSeleniumException(String msg, Throwable cause) {
		super(msg, cause);
	}

	public PlmrSeleniumException(Throwable cause) {
		super(cause);
	}

	
	public PlmrSeleniumException(String msg) {

		super(msg);

	}
}
