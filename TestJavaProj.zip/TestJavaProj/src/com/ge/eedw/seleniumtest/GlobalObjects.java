package com.ge.eedw.seleniumtest;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class GlobalObjects {
	
	private static Properties props = null;
	
	private static DesiredCapabilities capabilities;
	
	private static WebDriver driver;
	
	public static void InitGlobalObjects()
	{		
		props = new Properties();
		try{
			props.load(new FileInputStream(new File("C:\\Users\\nggmnvq\\ActiveProcess\\ActiveProcessWorkSpace\\TestJavaProj\\src\\com\\ge\\eedw\\seleniumtest\\pagedata.properties")));	
			if(props.getProperty("driver").equals("IE")){
				capabilities = DesiredCapabilities.internetExplorer();
				capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
				System.setProperty("webdriver.ie.driver", props.getProperty("driverPath"));
				driver = new InternetExplorerDriver(capabilities);
			}
		}
		catch(IOException ex){
			System.err.println(ex);
		}
	}
	
	public static Properties getPageData(){
		return props != null ? props : null;		
	}
	
	public static WebDriver getDriver(){
		return driver != null ? driver : null;
	}
	
	public static DesiredCapabilities getCapabilities(){
		return capabilities;
	}
	
	public static void closeQuitDriver(){
		driver.close();
		driver.quit();
	}
	
}
