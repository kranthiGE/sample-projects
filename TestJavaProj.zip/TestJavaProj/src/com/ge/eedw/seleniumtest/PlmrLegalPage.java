package com.ge.eedw.seleniumtest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.LoadableComponent;

public class PlmrLegalPage extends LoadableComponent<PlmrLegalPage>{

	private final WebDriver driver;
	
	@FindBy(how = How.XPATH, using = "//input[starts-with(@value,'Accept')]")
	private WebElement btnAccept;
		
	@Override
	protected void load(){
		driver.get(GlobalObjects.getPageData().getProperty("legalPage"));
	}
	
	@Override
	protected void isLoaded() throws Error{
		System.out.println("Current URL: " + driver.getCurrentUrl() );
	}
	
	public PlmrLegalPage(WebDriver driver){
		this.driver = driver;
	}

	public void acceptNotice(){
		btnAccept.click();		
	}
	
}
