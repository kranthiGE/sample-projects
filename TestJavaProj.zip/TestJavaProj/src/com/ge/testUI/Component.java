package com.ge.testUI;

public class Component {
	public String getName(){return "CompName";}
}
