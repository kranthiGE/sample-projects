package com.ge.testUI;

public class Label extends Component {
 public Label(){}
}
