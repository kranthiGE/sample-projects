package com.ge.testUI;

public class Window extends Component {
	
	Component c;
	
	public Window(Component c){
		this.c = c;		
	}
	
	public void test(){
		
		
	}
}
