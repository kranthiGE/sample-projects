package com.ge.testUI;

public class TextField extends Component {
 public TextField(){}
}
