package com.ge.testUI;

public class Button extends Component {
 public Button(){}
 
 public void getButtonAttributes(){}
}
