package com.ge.rmi;

import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class Server extends UnicastRemoteObject implements RunProgram {

	public Server() throws RemoteException{
		
	}
	
	public String sayHello(){
		return "Hi..";
	}
	
	public static void main(String[] args) {
		try{
			String hostname = InetAddress.getLocalHost().getHostName();
			System.out.println("Searching for global address of " + hostname);

			String globalIp4address = null;
			String globalIp6address = null;

			InetAddress [] inetAddresses = InetAddress.getAllByName(hostname);
			for (InetAddress inetAddress : inetAddresses) {
			    System.out.println("hostname is " + inetAddress.getHostName());
			    System.out.println("address  is " + inetAddress.getHostAddress());
			    boolean isSiteLocalAddress = inetAddress.isSiteLocalAddress();
			    boolean isLinkLocalAddress = inetAddress.isLinkLocalAddress();
			    boolean isLoopbackAddress = inetAddress.isLoopbackAddress();
			    boolean isReachable = inetAddress.isReachable(10000);
			    System.out.println("isSiteLocalAddress  = " + isSiteLocalAddress);
			    System.out.println("isLinkLocalAddress  = " + isLinkLocalAddress);
			    System.out.println("isLoopbackAddress   = " + isLoopbackAddress);
			    System.out.println("isReachable         = " + isReachable);
			    if (isReachable && !isSiteLocalAddress && !isLinkLocalAddress && !isLoopbackAddress) {
			        if (inetAddress instanceof Inet4Address) {
			            globalIp4address = inetAddress.getHostAddress();
			        }
			        if (inetAddress instanceof Inet6Address) {
			            globalIp6address = inetAddress.getHostAddress();
			        }
			    }
			}
			
			
			System.setProperty("java.rmi.server.hostname", "BNG1307007782B");
			System.out.println( System.getProperty("java.rmi.server.hostname"));
			Server server = new Server();
			//export server object to receiving RMI on anonymous TCP port and returns the stub for the remote object to pass to clients 
			//RunProgram stub = (RunProgram)UnicastRemoteObject.exportObject(server, 1);
			
			//Bind the server obj to registry
			Registry reg = LocateRegistry.getRegistry();
			reg.bind("RunProgram", server);
			System.out.println("Server ready ....");
		}	
		catch(RemoteException rmEx){
			System.err.println(rmEx);
		}	
		catch(AlreadyBoundException alEx){
			System.err.println(alEx);
		}
		catch(Exception e){
			System.err.println(e);
		}
	}
}
