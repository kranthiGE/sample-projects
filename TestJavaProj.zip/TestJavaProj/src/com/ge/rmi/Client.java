package com.ge.rmi;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Client {

	public static void main(String[] args) {
		String host = (args.length < 1) ? null : args[0];
		try{
			Registry reg = LocateRegistry.getRegistry(host);
			RunProgram stub = (RunProgram)reg.lookup("RunProgram");
			System.out.println(stub.sayHello());
		}catch(Exception e){
			System.err.println(e);			
		}
	}

}
