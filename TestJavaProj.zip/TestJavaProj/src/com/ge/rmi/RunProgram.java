package com.ge.rmi;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface RunProgram extends Remote{

	String sayHello() throws RemoteException;
}
