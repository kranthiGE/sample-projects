package com.ge.plm.testsuite;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.LoadableComponent;

public class PlmHome extends LoadableComponent<PlmHome>{
	
	private final WebDriver driver;
	
	@FindBy(how = How.CSS, using = "input.buttonTxt")
	private WebElement selectMenu;
	
	@FindBy(how = How.XPATH, using = "//div[@id='divToolbar']/div/table/tbody/tr/td[2]")
	private WebElement selectCreateIssue;
	
	@FindBy(how = How.XPATH, using = "//div[@id='divToolbar']/div/table/tbody/tr/td[2]/img[2]")
	private WebElement createIssueBtn;
	
	public PlmHome(WebDriver driver){
		this.driver = driver;
	}
	
	@Override
	protected void load(){
		driver.get(GlobalObjects.getPageData().getProperty("baseurl") + GlobalObjects.getPageData().getProperty("menupage"));
	}
	
	@Override
	protected void isLoaded() throws Error{
		System.out.println("Current URL: " + driver.getCurrentUrl() );
	}
	
	public void selectMenuCreateIssue(){
		selectMenu.click();
		selectCreateIssue.click();
		createIssueBtn.click();
	}
}
