package com.ge.plm.testsuite;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import com.ge.passwordutils.DecryptPassword;

public class TestCreateIssue {

	public static void main(String[] args){
		createIssue(args[0]);	
	}
	
	public static void createIssue(String filePath){
		try{
			GlobalObjects.InitGlobalObjects(filePath);
			WebDriver driver = GlobalObjects.getDriver();
			if(driver != null){
				//run base URL
				driver.get(GlobalObjects.getPageData().getProperty("baseurl"));
				//authenticate in sso page
				SsoLoginPage login = PageFactory.initElements(driver, SsoLoginPage.class);
				//decrypt password with the key
				String pwd = GlobalObjects.getPageData().getProperty("pwd") != null ? DecryptPassword.decrypt(GlobalObjects.getPageData().getProperty("key"), GlobalObjects.getPageData().getProperty("pwd")) : null; 
				PlmLegalPage legal = login.submitLoginCredentials(GlobalObjects.getPageData().getProperty("uid"), pwd);
				//Initialize and accept the notice
				PageFactory.initElements(driver, legal);				
				legal.acceptNotice();
				
				PlmHome home = PageFactory.initElements(driver, PlmHome.class);
				home.selectMenuCreateIssue();
				
				
			}
		}
		catch(Exception ex){System.err.println(ex);}
		finally{
			//GlobalObjects.closeQuitDriver();	
		}		
	}
}
