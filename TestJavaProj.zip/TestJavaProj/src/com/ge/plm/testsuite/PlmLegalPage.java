package com.ge.plm.testsuite;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.LoadableComponent;

public class PlmLegalPage extends LoadableComponent<PlmLegalPage>{

	private final WebDriver driver;
	
	@FindBy(how = How.XPATH, using = "//input[starts-with(@value,'   Ok   ')]")
	private WebElement btnAccept;
		
	@Override
	protected void load(){
		driver.get(GlobalObjects.getPageData().getProperty("baseurl"));
	}
	
	@Override
	protected void isLoaded() throws Error{
		System.out.println("Current URL: " + driver.getCurrentUrl() );
	}
	
	public PlmLegalPage(WebDriver driver){
		this.driver = driver;
	}

	public void acceptNotice(){
		btnAccept.click();		
	}
	
}
