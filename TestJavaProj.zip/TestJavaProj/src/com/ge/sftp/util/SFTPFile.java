/** SFTPFile
 * <Describe the purpose of this file here>
 * ATTENTION! Please indicate one of the following options:
 * This software is intended for:
 *	(_) Military use only
 *	(_) Commercial use only
 *	(X) Both military and commercial use
 * Copyright (C) General Electric 2007, 2008
 */

package com.ge.sftp.util;

import java.io.Serializable;
import java.util.Date;

/** This class implements a VO that reporesents a file entry for a SFTP directory listing
 * SFTPFile
 */
public class SFTPFile implements Serializable {
    private static final int SSH_FILEXFER_ATTR_PERMISSIONS=  0x00000004;
    private static final int S_IFDIR=0x4000;
    private static final int S_IFLNK=0xa000;
    private Date timeArchived = null;
    private Date timeModified = null;
    private int permissions = 0;
    private int uid = 0;
    private int gid = 0;
    private long size = 0;
    private int flags = 0;
    private String name = null;
    private String longName = null;
    
    private String strUniqueFileName=null;
    
    /** Returns the value of fileName with timeStamp.
     * @return Returns the fileName with timeStamp.
     */
    public String getStrUniqueFileName() {
		return strUniqueFileName;
	}
    /** Sets fileName with timeStamp property
     * @param fileName with timeStamp to set.
     */
	public void setStrUniqueFileName(String strUniqueFileName) {
		this.strUniqueFileName = strUniqueFileName;
	}

	/** Default constructor */
    public SFTPFile() {
        super();
    }

    /** Returns the value of aTime property.
     * @return Returns the aTime.
     */
    public Date getTimeArchived() {
        return timeArchived;
    }

    /** Sets aTime property
     * @param time The aTime to set.
     */
    public void setTimeArchived(Date time) {
        timeArchived = time;
    }

    /** Returns the value of mTime property.
     * @return Returns the mTime.
     */
    public Date getTimeModified() {
        return timeModified;
    }

    /** Sets mTime property
     * @param time The mTime to set.
     */
    public void setTimeModified(Date time) {
        timeModified = time;
    }

    /** Returns the value of permissions property.
     * @return Returns the permissions.
     */
    public int getPermissions() {
        return permissions;
    }

    /** Sets permissions property
     * @param permissions The permissions to set.
     */
    public void setPermissions(int permissions) {
        this.permissions = permissions;
    }

    /** Returns the value of uid property.
     * @return Returns the uid.
     */
    public int getUid() {
        return uid;
    }

    /** Sets uid property
     * @param uid The uid to set.
     */
    public void setUid(int uid) {
        this.uid = uid;
    }

    /** Returns the value of gid property.
     * @return Returns the gid.
     */
    public int getGid() {
        return gid;
    }

    /** Sets gid property
     * @param gid The gid to set.
     */
    public void setGid(int gid) {
        this.gid = gid;
    }

    /** Returns the value of size property.
     * @return Returns the size.
     */
    public long getSize() {
        return size;
    }

    /** Sets size property
     * @param size The size to set.
     */
    public void setSize(long size) {
        this.size = size;
    }

    /** Returns the value of name property.
     * @return Returns the name.
     */
    public String getName() {
        return name;
    }

    /** Sets name property
     * @param name The name to set.
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /** Returns the value of flags property.
     * @return Returns the flags.
     */
    public int getFlags() {
        return flags;
    }

    /** Sets flags property
     * @param flags The flags to set.
     */
    public void setFlags(int flags) {
        this.flags = flags;
    }
    
    /** Returns the value of longName property.
     * @return Returns the longName.
     */
    public String getLongName() {
        return longName;
    }

    /** Sets longName property
     * @param longName The longName to set.
     */
    public void setLongName(String longName) {
        this.longName = longName;
    }

    /** Returns true if the entry is a directory
     * 
     * @return true if directory
     */
    public boolean isDir() {
        return ((flags & SSH_FILEXFER_ATTR_PERMISSIONS) !=0 && ((permissions & S_IFDIR) == S_IFDIR));
    }
    
    /** Returns true if the entry is a link
     * 
     * @return true if the enty is a link
     */
    public boolean isLink() {
        return ((flags & SSH_FILEXFER_ATTR_PERMISSIONS) !=0 && ((permissions & S_IFLNK) == S_IFLNK));
    }
    
    @Override
    public String toString() {
        return longName;
    }
}
