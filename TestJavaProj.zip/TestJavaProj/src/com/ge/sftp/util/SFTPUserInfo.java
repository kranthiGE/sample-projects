package com.ge.sftp.util;


import com.jcraft.jsch.UserInfo;

/**
 * Helper class containing user credentials SFTPUserInfo
 * 
 * @author Julian Chultarsky Version 1.0 Created on Jul 13, 2008
 */
class SFTPUserInfo implements UserInfo {
	private String user = null;
	private String password = null;

	public SFTPUserInfo() {
		super();
	}

	public void setUserName(String userName) {
		this.user = userName;
	}

	public String getUserName() {
		return user;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPassword() {
		return password;
	}

	public String getPassphrase() {
		return null;
	}

	public boolean promptYesNo(String message) {
		return true;
	}

	public boolean promptPassphrase(String message) {
		return false;
	}

	public boolean promptPassword(String message) {
		return true;
	}

	public void showMessage(String message) {
		System.out.println(message);
	}
}
