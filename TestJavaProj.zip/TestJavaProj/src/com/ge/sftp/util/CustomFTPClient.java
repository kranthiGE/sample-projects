package com.ge.sftp.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URL;
import java.net.URLConnection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CustomFTPClient
{
  /** The URL connection object */
  private URLConnection m_client;
  /** The URL connection object */
  private URLConnection l_client;
  /** The FTP host/server to be connected */
  private String host;
  /** The FTP user */
  private String user;
  /** The FTP user�s password */
  private String password;
  /** The remote file that needs to be uploaded or downloaded */
  private String remoteFile;
  /** The previous error message triggered after a method is called */
  private String erMesg;
  /** The previous success message after any method is called */
  private String succMesg;
  public CustomFTPClient(){}
  /** Setter method for the FTP host/server */
  public void setHost (String host)
  {
    this.host = host;
  }
  /** Setter method for the FTP user */
  public void setUser (String user)
  {
    this.user = user;
  }
  /** Setter method for the FTP user�s password */
  public void setPassword (String p)
  {
    this.password = p;
  }
  /** Setter method for the remote file, this must include the sub-directory path relative
   to the user�s home directory, e.g you�e going to download a file that is within a sub directory
   called "sdir", and the file is named "d.txt", so you shall include the path as "sdir/d.txt"
  */
  public void setRemoteFile (String d)
  {
    this.remoteFile = d;
  }
  /** The method that returns the last message of success of any method call */
  public synchronized String getLastSuccessMessage()
  {
    if (succMesg==null ) return ""; return succMesg;
  }
  /** The method that returns the last message of error resulted from any exception of any method call */
  public synchronized String getLastErrorMessage()
  {
    if (erMesg==null ) return ""; return erMesg;
  }
  /** The method that handles file uploading, this method takes the absolute file path
   of a local file to be uploaded to the remote FTP server, and the remote file will then
   be transfered to the FTP server and saved as the relative path name specified in method setRemoteFile
   @param localfilename � the local absolute file name of the file in local hard drive that needs to
   FTP over
  */
  public synchronized boolean uploadFile (String localfilename)
  {
    try{
      InputStream is = new FileInputStream(localfilename);
      BufferedInputStream bis = new BufferedInputStream(is);
      OutputStream os =m_client.getOutputStream();
      BufferedOutputStream bos = new BufferedOutputStream(os);
      byte[] buffer = new byte[1024];
      int readCount;
      while( (readCount = bis.read(buffer)) > 0)
      {
            bos.write(buffer, 0, readCount);
      }
      bos.close();
      /*FileOutputStream fileOutputStream = null;
      File f = new File(localfilename);
      fileOutputStream = new FileOutputStream(f);
	  fileOutputStream.write();*/
      this.succMesg = "Uploaded!";
      return true;
    }
    catch(Exception ex)
    {
      StringWriter sw0= new StringWriter ();
      PrintWriter p0= new PrintWriter ( sw0, true );
      ex.printStackTrace ( p0 );
      erMesg = sw0.getBuffer().toString ();
      return false;
    }
  }
  /** The method to download a file and save it onto the local drive of the client in the specified absolut path
   @param localfilename � the local absolute file name that the file needs to be saved as */
  public synchronized boolean downloadFile (String localfilename)
  {
    try{
      InputStream is = m_client.getInputStream();
      
      BufferedInputStream bis = new BufferedInputStream(is);
      OutputStream os = new FileOutputStream(localfilename);     
      BufferedOutputStream bos = new BufferedOutputStream(os);
      byte[] buffer = new byte[1024];
      int readCount;
      while( (readCount = bis.read(buffer)) > 0)
      {
        bos.write(buffer, 0, readCount);
      }
      bos.close();
      is.close (); // close the FTP inputstream
      this.succMesg = "Downloaded!";
      return true;
    }catch(Exception ex)
    {
      StringWriter sw0= new StringWriter ();
      PrintWriter p0= new PrintWriter ( sw0, true );
      ex.printStackTrace ( p0 );
      erMesg = sw0.getBuffer().toString ();
      return false;
    }
  }
  /** The method that connects to the remote FTP server */
  public synchronized boolean connect()
  {
    try{
    URL url = new URL("ftp://"+user+":"+password+"@"+host+"/"+remoteFile+";type=i");
    //System.out.println("ftp://"+user+":"+password+"@"+host+"/"+remoteFile+";type=i");
    m_client = url.openConnection();
    return true;
    }
    catch(Exception ex)
    {
      StringWriter sw0= new StringWriter ();
      PrintWriter p0= new PrintWriter ( sw0, true );
      ex.printStackTrace ( p0 );
      erMesg = sw0.getBuffer().toString ();
      return false;
    }
  }
  
  /** The method that connects to the remote FTP server */
  public synchronized boolean connectFrList()
  {
    try{
    URL url = new URL("ftp://"+user+":"+password+"@"+host+"/");
    //System.out.println("ftp://"+user+":"+password+"@"+host+"/"+remoteFile+";type=i");
    l_client = url.openConnection();
    return true;
    }
    catch(Exception ex)
    {
      StringWriter sw0= new StringWriter ();
      PrintWriter p0= new PrintWriter ( sw0, true );
      ex.printStackTrace ( p0 );
      erMesg = sw0.getBuffer().toString ();
      return false;
    }
  }
  
  public List<String> listFiles(String dateOlderThan) throws IOException, ParseException{	  	
	  Matcher m;
	  String dtFormat;
	  SimpleDateFormat dateFormat;
	  String aBeginDateStr;
	  String fileName;
	  InputStream stream;
	  BufferedReader br;
	  Pattern p;
	  List<String> fileNames;
	  Calendar calendar = Calendar.getInstance();
	  Calendar flClndr = Calendar.getInstance();
	  
	  //-7 need to be driven from appworx prompts
      calendar.add(Calendar.DATE, Integer.parseInt(dateOlderThan));
      
      dtFormat = "yyyy-MM-dd";
      dateFormat = new SimpleDateFormat(dtFormat);
      
      aBeginDateStr = dateFormat.format(calendar.getTime());
      calendar.setTime(dateFormat.parse(aBeginDateStr));
      
      System.out.println("Before Date "+aBeginDateStr);
	  stream = l_client.getInputStream();
      br = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
      p = Pattern.compile("[-](.+?)[/.]");
      fileNames = new ArrayList<String>();
	  while (br.ready()) {
		    fileName = getFileName(br.readLine());
			m = p.matcher(fileName); 
			if (m.find()) {
				flClndr.setTime(dateFormat.parse(m.group(1)));
				if(flClndr.before(calendar)){
					fileNames.add(fileName); 
				}				
			} 	        
	  }
	  return fileNames;

  }
  
  public String getFileName(String fileName){
	  String files[];	
	  files = fileName.split(" ");
	  if(files.length > 0){
		  fileName = files[files.length-1];
	  }
	  return fileName;
  }
  
} 