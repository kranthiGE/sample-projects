package com.ge.sftp.util;

public class SFTPClientFactory {

	public static SFTPClient getSftpClientObject(){
		return SFTPClientImpl.getInstance();
	}
}
