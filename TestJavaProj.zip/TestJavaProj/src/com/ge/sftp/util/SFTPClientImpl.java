package com.ge.sftp.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import com.ge.sftp.util.SFTPFile;
import com.ge.sftp.util.SFTPUserInfo;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.jcraft.jsch.ChannelSftp.LsEntry;

public class SFTPClientImpl implements SFTPClient
{
	private static String PATH_SEPARATOR = "/";
	private JSch jsch = null;
	private Session session = null;
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
	public ChannelSftp sftpChannel = null;

	private static final SFTPClient INSTANCE = new SFTPClientImpl(); 
	
	public static SFTPClient getInstance(){
		return INSTANCE;
	}
	
	private SFTPClientImpl(){
		
	}
	/**
	 * Default constructor Constructor
	 * 
	 */
	/*public SFTPClientImpl() {
		super();
		this.jsch = new JSch();
	}*/

	/**
	 * Sets the location of the known_hosts file
	 * 
	 * @param path
	 * @throws JSchException
	 */
	public void setKnownHosts(String path) throws JSchException {
		jsch.setKnownHosts(path);
	}

	/**
	 * Connects the client to the server
	 * 
	 * @param host
	 * @param port
	 * @param user
	 * @param password
	 * @return
	 * @throws JSchException
	 */
	public void connect(final String host, int port, final String user, final String password) throws JSchException {
	    
		System.out.println("Connecting to SFTP server " + host + " on port " + port + "...");
		if ((null == session) || (!session.isConnected())) {

			SFTPUserInfo userInfo = new SFTPUserInfo();
			userInfo.setUserName(user);
			userInfo.setPassword(password);

			session = jsch.getSession(user, host, port);
			session.setUserInfo(userInfo);
			session.connect();

			Channel channel = session.openChannel("sftp");
			channel.connect();
			System.out.println("Connected.");
			
			sftpChannel = (ChannelSftp) channel;
			try {
				String home = sftpChannel.getHome();
				System.out.println("Home directory is " + home);
			} catch (SftpException ex) {
			    System.out.println("Unexpected exception occured while checking the home directory." + ex);
			}

		} else {
			System.out.println("The SFTP session is already connected.");
		}
	}

	/**
	 * Creates the specified directory structure. Calls to method can be ignored
	 * by passing a value of false in as createDirectory parameter.
	 * 
	 * @param directory
	 *            The directory structure to create.
	 * @param createDirectory
	 *            True if directory structure should be created.
	 * @throws SftpException
	 */
	public synchronized void createDirectory(String directory,	boolean createDirectory) throws SftpException {

	    if (createDirectory && !(isDirectoryExists(directory))) {
			if (createDirectory(directory)) {
			} else {
				System.out.println("Directory " + directory + " was created successfully.");
				System.out.println("Directory " + directory + " already exists.");
			}
		} 
	}
	
	public synchronized String getHomeDirectory()
	 throws SftpException {
		String workingDir = "";
		try 
		{
			workingDir = sftpChannel.pwd();
		}
		catch (Exception ex) {
			SftpException nex = new SftpException(1, "Failed to find Home directory " + ex.getMessage());
			nex.setStackTrace(ex.getStackTrace());
			throw nex;
		}
		return workingDir;
	}

	/**
	 * Checks to see if directory exists.
	 * 
	 * @param directory
	 *            The directory to check.
	 * @return True if the directory exists.
	 * @throws FTPException
	 */
	public synchronized boolean isDirectoryExists(String directory) throws SftpException {

	    String workingDir = "";
	    boolean directoryExists = false;
		try {
			
			// get current working directory so it can be reset afterwards
			workingDir = sftpChannel.pwd();
			changeDirectory(directory);
			if (sftpChannel.pwd().equals(directory)) {
				directoryExists = true;
			}
		}
		catch (Exception ex) 
		{
			directoryExists = false;
			SftpException nex = new SftpException(1, "Failed to find directory " + directory + ". " + ex.getMessage());
			nex.setStackTrace(ex.getStackTrace());
			
		} finally {
			// reset working directory
			changeDirectory(workingDir);
		}
		return directoryExists;
	}

	/**
	 * Creates the directory structure specified.
	 * 
	 * @param directory
	 *            The directory structure to create.
	 * @return True if the directory structure is created successfully.
	 * @throws FTPException
	 */
	public synchronized boolean createDirectory(String directory) throws SftpException {

	    try {
			// create directory
			if (isDirectoryExists(directory)) {
				// directory already exists
				return false;
			} else 
			{		
				sftpChannel.mkdir(directory);
				return isDirectoryExists(directory);
			}
		} catch (Exception ex) {
			SftpException nex = new SftpException(1, "Failed to create directory " + directory + ". " + ex.getMessage());
			nex.setStackTrace(ex.getStackTrace());
			throw nex;
		}
	}

	public void changeDirectory(String path) throws SftpException {

		if ((null != sftpChannel) && (sftpChannel.isConnected())) {
			sftpChannel.cd(path);
		} else {
			System.out.println("The SFTP channel is not connected. Check if the session is established properly.");
		}
	}

	/**
	 * Gets a list of all files in the specified directory.
	 * 
	 * @param path
	 *            The directory to look in.
	 * @return The list of files in the directory.
	 * @throws SFTPException
	 */
	public List<SFTPFile> getFilesList(String path) throws SftpException {

		List<SFTPFile> result = new ArrayList<SFTPFile>();

		if ((null != sftpChannel) && (sftpChannel.isConnected())) {
			System.out.println("current working directory is:---" + path);
			Vector<LsEntry> files = sftpChannel.ls(path);
			System.out.println("no of files::::::::" + files.size());
			System.out.println("Files:");

			// Get entire content listing.

			if (files != null) {
				// Iterate listing.
				for (int i = 0; i < files.size(); i++) {
					LsEntry entry = (LsEntry) files.elementAt(i);
					String filename = entry.getFilename();

					// Copy only non-directories (i.e. files) to
					// our new vector.
					if (!entry.getAttrs().isDir()) {
						String longName = entry.getLongname();
						SftpATTRS attrs = entry.getAttrs();
						SFTPFile sftpFile = new SFTPFile();
						System.out.println("Attributes----"
								+ attrs.getMtimeString() + "    "
								+ attrs.getSize() + "   " + attrs.getMTime());
						sftpFile.setTimeArchived(new Date(attrs.getATime()));
						try {
							Date mTime = new SimpleDateFormat(
									"EEE MMM dd hh:mm:ss zzz yyyy").parse(attrs
									.getMtimeString());
							System.out.println(mTime);

							sftpFile.setTimeModified(mTime);
							System.out.println(sdf.format(sftpFile
									.getTimeModified()));
							sftpFile.setSize(attrs.getSize());
							sftpFile.setFlags(attrs.getFlags());
							sftpFile.setGid(attrs.getGId());
							sftpFile.setUid(attrs.getUId());
							sftpFile.setPermissions(attrs.getPermissions());
							sftpFile.setName(filename);
							System.out.println("file.getTimeModified()  "
									+ sftpFile.getTimeModified() + "    "
									+ sftpFile.getTimeArchived().toString());
							sftpFile.setStrUniqueFileName(sdf.format(sftpFile
									.getTimeModified())
									+ "11_" + sftpFile.getName());
							System.out.println(sftpFile.getStrUniqueFileName());
							sftpFile.setLongName(longName);
							result.add(sftpFile);
						} catch (ParseException e) {
							e.printStackTrace();
						}
					}
				}

			}
		} else {
			System.out.println("The SFTP channel is not connected. Check if the session is established properly.");
		}
		// System.out.println("result "+result.get(0).getName());
		return result;
	}

	/**
	 * Returns an InputStream to the file on the remote server
	 * 
	 * @param file
	 * @return input stream
	 * @throws SftpException
	 */
	/*
	 * public InputStream get(String file) throws SftpException { return
	 * sftpChannel.get(file); }
	 */
	public InputStream getRemoteFileInputStream(String filename) {
		try {
			// SftpProgressMonitor monitor = new MyProgressMonitor();

			ByteArrayOutputStream out = new ByteArrayOutputStream();
			sftpChannel.get(filename, out);

			return new ByteArrayInputStream(out.toByteArray());

		} catch (Exception e) {
			// myWP.errorMsg( e.toString() );
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Uploads a file to the remote server. Use the input steam to send data to
	 * the SFTP server. The file will be created using the name you specify in
	 * the file argument.
	 * 
	 * @param input
	 *            stream for the data source
	 * @param the
	 *            name of the remote file
	 * @throws SftpException
	 */
	public void put(InputStream input, String file) throws SftpException {
		sftpChannel.put(input, file);
	}

	/**
	 * Changes the mode of the remote file
	 * 
	 * @param mode
	 * @param file
	 * @throws SftpException
	 */
	public void chmod(int mode, String file) throws SftpException {
		sftpChannel.chmod(mode, file);
	}

	/**
	 * Moves or renames a file on the remote server
	 * 
	 * @param src
	 * @param dst
	 * @throws SftpException
	 */
	public void mv(String src, String dst) throws SftpException {
		sftpChannel.rename(src, dst);
	}

	/**
	 * Disconnects the current session
	 * 
	 * @param session
	 */
	public void disconnect() {

		if ((null != sftpChannel) && (sftpChannel.isConnected())) {
			sftpChannel.exit();
			sftpChannel.disconnect();
		}

		if ((null != session) && (session.isConnected())) {
			session.disconnect();
		} else {
			System.out.println("The session is not connected.");
		}
	}

	public boolean copyFile(String srcPath, String destPath) throws SftpException {
		System.out.println("here in the downloadFile sftp block");
		InputStream inStream = getRemoteFileInputStream(srcPath);
		// String srcFile=inboxPath+task.getSftpFile().getName();

		try {
			System.out.println("Instream=====" + inStream.available());
			System.out.println("Goint to put file in outgoing  " + destPath);
			// task.getChannel().getServer().getSftpClient().put(inStream,tempPath);
			put(inStream, destPath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SftpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (inStream != null) {
				try {
					inStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		if (isFileExists(destPath))
			return true;
		else
			return false;
		
	}

	/**
	 * Check if a file exists.<br>
	 * 
	 * @param filename
	 *            name of the file to check
	 * @return true if the file exists, otherwise false. 
	 * @throws SftpException
	 */

	public boolean isFileExists(String filename) throws SftpException {
		String directory = filename.substring(0, filename
				.lastIndexOf(PATH_SEPARATOR) + 1);
		String nameOfFile = filename.substring(filename
				.lastIndexOf(PATH_SEPARATOR) + 1);

		System.out.println("Checking for the file name  " + nameOfFile
				+ " in the directory  " + directory);
		Vector<LsEntry> ls = sftpChannel.ls(directory);
		for (LsEntry f : ls) {
		//	System.out.println("f.getFilename()******" + f.getFilename());
			if (f.getFilename().equals(nameOfFile)) {
				return true;
			}
		}
		return false;
	}
}
