package com.ge.sftp.util;

import java.io.InputStream;
import java.util.List;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;

public interface SFTPClient {

	/**
	 * Connects the client to the server
	 * 
	 * @param host
	 * @param port
	 * @param user
	 * @param password
	 * @return
	 * @throws JSchException
	 */
	void connect(final String host, int port, final String user, final String password) throws JSchException;
		
	/**
	 * Creates the specified directory structure. Calls to method can be ignored
	 * by passing a value of false in as createDirectory parameter.
	 * 
	 * @param directory
	 *            The directory structure to create.
	 * @param createDirectory
	 *            True if directory structure should be created.
	 * @throws SftpException
	 */
	void createDirectory(String directory,	boolean createDirectory) throws SftpException;
	
	/**
	 * gets the working directory by running pwd on sftpchannel object in remote server
	 * @throws SftpException 
	 */
	String getHomeDirectory() throws SftpException;
	
	/**
	 * Checks to see if directory exists based on an input directory path
	 * 
	 * @param directory
	 *            The directory to check.
	 * @return True if the directory exists.
	 * @throws SftpException
	 */
	boolean isDirectoryExists(String directory) throws SftpException;
	
	/**
	 * Creates the directory structure specified.
	 * 
	 * @param directory
	 *            The directory structure to create.
	 * @return True if the directory structure is created successfully.
	 * @throws SftpException
	 */
	boolean createDirectory(String directory) throws SftpException;
	
	/**
	 * Gets a list of all files in the specified directory.
	 * 
	 * @param path
	 *            The directory to look in.
	 * @return The list of files in the directory.
	 * @throws SFTPException
	 */
	List<SFTPFile> getFilesList(String path) throws SftpException;
	
	/**
	 * Returns an InputStream to the file on the remote server
	 * 
	 * @param file
	 * @return input stream
	 * @throws SftpException
	 */
	public InputStream getRemoteFileInputStream(String filename);
	
	/**
	 * Uploads a file to the remote server. Use the input steam to send data to
	 * the SFTP server. The file will be created using the name you specify in
	 * the file argument.
	 * 
	 * @param input
	 *            stream for the data source
	 * @param the
	 *            name of the remote file
	 * @throws SftpException
	 */
	public void put(InputStream input, String file) throws SftpException;
	
	/**
	 * Changes the mode of the remote file
	 * 
	 * @param mode
	 * @param file
	 * @throws SftpException
	 */
	void chmod(int mode, String file) throws SftpException;
	
	/**
	 * Moves or renames a file on the remote server
	 * 
	 * @param src
	 * @param dst
	 * @throws SftpException
	 */
	void mv(String src, String dst) throws SftpException;
	
	/**
	 * Disconnects the current session
	 * 
	 * @param session
	 */
	void disconnect();
	
	/**
	 * Copies file from source to distination path
	 * 
	 * @param srcPath
	 * @param destPath
	 * @throws SftpException
	 */
	boolean copyFile(String srcPath, String destPath) throws SftpException;
	
	/**
	 * Check if a file exists.<br>
	 * 
	 * @param filename
	 *            name of the file to check
	 * @return true if the file exists, otherwise false. 
	 * @throws SftpException
	 */
	public boolean isFileExists(String filename) throws SftpException;
	
	
	
	
	
}
