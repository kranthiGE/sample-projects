package com.ge.sftp;

import com.ge.sftp.util.CustomFTPClient;
import com.ge.sftp.util.SFTPClient;
import com.ge.sftp.util.SFTPClientFactory;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;

public class SendFile {
	
	public SendFile(){
	}
	
	public static void sftpFile(String sourcePath, String destPath, String host, String uid, String pwd){
		SFTPClient sftpclient = SFTPClientFactory.getSftpClientObject();
		try{
			sftpclient.connect(host, 22, uid, pwd);
			sftpclient.copyFile(sourcePath, destPath);
		}
		catch(JSchException jEx){
			System.err.println(jEx);
		}
		catch(SftpException sEx){
			System.err.println(sEx);
		}
		finally{
			sftpclient.disconnect();
		}
	}
	
	public static void ftpFiles(){
		CustomFTPClient ftp = new CustomFTPClient();
		ftp.setHost("3.251.102.40");
		ftp.setUser("nggmnvq");
		ftp.setPassword("");
		ftp.setRemoteFile("C:\\Users\\nggmnvq\\EEDW\\temp\\Datatime_filter_sqls.sql");
		ftp.connect();
		ftp.uploadFile("C:\\Users\\nggmnvq\\EEDW\\Datatime_filter_sqls.sql");
		
	}
	
	public static void main(String[] args){
		//sftpFile("C:\\Users\\nggmnvq\\EEDW\\temp\\Datatime_filter_sqls.sql", "C:\\Users\\nggmnvq\\EEDW\\Datatime_filter_sqls.sql", "3.251.102.40", "GEAEINDIA\nggmnvq", "");
		ftpFiles();
	}
	
}
