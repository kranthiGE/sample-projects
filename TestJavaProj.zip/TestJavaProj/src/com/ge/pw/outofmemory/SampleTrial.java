package com.ge.pw.outofmemory;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class SampleTrial {

	public static void main(String[] args) throws InterruptedException{
		System.out.println("Max Size: " + Runtime.getRuntime().maxMemory());	
		SampleTrial trial = new SampleTrial();
		trial.mapExample();
	}
	
	public void intArrayExample(){
		Long maxSize = Runtime.getRuntime().maxMemory();
		int[] intArray = new int[(int)(maxSize+1)];
		for(int i = 0; i < 100; i++){
			intArray[i] = i+1;
			System.out.println("free memory: " + Runtime.getRuntime().freeMemory());
		}	
	}
	
	public void mapExample() throws InterruptedException{
		Random rnd = new Random();
		Map<Integer, String> samMap = new HashMap<Integer, String>();
		while(true){
			int val = rnd.nextInt();
			samMap.put(val, String.valueOf(val));
			//Thread.sleep(1000);=
			System.out.println("free memory: " + Runtime.getRuntime().freeMemory());
		}
		
	}
	
}
