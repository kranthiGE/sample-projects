package com.ge.accounts;

public class TestAccounts {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			System.out.println("tets");
	}

}
