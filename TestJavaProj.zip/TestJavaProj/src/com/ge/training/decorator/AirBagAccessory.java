package com.ge.training.decorator;

public class AirBagAccessory extends AccessoryDecorator {

	public AirBagAccessory(Car car){
		super(car);
	}
	
	protected double getCost(){
		return this.car.getCost() + 1;		
	}
		
}
