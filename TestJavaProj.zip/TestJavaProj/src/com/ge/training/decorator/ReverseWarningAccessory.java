package com.ge.training.decorator;

public class ReverseWarningAccessory extends AccessoryDecorator {

	public ReverseWarningAccessory(Car car){
		super(car);
	}
	
	protected double getCost(){
		return this.car.getCost() + 1.5;		
	}
}
