package com.ge.training.decorator;

public class SedanCar extends Car {

	@Override
	protected double getCost(){
		return 3.0;
	}
	
}
