package com.ge.training.decorator;

public abstract class AccessoryDecorator extends Car {

	Car car;
	
	public AccessoryDecorator(Car car){
		this.car = car;
	}
	
	protected abstract double getCost();
}
