package com.ge.training.decorator;

public class CarMain {

	public static void main(String[] args){
		//Sedan car
		Car sedan = new AirBagAccessory(new ReverseWarningAccessory(new SedanCar()));
		System.out.println(sedan.getCost());
		
		//hatch back car
		Car hatchBack = new AirBagAccessory(new ReverseWarningAccessory(new HatchBackCar()));
		System.out.println(hatchBack.getCost());
		
		
	}
}
