package com.ge.training.decorator;

public class HatchBackCar extends Car{

	@Override
	protected double getCost(){
		return 2.0;
	}
}
