package com.ge.training.decorator;

public abstract class Car {

	protected abstract double getCost();
}
