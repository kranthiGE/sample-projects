package com.ge.graph;

public class Relation {

	private Type type; 
	
	public Type getType() {
		return type;
	}

	private String relationName;
	
	public Relation(){
		type = null;
	}
	
	public String getRelationName(){
		return relationName;
	}
	
	public Relation(Type type, String relName){
		this.type = type;
		relationName = relName;
	}
	
	public String toString(){
		return relationName + "->" + type.getName(); 
	}
}
