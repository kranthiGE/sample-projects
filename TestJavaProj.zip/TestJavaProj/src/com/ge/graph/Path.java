package com.ge.graph;

import java.util.ArrayList;
import java.util.List;

public class Path {

	Relation relation =  null;
	
	Type type = null;
	
	List<String> types = new ArrayList<String>();
	
	public void addTypeRelation(Relation relation, Type type){
		this.relation = relation;
		this.type = type;
		types.add(new StringBuilder().append(relation.getRelationName()).append("->").append(type.getName()).toString());
	}
	
	public StringBuilder getPath(){
		StringBuilder pathdata = new StringBuilder();
		for(String data : types){
			pathdata.append(data).append("->");
		}
		return pathdata;
		
	}
}
