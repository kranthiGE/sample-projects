package com.ge.graph;

import java.util.ArrayList;
import java.util.List;

public class Type {

	private List<Relation> neighbours;
	
	public List<Relation> getNeighbours() {
		return neighbours;
	}

	private String typeName;
	
	public String getName(){
		return typeName;
	}
	
	public Type(String typeName){
		neighbours = new ArrayList<Relation>();
		this.typeName = typeName;
	}
	
	public boolean isEqual(Type type){
		return typeName.equals(type.typeName);
	}
	
	public void addRelation(Relation relation){
		neighbours.add(relation);		
	}
}
