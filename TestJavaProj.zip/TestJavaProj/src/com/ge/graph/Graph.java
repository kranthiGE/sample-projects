package com.ge.graph;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Graph {

	private Map<String, Type> typesMap;
	
	public Graph(){
		typesMap = new HashMap<String, Type>();
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("Hi");
		Graph plmGraph = new Graph();
		
		try {
			plmGraph.setCsvData("C:/Users/nggmnvq/EEDW/Project docs/PWi/Design/ODS-Adhoc/ods_types_rels.csv");
			//System.out.println(plmGraph.getTypes());
			PathFinder find = new PathFinder();
			System.out.println("ECO -> ");
			find.findAllPaths(plmGraph, plmGraph.getType("ECO"), plmGraph.getType("GE Vendor Part"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public Type[] getTypes() {
    	return typesMap.values().toArray(new Type[0]);
    }
	
	public Type getType(String name) {
		Type type = typesMap.get(name);
    	if (type == null) {
    		type = new Type(name);
    		typesMap.put(name, type);
    	}
    	return type;
    }
	
	public void setCsvData(String filePath) throws FileNotFoundException, IOException{
		BufferedReader reader = new BufferedReader(new FileReader(filePath));
		String line;
		while((line = reader.readLine()) != null) {
			readData(line);
		}
	}
	
	private void readData(String line){
		String[] data = line.split(",");
		
		//check length of S, should be 3
		if(data.length < 3){
			throw new IllegalArgumentException("Each line should FromType,ToType,Relation " + data);
		}
				
		Type from = getType(data[0]);		
		Type to = getType(data[1]);		
		
		from.addRelation(new Relation(to, data[2]));					
	}

}
