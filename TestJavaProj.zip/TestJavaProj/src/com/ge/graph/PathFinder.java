package com.ge.graph;

import java.util.ArrayList;
import java.util.List;

public class PathFinder {

	List<Path> paths = new ArrayList<Path>();
	Path path = null;
	public List<Path> findAllPaths(Graph G, Type fromType, Type toType ){
		 
		for (Relation relation: fromType.getNeighbours()) {
			Type destination = relation.getType();
			path = new Path();
			if(destination.isEqual(toType)){
				//add current Path object to paths list
				//and create new Path object
				path.addTypeRelation(relation, destination);
				paths.add(path);
				path = new Path();
			}
			else{
				for (Path path : findAllPaths(G, destination, toType)) {
					Type newPath = null;
					//System.out.print(destination.getName() + " -> " + newPath.getName() + " -> ");
					//till toType is found, add the flow to current Path object
					path.addTypeRelation(relation, newPath);					
				}
			}
		}
		return paths;
	}
	
	
}
