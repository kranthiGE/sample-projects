package com.eedw.performance;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RunSqlQuery {

	String fileName = null, environment = null;	
	
	int maxCnt = 0, frequency = 0;
	
	List<PerformanceData> logVals = new ArrayList<PerformanceData>();
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		if(checkInputArgs(args)){
			RunSqlQuery run = new RunSqlQuery();
			
			run.setEnvironment(args[0].toString());			
			run.setFileName(args[1].toString());
			run.setMaxCnt(Integer.valueOf(args[2]));
			run.setFrequency(Integer.valueOf(args[3]));
			int rowCount = 0;
			
			if(run.isFileExists(run.getFileName())){
				do{	
					rowCount++;
					System.out.println(" Sample run: " + rowCount);
					run.executeSqlFile(rowCount);
					System.out.println(" Completed run: " + rowCount);
					try{
						if(run.getMaxCnt() > 1 && rowCount != run.getMaxCnt())
							Thread.sleep(60000*run.getFrequency());
					}
					catch(InterruptedException iEx){System.err.println(iEx);}
				}while(rowCount < run.getMaxCnt() );
			}			
			run.createCsvReport("SQLPerformance", run.logVals);
			System.out.println(" Performance CSV report created ");
		}
	}
	
	private static boolean checkInputArgs(String[] args){
		boolean isValid = false;
		switch(args.length){		
		case 4:	//args - <environment> <SQL filename> <No. of samples> <Frequency (in minutes)>			
			isValid = true;
			break;		
		default:
			System.err.println("Usage:\n  RunSqlQuery <Environment> <.sql filename> <No. of samples>  <Frequency (in minutes)>\n\n");			
			break;
		}		
		return isValid;
	}
	
	/**
	 * @param SQL file name
	 * @throws SQLException
	 *             executeSqlFile - read SQL file and execute each SQL query against the environment 
	 */	
	private void executeSqlFile(int rowCount){
		BufferedReader br = null;
		String line = "";
		StringBuffer stBuf = new StringBuffer();
		Connection con = null;
		
		try{
			br = new BufferedReader(new InputStreamReader(new FileInputStream(getFileName())));
			con = DbUtil.getConnection(getEnvironment());
			if(con != null)
				System.out.println(" DB Connection established ");
			while((line = br.readLine()) != null){
				if(line.contains(";")){
					//execute SQL query
					stBuf.append(line);
					long startTime = System.currentTimeMillis();					
					DbUtil.executeQuery(stBuf.toString(), con);		
					logVals.add(new PerformanceData("\""+stBuf.toString()+"\"", ((System.currentTimeMillis() - startTime)/1000.0), rowCount));
					stBuf.setLength(0);
				}
				else
					stBuf.append(line).append(" ");
			}
		}
		catch (Exception e) {
			System.err.println("Error in readSqlFile : " + e);
		}
		finally{
			try{
			if(con != null)
				con.close();
			}
			catch (SQLException e) {
				System.err.println(e);
			}
		}
	}

	
	private void createCsvReport(String fileName, List<PerformanceData> data){
		PrintStream printStm = null;
		try{
			File optFile = new File(fileName + ".csv");
			printStm = new PrintStream(new FileOutputStream(optFile));//create a csv file
			printStm.println("SQLQuery, Total execution time (in Sec), Sample");
			for (PerformanceData perf : data) {
				if(perf != null)
				printStm.println(perf.getSqlQuery() + "," + perf.getElapsedTime() + "," + perf.getRunCount());				
			}
		}
		catch(FileNotFoundException ex){System.err.println(ex);}
		finally{
			printStm.close();
		}
	}

	/**
	 * @return true or false
	 * @param file
	 * @throws SQLException
	 *             isFileExists - check if file exists at the given location or not      
	 */	
	public boolean isFileExists(String fileName){
		boolean isExists = false;
		try {
			File file = new File(fileName);			
			isExists = (null != file && !file.exists()) ? false : true;			
		} catch (Exception e) {
			System.err.println(e);
		}
		return isExists;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public int getMaxCnt() {
		return maxCnt;
	}

	public void setMaxCnt(int maxCnt) {
		this.maxCnt = maxCnt;
	}
	
	private class PerformanceData {
		
		private String sqlQuery = "";		
		private double elapsedTime = 0;
		int runCount = 0;
						
		public PerformanceData(String sqlQuery, double elapsedTime, int runCount){
			this.sqlQuery = sqlQuery;
			this.elapsedTime = elapsedTime;
			this.runCount = runCount;
		}

		public String getSqlQuery() {
			return sqlQuery;
		}

		public double getElapsedTime() {
			return elapsedTime;
		}
	
		public int getRunCount() {
			return runCount;
		}		
	}

	public int getFrequency() {
		return frequency;
	}

	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}
}
