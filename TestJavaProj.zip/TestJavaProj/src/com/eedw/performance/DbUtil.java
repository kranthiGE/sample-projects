package com.eedw.performance;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DbUtil {

	public static void release(final Connection con) throws SQLException {
        release((Statement[])null, (ResultSet[])null, con);
	}

	public static void release(final ResultSet... res) throws SQLException {
	        release(null, res, null);
	}

	public static void release(final Statement[] stmt) throws SQLException {
	        release(stmt, null, null);
	}

	public static void release(final Statement stmt, final ResultSet... res) throws SQLException {
	        release(stmt == null ? null : new Statement[] { stmt }, res, null);
	}
	
	public static void release(final Statement stmt, final ResultSet resultSet, final Connection conn) throws SQLException {
	        release(stmt == null ? null : new Statement[] { stmt },
	                resultSet == null ? null : new ResultSet[] { resultSet }, conn);
	}
	
	public static void release(final Statement[] stmt, final ResultSet[] resultSet) throws SQLException {
	        release(stmt, resultSet, null);
	}

		public static void release(final Statement[] stmt, final ResultSet[] resultSet, final Connection conn) throws SQLException {
		
		        SQLException error = null;
		
		try {
				if (resultSet != null) {
			                        for (ResultSet res : resultSet) {
			                                try {
			                                        if (res != null) {
			                                                res.close();
			                                        }
			                                        
			                                } catch (SQLException e) {
			                                        error = e;
			                                        System.err
															.println("Result set failed to close" + e);
			                                }
			                        }
			                }
		        } finally {
		                try {
							if (stmt != null) {
								for (Statement st : stmt) {
								        try {
								                if (st != null) {
								                        st.close();
								                }
								        } catch (SQLException e) {
								                error = e;
								                System.err
												.println("Statement failed to close"+ e);
								}
								                }
			                 }		                
		                } finally {
		                    try {
								if (conn != null) {
									conn.close();
								}
								                    } catch (SQLException e) {
								                            error = e;
								                            System.err
																	.println("Connection failed to close"+ e);
								}
		                }
		        	}
		
		        if (error != null) {
		                throw error;
		        }
		}
				
		/**
		 * @return
		 * @throws SQLException
		 *             getConnection -This getConnection method is used to get
		 *             Connection to Data base.
		 */
		public static Connection getConnection(String environment){
			Connection conn = null;
			try {   
				final String driverName = "com.teradata.jdbc.TeraDriver";
				final String url = getDBUrl(environment);
				final String dbUserid = "307007782";		  		
				Class.forName(driverName);
				conn = DriverManager
	                    .getConnection(url, dbUserid, "Ultim123ate$");                        

			} 
			catch (ClassNotFoundException cEx) {			
				System.err.println("error in getConnection :: ClassNotFoundException - " + cEx);
			}
			catch (SQLException e) {			
				System.err.println("error in getConnection" + e);
			}
			
			return conn;
		}
	   		
		private static String getDBUrl(String env){
			String dburl = null;
			if(env.equalsIgnoreCase("d"))
				dburl = "jdbc:teradata://GEITDDEV.ae.ge.com";
			if(env.equalsIgnoreCase("q"))
				dburl = "jdbc:teradata://GEITDQA.ae.ge.com";
			if(env.equalsIgnoreCase("p"))
				dburl = "jdbc:teradata://GEITDPRD.ae.ge.com";
			return dburl;
		}
		
		public static ResultSet executeMacro(String macroQuery, Connection con){
			PreparedStatement stateMacro = null;
			ResultSet rsMacroData = null;
			try {
				stateMacro = con.prepareStatement(macroQuery, ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);				
				rsMacroData = stateMacro.executeQuery();
			} catch (SQLException ex) {
				System.err.println("Exception in executeQuery :"	+ ex);			
			}		
			/*finally{
				try {			
					if(rsMacroData != null)
						DbUtil.release(rsMacroData);
					if(stateMacro != null)
					DbUtil.release(stateMacro);				
				}
				catch(SQLException sqlEx){
					System.err.println("Exception in executeQuery :"	+ sqlEx);			
				}
			}*/
			return rsMacroData;
		}
		/**
		 * @return
		 * @throws SQLException
		 *             executeQuery - Executes any SQL provided and returns forward only result set.             
		 */
		public static void executeQuery(String query,Connection con) {
			PreparedStatement stateMacro = null;
			//ResultSet rset = null;		
			try {			
				stateMacro = con.prepareStatement(query, ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
				
				stateMacro.execute();
				/*ResultSet rs =  stateMacro.executeQuery();
				while(rs.next()){
					System.out.println(rs.getString(1));
				}*/
			} catch (SQLException ex) {
				System.err.println("Exception in executeQuery :"	+ ex);			
			}		
			finally{
				try {			
					/*if(rset != null)
						DbUtil.release(rset);*/
					if(stateMacro != null)
					DbUtil.release(stateMacro);				
				}
				catch(SQLException sqlEx){
					System.err.println("Exception in executeQuery :"	+ sqlEx);			
				}
			}		
		}
		
}
