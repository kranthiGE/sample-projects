package com.eedw.performance;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.Borders;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

public class PoiXSSFTest {

	public static void main(String[] args){
		
		//createStreamingXlsx();
		createMSWordDoc();
		
		
		
	}
	
	public static void createUserModelXlsx(){
		XSSFWorkbook wbook = new XSSFWorkbook();
		XSSFSheet sheet = wbook.createSheet("TestData");
	}
	
	public static void createMSWordDoc(){
		XWPFDocument doc = new XWPFDocument();
		//create paragraph - kind of template with specific format
		XWPFParagraph par1 = doc.createParagraph();
		par1.setAlignment(ParagraphAlignment.CENTER);
		par1.setBorderLeft(Borders.SINGLE);
		par1.setBorderRight(Borders.SINGLE);
		par1.setBorderBottom(Borders.SINGLE);
		par1.setBorderTop(Borders.SINGLE);
		par1.setBorderBetween(Borders.SINGLE);
		
		XWPFRun par1Run = par1.createRun();
		par1Run.setBold(true);
		par1Run.setText(" This is par1 by Kranthi ");
		par1Run.addBreak();
		
		FileOutputStream out = null;
		try{
			out = new FileOutputStream("C:\\Users\\nggmnvq\\Softwares\\POI_3.10\\poi-3.10-FINAL\\sample\\test.docx");
			doc.write(out);
		}
		catch(FileNotFoundException fleEx){
			System.err.println(fleEx);
		}
		catch(IOException ioEx){
			System.err.println(ioEx);
		}
		finally{
			try{
			if(out != null)
				out.close();
			}
			catch(IOException ioEx){
				System.err.println(ioEx);
			}
		}
		
	}
	
	public static void createStreamingXlsx(){
		SXSSFWorkbook sWbook = new SXSSFWorkbook(100);
		Sheet sh = sWbook.createSheet(); 
		for(int rowNo = 0; rowNo < 1000; rowNo++){
			Row row = sh.createRow(rowNo);
			for(int cellNo =0; cellNo < 10; cellNo++){
				Cell cell = row.createCell(cellNo);
				cell.setCellValue(new CellReference(cell).formatAsString());
			}
		}
		FileOutputStream out = null;
		try{
			out = new FileOutputStream("C:\\Users\\nggmnvq\\Softwares\\POI_3.10\\poi-3.10-FINAL\\sample\\test.xlsx");
			sWbook.write(out);	
			System.out.println("XLSX file created");
		}
		catch(FileNotFoundException ex){
			System.err.println("FileNotFoundException in createStreamingXlsx" + ex);
		}
		catch(IOException ioEx){
			System.err.println("IOException in createStreamingXlsx" + ioEx);
		}
		finally{
			try{
			out.close();
			}
			catch(IOException ioEx){
				System.err.println("IOException in createStreamingXlsx" + ioEx);
			}			
		}
	}
}
