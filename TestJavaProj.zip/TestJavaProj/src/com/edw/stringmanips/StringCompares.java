package com.edw.stringmanips;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class StringCompares {

	public static void main(String[] args){
		StringCompares strManps = new StringCompares();
		System.out.println( strManps.compareStringWithValues("kiran", "kranthi|sahithi"));
		String[] values = {"kranthi", "sahithi", "kiran"};
		int[] numbers = {0,1,2,3};
		System.out.println(strManps.checkifNumberExists(1,2,5,6,1,9));
		
		Set<Integer> set = new HashSet<Integer>( Arrays.asList(12, 1, 2, 3, 4));
		System.out.println(set.contains(1));		
	}
	
	public boolean compareStringWithValues(String str, String values){//values: ("val1|val2|val3")
		return str.matches(values);
	}
	
	public <T> boolean isExists(T target, T...values){
		for (T t : values) {
			System.out.println(t);
			return target.equals(t);
		}
		return false;
	}
	
	public <T> boolean checkifNumberExists(T target, T...a){
		Set<Integer> numbers = new HashSet<Integer>((Collection<? extends Integer>) Arrays.asList(a));
		return numbers.contains(target);		
	}
}
