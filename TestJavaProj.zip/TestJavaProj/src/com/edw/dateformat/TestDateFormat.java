package com.edw.dateformat;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Currency;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class TestDateFormat {

	DateFormat dtFmt = new SimpleDateFormat("MMddyy");
	
	/*
	 * Illustration to synchronize the call to DateFormat object to make it threadsafe
	 */
	public Date getDate(String source) throws ParseException{
		//synchronized (dtFmt) {
			Date dt =dtFmt.parse(source);
			return dt;
		//}
	}
	
	public static void executeThreads(){
		final TestDateFormat dt = new TestDateFormat(); 
		ExecutorService execServ = Executors.newFixedThreadPool(3);
		List<Future<Date>> res = new ArrayList<Future<Date>>();
		
		for(int i =0; i<=5;i++){
			res.add(execServ.submit(new Callable<Date>(){
				public Date call() throws ParseException{
					return dt.getDate("103013");
				}				
			}));
		}
		execServ.shutdown();
		try{
			for (Future<Date> future : res) {
				System.out.println(future.get());
			}
		}
		catch(ExecutionException ex){ex.printStackTrace();}
		catch(InterruptedException ex){ex.printStackTrace();}
	}
	
	public static void main(String[] args) {
		getPriceInIndia();
		//executeThreads();
	}
	
	public static void getPriceInIndia(){
		Locale in = new Locale("hi", "in");
		NumberFormat currency = NumberFormat.getCurrencyInstance(in);
		System.out.println(currency.format("1000000.45"));
		Currency india = Currency.getInstance(in);
		System.out.println(india.getCurrencyCode());
	}
}
