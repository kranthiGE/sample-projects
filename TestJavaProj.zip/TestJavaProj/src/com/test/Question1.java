package com.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import com.test.Question1.Fruit;
import com.test.Question1.FruitComparator;

public class Question1{  
	  
	public static void main(String argss[]){  
	ArrayList<Fruit> myList = new ArrayList<Fruit>();  
	myList.add(new Fruit(3, "grape"));  
	myList.add(new Fruit(1, "pineaple"));  
	myList.add(new Fruit(2, "lemon"));  
	myList.add(new Fruit(5, "orange"));  
	myList.add(new Fruit(6, "pear"));  
	myList.add(new Fruit(4, "watermellon"));  
	myList.add(new Fruit(7, "mango"));  
	  
	  
	  
	String html = null;  
	  
	Collections.sort(myList,Fruit.fruitOredered);
	Collections.sort(myList,Fruit.fruitidOredered);
	for (Fruit fruit : myList) {
		System.out.println(fruit.getID() + "	" + fruit.getName());		
	}
	//html = myList.toString();  
	//System.out.println(html);  
	  
	//Reverse order  
	/*Collections.sort(myList,Fruit.ReversedComparator);  
		for (Fruit fruit : myList) {
			System.out.println(fruit.getName());
		}*/
	}  
	  
	//Let this be one of your business objects  
	public static class Fruit implements Comparable<Fruit>{  
	  
		public static Comparator<Fruit> fruitOredered; 
		public static Comparator<Fruit> fruitidOredered; 
		
		public static Comparator<Fruit> ReversedComparator;  
		static{  
			fruitOredered= new FruitComparator();
			fruitidOredered = new FruitIdComparator();
			ReversedComparator = Collections.reverseOrder(fruitOredered);  
		}  
		private int id;  
		private String name;  
		  
		public Fruit(int id, String name){  
			this.id = id;
			this.name = name;  
		}  
		  
		public int getID(){  
		return id;  
		}  
		  
		public String getName(){  
		return name;  
		}    
		
		   
		public int compareTo(Fruit obj0) {  
			int result;
			
			result = this.getName().compareTo(obj0.getName());
			return result;
		}  
		  
	}  
	  
		public static class FruitComparator implements Comparator<Fruit>{  
		   
		public int compare(Fruit obj1, Fruit obj2) {  
			return obj1.compareTo(obj2);  
			}  
		}
		
		public static class FruitIdComparator implements Comparator<Fruit>{  
			   
			public int compare(Fruit obj1, Fruit obj2) {  
				return obj1.getID() - obj2.getID();  
				}  
			}
	} 