package com.test;

import java.util.Calendar;

public class TdmLogValsTemp implements Comparable<TdmLogValsTemp> {

	Calendar mTime;
	String mColName;
	double mValue;
	
	public TdmLogValsTemp(Calendar time, String colName, double val)
	{
		mTime = time;
		mColName = colName; 
		mValue = val;
	}
	
	public int compareTo(TdmLogValsTemp tdmLog)
	{
		return getMtime().compareTo(tdmLog.getMtime());
	}
	
	public Calendar getMtime()
	{
		return mTime;
	}
}
