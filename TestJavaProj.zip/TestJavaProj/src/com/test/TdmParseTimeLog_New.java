package com.test;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintStream;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class TdmParseTimeLog_New {

	String[] arrColumnNames = {"Date", "C00", "C10", "C20", "C30", "C40", "J10", "J14", "J20", "J30", "J40", "J50", "D10", "D20", "D30", "D40", "D50", "D60", "D70", "D90", "D93", "D80", "D96", "Status"};// to store all column names
	
	static String[] arrTemp = null;
	
	static final String C_LOG = "TimeLog : END"; // constant to parse the C-Log
		
	static final int time_delay = 0;
	
	public class TdmLogVals implements Comparable<TdmLogVals> {

		Calendar mTime;
		String mColName;
		double mValue;
		
		public TdmLogVals(Calendar time, String colName, double val)
		{
			mTime = time;
			mColName = colName; 
			mValue = val;
		}
		
		public int compareTo(TdmLogVals tdmLog)
		{
			return getMtime().compareTo(tdmLog.getMtime());
		}
		
		public Calendar getMtime()
		{
			return mTime;
		}
	}
	
	public static void main(String[] args)
	{
		TdmParseTimeLog_New worker = new TdmParseTimeLog_New();
		if(args.length == 2){
			worker.process(args[0], args[1]);
		}
		else{
			System.out.println("Please pass the args :: LOG_FILE_PATH and OUTPUT_CSV_PATH");
		}
	}
	
	public void process(String logFile, String outFile)
	{
		String line = null;		
		String date = "", time = "", col = "", val = "";
		ArrayList<TdmLogVals> allRecords = new ArrayList<TdmLogVals>();
		SimpleDateFormat tmFmt = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
		SimpleDateFormat dtFmtJ = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
		//SimpleDateFormat dtFmtC = new SimpleDateFormat("HH:mm:ss yyyy-MM-dd", Locale.getDefault());
		SimpleDateFormat dtFmtOut = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss", Locale.getDefault());
		PrintStream printStm = null;
		String dtLog = null;
		try
		{
			//read the log file
			BufferedReader bufRd = new BufferedReader(new FileReader(logFile));
			while((line = (bufRd.readLine())) != null){
				Calendar cal = Calendar.getInstance();
				date = "";
				time = "";
				col = "" ;
				val = "";
				if(line.indexOf(C_LOG) > 0){
					//C log
					String cols[] = line.split(",");					
					String fvals[] = cols[0].split(" ");					
					date = fvals[1] + " " + fvals[0];					
					col = cols[2];
					val = cols[3];					
					cal.setTime(dtFmtJ.parse(date));
					if(time_delay != 0)
						cal.set(Calendar.MINUTE, cal.get(Calendar.MINUTE) + time_delay);
				}
				else{
					//Java 
					String cols[] = line.split(",");	
					if(cols.length == 4){
						Date dt = dtFmtJ.parse(cols[1]);	
						dtLog = dt.toString();						
						cols[1] = tmFmt.format(dt).toString();
						date = cols[1];
						col = cols[2];
						val = cols[3];
						cal.setTime(dt);						
					}
					else{
						System.out.println("Unable to process the line :: " + cols[0]);
						continue;
					}
				}				
				TdmLogVals tdmVals = new TdmLogVals(cal, col, Double.parseDouble(val));					
				allRecords.add(tdmVals);
			}
			Collections.sort(allRecords);
			
			printStm = new PrintStream(new FileOutputStream(outFile));//create the file
			
			// Write the column names to the file
			for(int j = 0; j <= arrColumnNames.length - 1; j++){
				if(j<(arrColumnNames.length-1)) 
					printStm.print(arrColumnNames[j] + ",");
				else
					printStm.print(arrColumnNames[j]);
			}
			
			Map<String, String> record_data = null;
			
			for (TdmLogVals tdmLogVals : allRecords) {
				
				if(tdmLogVals.mColName.equals("C10"))
				{
					if(record_data != null) {						
						printStm.println();						
						printStm.print(dtLog + ",");
						writeRecord(printStm, record_data);
					}
					record_data = new HashMap<String, String>();
				}				
				dtLog = dtFmtOut.format(tdmLogVals.mTime.getTime());
				if(record_data != null)
					record_data.put(tdmLogVals.mColName, String.valueOf(tdmLogVals.mValue));
			}
		}
		catch(FileNotFoundException fileEx)		{
			System.out.println("File not found : " + fileEx);
		}
		catch(Exception e)
		{
			System.out.println(" Error : " + e);
		}
	}

	private void writeRecord(PrintStream printStm, Map<String, String> record_data) 
	{
		String testStatus = "PASS";
		for (int i = 1; i < arrColumnNames.length ; i++)
		{
			String val = record_data.get(arrColumnNames[i]);			
			if(val == null){//insert space if the value is null
				val = "";
				if(!arrColumnNames[i].equals("D40") && i < arrColumnNames.length - 1)
					testStatus = "FAIL";
			}
			if(i<(arrColumnNames.length - 1)) 
				printStm.print(val+",");
			else 
				printStm.print(testStatus);
		}		
	}
}
