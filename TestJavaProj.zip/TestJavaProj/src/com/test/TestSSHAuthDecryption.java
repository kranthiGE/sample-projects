package com.test;

//import java.util.Arrays;
import javax.xml.bind.DatatypeConverter;

import java.security.KeyFactory;
import java.security.NoSuchProviderException;
import java.security.Signature;
import java.security.SignatureException;
import java.security.NoSuchAlgorithmException;
import java.security.InvalidKeyException;

import sun.security.rsa.RSAPublicKeyImpl;
//import sun.security.dsa.DSAPublicKeyImpl;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

// these are used only in verifySignature_testing()
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.EncodedKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.security.spec.X509EncodedKeySpec;


/**
 * @author Yasen Hristov
 *
 */
public class TestSSHAuthDecryption {
	
	static private boolean DEBUG = true;
	
	public TestSSHAuthDecryption(byte[] data) {
		m_arrAuthData = data;
		printByteArr(m_arrAuthData, "Input> ");
	}
	
	public TestSSHAuthDecryption(String data) {
		m_arrAuthData = base64decode(data);
		printByteArr(m_arrAuthData, "Input> ");
	}
	
	public static byte[] base64decode(String data) {
		//return javax.xml.bind.DatatypeConverter.parseBase64Binary(data);
		return javax.xml.bind.DatatypeConverter.parseBase64Binary(data);
	}
	
	public static String base64encode(byte[] arr, int index, int len) {
		//byte[] data = Arrays.copyOfRange(arr, index, index+len);
		byte[] data = new byte[len];
		System.arraycopy(arr, index, data, 0, len);
		//System.err.println("DEBUG: New arr len is [" + data.length + "]");
		return javax.xml.bind.DatatypeConverter.printBase64Binary(data);
	}
	
	public static void printByteArr(byte[] arr, String header) {

		if ( ! DEBUG ) return;
		
		System.err.print(header + "Byte Array Len is [" + arr.length + "]; Byte values: [");
		for (byte a : arr) {
			System.err.print( Integer.toHexString(0xFF & a) );
			System.err.print(' ');
		}
		System.err.println("]");
	}
	
	public static void writeByteArrToFile(byte[] arr, String fName) 
		throws IOException 
	{
		DataOutputStream os = new DataOutputStream(new FileOutputStream(fName));
		try {
			os.write(arr);
		} finally {
			os.close();
		}
	}
	
	public static byte[] readByteArrFromFile(String fName) 
		throws IOException 
	{
		File f = new File(fName);
		int fLen = (int) f.length();
		byte[] arr = new byte[fLen];
		
		DataInputStream is = new DataInputStream(new FileInputStream(f));
		try {
			is.read(arr);
		} finally {
			is.close();
		}
		
		return arr;
	}	
	
	private byte[] m_arrAuthData = null;
	private int m_nIndex = 0;
	
	protected short readByte() {
		short result = (short) (0xFF & ((short)m_arrAuthData[m_nIndex]));
		m_nIndex++;
		return result;
	}
	
	protected long readInt32() {
		short b1 = readByte();
		short b2 = readByte();
		short b3 = readByte();
		short b4 = readByte();
		
		return ((long) (b1 | b2 << 8 | b3 << 16 | b4 << 24)) & 0xFFFFFFFFL;
	}
	
	/// this method will read an 
	protected int readInt32WithChecks(String fieldName) throws Exception {
		// first read the length value
		// it should be a 32-bit int
		long len = readInt32();

		// zero length should never be there
		if ( len <= 0 )
			throw new Exception("ERR1702: Bad len for field [" + fieldName + "]");
		
		// do some sanity checks
		//  a. This value cannot exceed the total array lenght
		//  b. This value should not be beyond the array boundary
		//   I think actually a check for a. is not needed, since it is a subset of b.
		long arr_len_left = m_arrAuthData.length - m_nIndex;
		if ( len > arr_len_left ) 
			throw new Exception("ERR1702: Bad len for field [" + fieldName + "]");
		
		if ( len > 5000 )
			throw new Exception("ERR1703: Bad len for field [" + fieldName + "]");
		
		return (int) len;
	}
	
	protected String readString(String fieldName) 
		throws Exception
	{
		int len = readInt32WithChecks(fieldName);
		if ( DEBUG ) System.err.print("DEBUG: Reading string [" + fieldName + "]: Len is " + len);
		
		// now read LEN bytes from the buffer (into a string)
		String result = new String(m_arrAuthData, m_nIndex, len, "ISO-8859-1");
		m_nIndex = m_nIndex + len;
		
		if ( DEBUG ) System.err.println("; Value is [" + result + "]");
		return result;
	}
	
	protected byte[] readByteArray(String fieldName)
		throws Exception
	{
		int len = readInt32WithChecks(fieldName);		
		byte[] result = new byte[len];
		System.arraycopy(m_arrAuthData, m_nIndex, result, 0, len);
		m_nIndex = m_nIndex + len;
		return result;
	}
	
	private String m_sSessionID;
	// byte      SSH_MSG_USERAUTH_REQUEST
	private String m_sUserName;
	// string    service name		"ssh-userauth".
	// string    method name		"publickey"
	// boolean   TRUE
	private String m_sPKAlgorithmName;
	private byte[] m_arrPK;
	
	public String getSessionID() { return m_sSessionID; }
	public String getSSO() { return m_sUserName; }
	public String getPKAlgorithmName() { return m_sPKAlgorithmName; }
	public byte[] getPK() { return m_arrPK; }
	public String getPKAsString() { return base64encode(m_arrPK, 0, m_arrPK.length); }
	
	public void printValues() {
		System.out.println("Session ID: [" + getSessionID() + "]");
		System.out.println("SSO: [" + getSSO() + "]");
		System.out.println("PK algorithm name: [" + getPKAlgorithmName() + "]");
		System.out.println("Public key: [" + getPKAsString() + "]");
	}
	
	public void parse()
		throws Exception
	{
		m_nIndex = 0;
		
		/// 1. string    session identifier
		m_sSessionID = readString("Session ID");
		// TODO: Should there be validation that this string is a real UUID value?
		
		/// 2. byte      SSH_MSG_USERAUTH_REQUEST
		// the value for SSH_MSG_USERAUTH_REQUEST is 50 (or 0x32)
		short pcktType = readByte();
		if ( 0x32 != pcktType ) 
			throw new Exception("ERR1710: Bad packet type.");
		
		/// 3. string    user name
		m_sUserName = readString("User name");

		/// 4. string    service name		"ssh-userauth".
		String sServiceName = readString("service name");
		if ( 0 != sServiceName.compareTo("ssh-userauth")  )
			throw new Exception("ERR1711: Bad service name.");

		/// 5. string    method name		"publickey"
		String sMethodName = readString("method name");
		if ( 0 != sMethodName.compareTo("publickey")  )
			throw new Exception("ERR1712: Bad method name.");
		
		/// 6. boolean   TRUE
		short bConst = readByte();
		if ( 1 != bConst  )
			throw new Exception("ERR1713: Bad const TRUE.");
		
		/// 7. string    public key algorithm name	"ssh-rsa"
		m_sPKAlgorithmName = readString("Public key algorithm name");
		if ( 0 != m_sPKAlgorithmName.compareTo("ssh-rsa") && 0 != m_sPKAlgorithmName.compareTo("ssh-dsa") )
			throw new Exception("ERR1714: Bad public key algorithm name.");		
		
		/// 8. string    public key to be used for authentication
		m_arrPK = readByteArray("Public key");
		
		// The remaining of the buffer is the digest signature
		// do NOT touch input_data or index

		// DEBUG only
		if ( DEBUG ) {
			//byte[] sign = Arrays.copyOfRange(input_data, index, input_data.length);
			byte[] sign = new byte[m_arrAuthData.length - m_nIndex];
			System.arraycopy(m_arrAuthData, m_nIndex, sign, 0, sign.length);		
			printByteArr(sign, "Digest signature> ");
			
			// the content of effectively ${SIGN_FILE}.in is:
			//byte[] signIn = Arrays.copyOfRange(input_data, 0, index);
			byte[] signIn = new byte[m_nIndex];
			System.arraycopy(m_arrAuthData, 0, signIn, 0, signIn.length);
			printByteArr(signIn, "Sign input> ");
		}
		
	}
	
	void verifySignature_testing(byte[] signature_data) 
		throws InvalidKeyException, NoSuchAlgorithmException, SignatureException 
	{
		
		RSAPublicKeyImpl pub = new RSAPublicKeyImpl( m_arrPK );
	
/*		
		KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
		kpg.initialize(2048);
		KeyPair kp = kpg.genKeyPair();
		PublicKey pub = kp.getPublic();
		if ( DEBUG ) {
			System.err.println("DEBUG: PK algorithm is " + pub.getAlgorithm() );
			System.err.println("DEBUG: PK format is " + pub.getFormat() );
			byte[] pubV = pub.getEncoded();
			printByteArr( pubV, "DEBUG: PK value is " );
			writeByteArrToFile(pubV, "test.pub");
		}
*/		
///		byte[] pubV = readByteArrFromFile("test.pub");
///		RSAPublicKeyImpl pub = new RSAPublicKeyImpl( pubV );

		
		//Signature signature = Signature.getInstance("SHA1withRSA", "BC");
		Signature signature = Signature.getInstance("MD5withRSA");
		signature.initVerify( pub );
		signature.update(m_arrAuthData, 0, m_nIndex);
		boolean bOK = signature.verify(signature_data);
		System.out.println("Signature verifies OK?: " + bOK);
	}	
	
	public boolean verifySignature()
		throws InvalidKeyException, NoSuchAlgorithmException, SignatureException, InvalidKeySpecException
	{
/*
		// load the public key
		KeyFactory keyFactory = KeyFactory.getInstance("DSA");
		RSAPublicKeySpec bobPubKeySpec = new RSAPublicKeySpec( base64decode(m_sPublicKey) );
		PublicKey pub = keyFactory.generatePublic(bobPubKeySpec);
*/		
		
		PublicKey pub;
		if ( 0 == m_sPKAlgorithmName.compareTo("ssh-rsa") )
			pub = new RSAPublicKeyImpl( m_arrPK );
		else
			throw new SignatureException("ERR1721: Only ssh-rsa PK algorithm implemented so far.");
		
		Signature signature = Signature.getInstance("MD5withRSA");
		signature.initVerify( pub );
		signature.update(m_arrAuthData, 0, m_nIndex);
		
		byte[] signature_data = new byte[m_arrAuthData.length - m_nIndex];
		System.arraycopy(m_arrAuthData, m_nIndex, signature_data, 0, signature_data.length);			
		
		return signature.verify(signature_data);
	}	

	/**
	 * @param args
	 */
	public static void main(String[] args)
		throws Exception
	{
		//String data = args[0];
		//
		//String data = "JAAAADAwQkIyOEU4LTYzRjgtNEJFQS05NENDLThFODQyNTQ1Q0I1RDIJAAAAMjEwMDU3MDcwDAAAAHNzaC11c2VyYXV0aAkAAABwdWJsaWNrZXkBBwAAAHNzaC1yc2EVAQAAAAAAB3NzaC1yc2EAAAABJQAAAQEAphd8RHxHjLcU0rrfOy5j3joy5X+4uG5Bb1JQo2mStoAtvUa47a2xdDNWpC+7h67WFegqXLGAcdSEjhxPB/hKvErjRip2xAiTLgq54PPXfGH7pScko73BfywuEisY9F87xuJoLREor2jw/7W/EF8j86KCrK9YI2YHTcY4gK7NQ2wopuqzrz8wzfCPlWKDzWRbatAjRBIue+TlR2Axq8RKrTOaRippJcVyZSZyUT6mQ6xK20MYQq//P9766AKTcMd3W1XwxGsRoFz9wS6s3+Alg49B16pJv4OcGeWQm7/tca+5oQC0LSoTqEfLD+YegJa3iX5uqed6+IYfQdQL8krI2RM2Sp9pxqjh3370LdMiHTkn+lYBSGoNXgQQgKlxe3roEgtGdAsle5jh76ZhMn//eP8aj9kghtbYO4/jcZkoe9BukL5wd59YTCBoPJbPk4Kz0Y8nTdftKUDCU4YZZEqVnJshcrEWFlRbkPAel2jVGwdqiE+YqB4kXFXuTewNfMp0P0mQaQ3azMduQoDwAHIW2OBTWhI04njdH/NwsmgxZJLZSHxX3yYuZvqKAvG0i8Gce1f3oCbCAH1a4Z1ILfhDGO1GfuM/IyDMw2nIKBwIxPfbmBlfzbswy+QUkMiSEFgZh4qFlwp7rj8bfOyBcHVYMh5T0/cVNZTB8ANVrRu897M=";
		String data = "JAAAADE3MkYxNDM5LTA4NzMtNEREQy05RjVELUFFQjhENjFDRDA2MDIJAAAAMjEwMDU3MDcwDAAAAHNzaC11c2VyYXV0aAkAAABwdWJsaWNrZXkBBwAAAHNzaC1yc2EkAQAAMIIBIDANBgkqhkiG9w0BAQEFAAOCAQ0AMIIBCAKCAQEAphd8RHxHjLcU0rrfOy5j3joy5X+4uG5Bb1JQo2mStoAtvUa47a2xdDNWpC+7h67WFegqXLGAcdSEjhxPB/hKvErjRip2xAiTLgq54PPXfGH7pScko73BfywuEisY9F87xuJoLREor2jw/7W/EF8j86KCrK9YI2YHTcY4gK7NQ2wopuqzrz8wzfCPlWKDzWRbatAjRBIue+TlR2Axq8RKrTOaRippJcVyZSZyUT6mQ6xK20MYQq//P9766AKTcMd3W1XwxGsRoFz9wS6s3+Alg49B16pJv4OcGeWQm7/tca+5oQC0LSoTqEfLD+YegJa3iX5uqed6+IYfQdQL8krI2QIBJTdr/1XWqCp6yL8jREzvU8t3uCPXsWcGP0r1PrSgJG6R/ZhdjE1wB/T45M6+AapuVbgt1Q9vvSZqIXb5arOU6qoodYWblFIUFr+JuNq8MQhV91w6CZnjVEsRHdNCDXJk8nYoX6/Sy5BHwBD0xujd1trB8uWljT44UN82nuwalHZ6eOj42IbZK/zY1bjrpRk50i9aOkwDVetto6588bMfYURIj25xJvTfo9aMONyQ/6Fa5PtcdBHOsKEqH2dakgagUlmK2EMovwPzT7MVvHcWw6+ZLm0lBVEs5NLslN9zzjxklhSHuRSDHytzHy5eYkLxTFfKw41W3iGHqZgTWBecAnE=";
		
		TestSSHAuthDecryption t = new TestSSHAuthDecryption(base64decode(data));
		t.parse();
		t.printValues();
		boolean bOK = t.verifySignature();
		System.out.println("Signature verifies OK?: " + bOK);
		
		// TODO: Throw exception if false == bOK
		// TODO: Throw exception if t.getPublicKey() does not match the value present in the database for this getSSO()
		// TODO: Insert a new record with t.getSSO() and t.getSessionID(). Let Teradata throw an exception if there is a violation of the primary key
	}

}
