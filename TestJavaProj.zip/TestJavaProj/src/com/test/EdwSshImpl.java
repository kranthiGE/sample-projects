package com.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.net.Socket;
import java.net.UnknownHostException;
/*
import com.sshtools.j2ssh.agent.AgentNotAvailableException;
import com.sshtools.j2ssh.agent.KeyStore;
import com.sshtools.j2ssh.agent.SshAgentConnection;
import com.sshtools.j2ssh.agent.SshAgentSocketListener;
*/
public class EdwSshImpl {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		trialSshClient();
		
	}
	public static void trialSshClient(){
		
		/*try{
		
			SshAgentSocketListener sshage = new SshAgentSocketListener("127.0.0.1:4944", new KeyStore());
			
		
			System.out.println("test");
		}
		catch(AgentNotAvailableException ioEx){
			System.out.println(ioEx);
		}
		finally{
						
		}*/
	}
	
	
	public void trialSocket()
	{		
		BufferedReader rd = null;
		InputStreamReader inp = null;
		try
		{
			Socket soc = new Socket("127.0.0.1", 4944);			
			soc.sendUrgentData(11);			
			inp = new InputStreamReader(soc.getInputStream());			
			rd = new BufferedReader(inp);
			System.out.println("ts");
			/*pw.write("11");
			pw.flush();
		*/	
			System.out.println("test" + rd.read());
		}
		catch(UnknownHostException uex){
			System.out.println(uex);
		}
		catch(IOException IEx){
			System.out.println(IEx);
		}
		finally
		{
			try
			{
				if(rd != null)
					rd.close();
				if(inp != null)
					inp.close();
			}
			catch(IOException IEx){
				System.out.println(IEx);
			}
		}
	}

}
