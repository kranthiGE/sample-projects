package com.test.readedw;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

public class DbUtil {

	
	public static void release(final Connection con) throws SQLException {
        release((Statement[])null, (ResultSet[])null, con);
	}

	public static void release(final ResultSet... res) throws SQLException {
	        release(null, res, null);
	}

	public static void release(final Statement[] stmt) throws SQLException {
	        release(stmt, null, null);
	}

	public static void release(final Statement stmt, final ResultSet... res) throws SQLException {
	        release(stmt == null ? null : new Statement[] { stmt }, res, null);
	}
	
	public static void release(final Statement stmt, final ResultSet resultSet, final Connection conn) throws SQLException {
	        release(stmt == null ? null : new Statement[] { stmt },
	                resultSet == null ? null : new ResultSet[] { resultSet }, conn);
	}
	
	public static void release(final Statement[] stmt, final ResultSet[] resultSet) throws SQLException {
	        release(stmt, resultSet, null);
	}

		public static void release(final Statement[] stmt, final ResultSet[] resultSet, final Connection conn) throws SQLException {
		
		        SQLException error = null;
		
		try {
				if (resultSet != null) {
			                        for (ResultSet res : resultSet) {
			                                try {
			                                        if (res != null) {
			                                                res.close();
			                                        }
			                                        
			                                } catch (SQLException e) {
			                                        error = e;
			                                        System.err
															.println("Result set failed to close" + e);
			                                }
			                        }
			                }
		        } finally {
		                try {
							if (stmt != null) {
								for (Statement st : stmt) {
								        try {
								                if (st != null) {
								                        st.close();
								                }
								        } catch (SQLException e) {
								                error = e;
								                System.err
												.println("Statement failed to close"+ e);
								}
								                }
			                 }		                
		                } finally {
		                    try {
								if (conn != null) {
									conn.close();
								}
								                    } catch (SQLException e) {
								                            error = e;
								                            System.err
																	.println("Connection failed to close"+ e);
								}
		                }
		        	}
		
		        if (error != null) {
		                throw error;
		        }
		}
		
		/**
		 * @Description to exeucte the protegrity query band
		 * @param connection
		 * @catch SQLException
		 */
	    public static synchronized void executeQueryBand(Connection connection)
		throws SQLException
		{
				String protegrityQry = "SET QUERY_BAND='PROXYUSER= AFNTDMQ;' FOR SESSION";
				Statement tmpSt = null;
				try {
					tmpSt = connection.createStatement();                                
					tmpSt.executeUpdate(protegrityQry);
					release(tmpSt);

				} finally {
					release(tmpSt);
				}			
		}
	    
	    
	    /**
		 * @return
		 * @throws TdmDataAccessException
		 *             getConnection -This getConnection method is used to get
		 *             Connection to Data base.
		 */
		public static Connection getConnection(){
			Connection conn = null;
			try {   
				final String driverName = "com.teradata.jdbc.TeraDriver";
				final String url = "jdbc:teradata://GEITDQA.ae.ge.com";
				final String dbUserid = "GEADW_TDM_EXPORT_WEB";
		  		//decPassword = "geadw00export11web"; //DEV
				Class.forName(driverName);
				conn = DriverManager
	                    .getConnection(url, dbUserid, "geadw22export10qa");                        

			} 
			catch (ClassNotFoundException cEx) {			
				System.err.println("error in getConnection :: ClassNotFoundException - " + cEx);
			}
			catch (SQLException e) {			
				System.err.println("error in getConnection" + e);
			}
			
			return conn;
		}
	    

		/*public static void executeQuery(String query,Connection con, Map<String, ResultSet> returnmap, String rsName) {
			PreparedStatement stateMacro = null;
			ResultSet rset = null;		
			try {			
				stateMacro = con.prepareStatement(query, ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
				
				rset = stateMacro.executeQuery();
			} catch (SQLException ex) {
				System.err.println("Exception in DBDataQueriesDao : executeQuery :"	+ ex);			
			}		
			returnmap.put(rsName, rset);
		}*/
		
}
