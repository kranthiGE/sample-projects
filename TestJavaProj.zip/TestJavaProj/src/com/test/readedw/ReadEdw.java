package com.test.readedw;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import java.io.PrintWriter;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.HashMap;
import java.util.Map;


public class ReadEdw {

	public static int MAX_COUNT = 300;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Max memory (in KB): " + Runtime.getRuntime().maxMemory()/1000.0);
		ReadEdw edw = new ReadEdw();
		edw.processRecords(getCsvStream());
	}
	
	private void processRecords(FileOutputStream fos){		
		StringBuilder out = new StringBuilder();
		Connection con = null;
		Map<String, ResultSet> rsMap = null;
		PrintWriter pwriter = null;
		ResultSet keysResultset = null;
		PreparedStatement stateMacro = null;
		try{
		con = DbUtil.getConnection();
		rsMap = executeReadQueries(con, stateMacro);
		pwriter = new PrintWriter(new BufferedOutputStream(fos));
		keysResultset = rsMap.get("keysRs");
		int count = 0;
		if(keysResultset != null){
			while(keysResultset.next()){ // keys related result set.
				out.setLength(0);
				for(int i=1;i<keysResultset.getMetaData().getColumnCount();i++){
					out.append(keysResultset.getString(i)).append(",");
				}				
				//pwriter.println(out.toString());
				
				if(count%30 == 0){					
					pwriter.println("count:: " + count + "free memory (in KB): " + Runtime.getRuntime().freeMemory()/1024.0);
				}
				pwriter.flush();	
				count++;
				if(count > MAX_COUNT)
					break;
				
			}
		}
		}catch (SQLException e) {
			System.err.println(e);
		}
		catch(Exception ex){
			System.err.println(ex);
		}
		finally{
			if(pwriter != null)
				pwriter.close();
			try{
				if(stateMacro != null)
					DbUtil.release(stateMacro);
				if(keysResultset != null)
					DbUtil.release(keysResultset);
				if(con != null)
					con.close();
			}
			catch (SQLException e) {
				System.err.println(e);
			}
		}
	}
	
	public Map<String, ResultSet> executeReadQueries(Connection con, PreparedStatement stateMacro){
		Map<String, ResultSet> returnMap =  new HashMap<String, ResultSet>();
		/*String keysQry = "SELECT	TEST_ID, TEST_ITEM_TYPE_ID, MEASUREMENT_NUM, TEST_READING_NUM,"
		+ "TEST_FACILITY_LOC_ID, TEST_DATATYPE_TEXT, TEST_TYPE_OF_DATA_TEXT," +
				"TEST_TYPE_CD, ETDS_SET_ID, LOGICAL_DELETE_IND, JOB_CONTROL_ID," +
				"EXTRACT_STATUS, FILE_NAME, LAST_UPDATED_DT, RELEASE_IND, TEST_READING_TYPE_CD," +
				"		TEST_RESULT_RATING_VALUE, ENGINE_SERIAL_NUM, STATUS, ENGINE_POS," +
				"		TEST_METHOD, VEHICLE_TYPE, ANALYSIS_NUM, POWERSET_VALUE, ITEM_MODEL_CD," +
				"		JNUM, FILE_DATA_IND, FLEET_NAME, AIRCRAFT_TAIL_NUM, AIRCRAFT_TYPE_NAME," +
				"		FLIGHT_NUM" +
				" FROM	GEADW_TDM_V.TEST";*/
		String keysQry = "SELECT	TEST_ID, PARAMETER_ID, TEST_READING_NUM, TEST_PARAM_RESULT_SCAN," +
				"	TEST_PARAM_RESULT_VALUE, TEST_PARAM_RESULT_ASCII, TEST_PARAM_RESULT_INTEGER," +
				"		TEST_PARAM_RESULT_HEX, TEST_PARAM_RESULT_EXCEPN_HEX, TEST_PARAM_RESULT_TYPE_CD," +
				"		VALUE_RESULT_UOM_CD, LOGICAL_DELETE_FLAG, JOB_CONTROL_ID" +
				" FROM	GEADW_TDM_V.TEST_READING_SS";
		
		ResultSet rset = null;		
		try {			
			stateMacro = con.prepareStatement(keysQry, ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
			
			rset = stateMacro.executeQuery();
		} catch (SQLException ex) {
			System.err.println("Exception in DBDataQueriesDao : executeQuery :"	+ ex);			
		}
		returnMap.put("keysRs", rset);
		return returnMap;		
	}
	
	private static FileOutputStream getCsvStream(){
		File dir = null;
		FileOutputStream fos =  null;
		try{
			dir = new File("C:\\Users\\nggmnvq\\TDM\\test\\test.csv");
			fos = new FileOutputStream(dir);
		}
		catch (FileNotFoundException e) {
			System.err.println(e);
		}
		return fos;
		
	}
	
	

	
}
