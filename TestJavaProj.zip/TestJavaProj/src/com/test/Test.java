package com.test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.lang.reflect.Array;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Test {

		
	/**
	 * @param args
	 */
	static int row = 8;
	static int col = 8;
	static int n = 0;
	static ArrayList<String> alist_files = new ArrayList<String>();
	static String dirPath = "D:/Users/NGGMNVQ/Project_code/EDWRegTestSuite/EDWC/";
	
	private static String getdtYYYYMMDDHHSS(String str){
		SimpleDateFormat dtFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		DateFormat dtSource = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dt = null;
		try{
			dt = dtFormat.format(dtSource.parse(str));
		}
		catch(ParseException ex){}
		return dt;
	}
	
	public static String arraytoString(Object[] a) {
		if (a == null || a.length == 0)
            return "null";         
        StringBuilder buf = new StringBuilder();
 
        for (int i = 0; i < a.length; i++) {
            if (i == 0)
                buf.append('(');
            else
                buf.append(","); 
            buf.append(String.valueOf(a[i]));
        } 
        buf.append(")");
        return buf.toString();        
    }
	
	private static void expandRanges(int st, int end){
		
		for (int i=st; i<= end ; i++) {
			System.out.print(i + ",");
		}
	}
	
	private static void arrayToString(){
		String[] str = {"1", "2", "3", "4", "5", "6"};
		System.out.println(arraytoString(str));
	}
	
	public static void main(String[] args) {
	
		System.out.println(getdtYYYYMMDDHHSS("2013-09-20 12:09:21"));
		//expandRanges(5001, 5293);
		//arrayToString();
		//getListFromMap();
		//appendViewAliasName("TD.TEST, TD.RDG, TD.SCANNUMBER, TD.ESN, TD.ANALYNUM, DATATYPE, JNUM, RATING,TESTDATE, STORDATE, TEST_ID", "A");
		// TODO Auto-generated method stub
		//System.out.println(isValidContent("", "(1-3)"));
		//n = row * col;
		//printNums();
		//Add CSV files that need comparison from 
		//edwc_basic.rtc
		/*alist_files.add("qa_ss_nm_9880.csv");
		alist_files.add("qa_ss_nm_9880.v.csv");
		alist_files.add("qa_ss_nm_9880.x.csv");
		alist_files.add("qa_tr_nm_9880_scan.csv");
		alist_files.add("qa_tr_nm_9880_scan.v.csv");
		alist_files.add("qa_ss_nm_9880_nokeys.csv");
		alist_files.add("qa_ss_nm_9880_nokeys.v.csv");
		alist_files.add("qa_ss_nm_9880_somekeys.csv");
		alist_files.add("qa_ss_nm_9880_somekeys.v.csv");
		alist_files.add("qa_ss_nm_9880_param_filter.csv");
		alist_files.add("qa_ss_nm_9880_param_filter.v.csv");
		alist_files.add("qa_ss_nm_9880_storedate_range.csv");
		alist_files.add("qa_ss_nm_9880_storedate_range.v.csv");
		alist_files.add("qa_ss_nm_9880_test_rdg_scan_range.csv");
		alist_files.add("qa_ss_nm_9880_qc_804.csv");
		alist_files.add("qa_ss_nm_9880_qc_877.csv");
		alist_files.add("qa_ss_nm_9880_qc_936.csv");
		alist_files.add("qa_ss_nm_9880_qc_909_rdg.csv");
		alist_files.add("qa_ss_nm_9880_ignorecase.csv");
		compareCSVfiles(args);*/
	}
	
	private static void getListFromMap(){
		Map<String, String> staticMap = new HashMap<String, String>();
		staticMap.put("f1.h5", "/ldm/2012.h5");
		staticMap.put("f2.h5", "/ldm/2013.h5");
		staticMap.put("f3.h5", "/ldm/2014.h5");
		staticMap.put("f4.h5", "/ldm/2015.h5");
		staticMap.put("f5.h5", "/ldm/2016.h5");
		Set<String> fileSet = staticMap.keySet();
		List<String> list = new ArrayList<String>();
		list.addAll(fileSet);
		Collections.sort(list);
		for (String str : list) {
			System.out.println(str);
		}
		
	}

	private static String appendViewAliasName(String strSQLqry, String aliasName){
		StringTokenizer st = new StringTokenizer(strSQLqry, ",", true);
		StringBuilder sqlQry = new StringBuilder();
		while (st.hasMoreTokens()) {
			String token = st.nextToken().trim();
			if (token.length() == 0 || token.equals(",")) {
				continue;
			}
			if(token.contains("."))
				token = token.substring(token.indexOf('.') + 1, token.length());			
				sqlQry.append(aliasName).append(".").append(token).append(", ");
		}
		return sqlQry.toString();
	}
	
	public static void printNums()
	{
		for(int i = row; i <= n; i--){
			System.out.print(n-i);
			System.out.print("\t");
		}
	}
	
	/**
	 * @param fname
	 * @param fvalue
	 * @return
	 */
	private static boolean isValidContent(String fname, String fvalue) {
		boolean flag = false;
		Pattern pattern;
		Matcher matcher;
		String regEx = "";

		//regEx = "^[\\da-zA-Z-/_,\\s<>()]{1,}$";
		regEx = "^[\\d-,\\s()]{1,}$";
		pattern = Pattern.compile(regEx);
		matcher = pattern.matcher(fvalue.toUpperCase());
		if (matcher.find()) {
			flag = true;
		}
		return flag;
	}
	
	public static void compareCSVfiles(String[] args)
	{
		String line1, line2 = null;
		int rowCount = 0;
		boolean isFail = false;
			try
			{
				for (String strFilePath : alist_files) {
					BufferedReader bufFile1 = new BufferedReader(new FileReader(dirPath + "WorkDir//" + strFilePath));
					BufferedReader bufFile2 = new BufferedReader(new FileReader(dirPath + "Ref//" + strFilePath));
					
					while(true){	
						rowCount ++;
						line1 = (bufFile1.readLine());
						line2 = (bufFile2.readLine());
						if(line1 == null || line2 == null)
						{							
							if(isFail)
								System.out.println("File: " + strFilePath + " FAIL" );
							else
								System.out.println("File: " + strFilePath + " PASS" );
							System.out.println("***************************");
							isFail = false;
							break;
						}
						String line1Cols[] = line1.split(",");
						String line2Cols[] = line2.split(",");
						if(line1Cols.length != line2Cols.length){
							System.out.println("lines are not equal in " + strFilePath);
							System.out.println(line1);
							System.out.println(line2);
							break;
						}
						if(rowCount != 1){
							for(int i = 19; i < line1Cols.length;i++) {
								
								if(!line1Cols[i].equals("") && !line2Cols[i].equals("")){
									
									try{
									  double entry1 = Double.parseDouble(line1Cols[i]);
									  double entry2 = Double.parseDouble(line2Cols[i]);
									 // double average = (entry1 + entry2) / 2;
									  double relativeError;
									  if(entry1 == entry2){									  
										  continue;
									  }
									  else{
									    if (Math.abs(entry2) > Math.abs(entry1))
									        relativeError = Math.abs((entry1 - entry2));
									    else
									        relativeError = Math.abs((entry1 - entry2));
									  }								  
									  if(relativeError > 0.001){
										  isFail = true;
										  System.out.println("Not equal, Variation: " + relativeError);
									  }
									}
									catch (NumberFormatException e) {
										//System.out.println("Error: " + e);
									}
								}
							}
						}
					}
				}
			}
			catch(Exception ex)
			{
				System.out.println("Error: " + ex);
			}
		
	}
	
	
}
