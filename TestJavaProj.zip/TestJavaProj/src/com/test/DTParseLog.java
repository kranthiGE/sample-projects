package com.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.test.TdmParseTimeLog.FinalLogData;
import com.test.TdmParseTimeLog.TdmLogVals;

public class DTParseLog {

	/**
	 * @param args
	 */
	
	static String startString = "Config Thread started for ConfigId:";
	//static final String config_text ="Config Thread started for ConfigId";
	static final String procedure_text ="Procedure to call the testid::";
	static String config_id ="configid   :";
	static final String testIdList ="testList   :";
	static final String seqId_text = "seqId      :";
	static String process_complete_text = " -------  TdmTestMaster thread completed ---";
	static String temp_outfile = ""; 
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DTParseLog worker = new DTParseLog();
		if(args.length == 3)
		{	
			startString = startString + args[2];
			config_id = config_id + args[2];
			process_complete_text = "ConfigId:" + args[2] + process_complete_text;
			worker.createTempLog(args[0]);			
			worker.processData(temp_outfile, args[1]);
		}
		else{
			System.err.println("Usage:\n  DTParseLog <Input Log file> <Output file> <Config ID>\n\n" +
					"Note: If the output file will be appended if it already exists");
		}
	}

	public void createTempLog(String logFile)
	{
		String line = null;
		temp_outfile = logFile+"_temp.txt";
		PrintStream printStm = null;
		File optFile = null;
		try
		{
			BufferedReader bufRd = new BufferedReader(new FileReader(logFile));
			optFile = new File(temp_outfile);
			printStm = new PrintStream(new FileOutputStream(optFile));//create the file
			while((line = (bufRd.readLine())) != null){
				if(line.indexOf(startString) > 0 || line.indexOf(procedure_text) > 0 || line.indexOf(config_id) > 0 || line.indexOf(testIdList) > 0 || line.indexOf(seqId_text) > 0 || line.indexOf(process_complete_text) > 0){				
					printStm.println(line);
				}				
			}
			
		}
		catch(FileNotFoundException fileEx)		{
			System.out.println("File not found : " + fileEx);
		}
		catch(Exception e)
		{
			System.out.println(" Error : " + e);
		}
		finally
		{
			
		}
	}
	
	public void processData(String logFile, String outFile)
	{
		String line = null;
		String configId = "", testIds = "", seqId = "";
		String stTim = "";
		String stEnd = "";			
		PrintStream printStm = null;
		File optFile = null;		
		boolean isValidRec = false;
		try
		{
			//read the log file
			BufferedReader bufRd = new BufferedReader(new FileReader(logFile));
			optFile = new File(outFile);
			printStm = new PrintStream(new FileOutputStream(optFile));//create the file
			while((line = (bufRd.readLine())) != null){							
				
				if(line.indexOf(startString) > 0 && !isValidRec){					
					String cols[] = line.split("ConfigId:");
					if(cols.length == 2){						
						String fvals[] = cols[0].split("  INFO ");						
						configId = cols[1];
						stTim = fvals[0];						
					}
				}		
				if(line.indexOf(testIdList) > 0 && !isValidRec){
					String cols[] = line.split("testList   :");
					if(cols.length ==2){
						String testids[] = cols[1].split(",");
						testIds = String.valueOf(testids.length);
					}
				}
				if(line.indexOf(seqId_text) > 0 && !isValidRec){
					String cols[] = line.split(seqId_text);
					if(cols.length ==2){
						seqId = cols[1];						
						isValidRec = true;
					}
				}
				if(line.indexOf(process_complete_text) > 0){
					String cols[] = line.split("ConfigId:");
					if(cols.length ==2){
						String tempArr[] = cols[1].split(" -------  ");
						String tempConfid = tempArr[0];
						if(tempConfid.equalsIgnoreCase(configId)){
							String fvals[] = cols[0].split("  INFO ");
							stEnd = fvals[0];
						}
					}
				}
				/*System.out.println("*ST*****");
				System.out.println(configId);
				System.out.println(testIds);
				System.out.println(seqId);
				System.out.println(stTim);
				System.out.println(stEnd);
				System.out.println("*END*****");*/
				if(configId != "" && testIds != "" && seqId != "" && stTim != "" && stEnd != ""){					
					System.out.println(stTim + "," + configId + "," + testIds + "," + seqId + "," + stTim + "," + stEnd);
					printStm.println(stTim + "," + configId + "," + testIds + "," + seqId + "," + stTim + "," + stEnd);
					configId = "";
					testIds = "" ;
					seqId = "";
					stTim = "";
					stEnd = "";
					isValidRec = false;
				}				
			}		
		}
		catch(FileNotFoundException fileEx)		{
			System.out.println("File not found : " + fileEx);
		}
		catch(Exception e)
		{
			System.out.println(" Error : " + e);
		}
		finally
		{
			if(printStm != null){
				printStm.flush();
				printStm.close();
			}
		}
	
		
	}
}
