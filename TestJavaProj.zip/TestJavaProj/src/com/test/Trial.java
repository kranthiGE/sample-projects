package com.test;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;




public class Trial {
	public static void main(String[] args){
		
		
	}
	
	public void dateFunctions(){
		
		Map pdsMap = new HashMap();
		//pdsMap.put("test", "test");
		
	//System.out.println(pdsMap.get("test").toString());
		/*String val = "+1.0014060852150000E+004";
		Double dbl = 0.0;
		//val = "2.000000E+001";
		val = "4.567823345674E-009";
		val = "12.367";
		long sys = System.currentTimeMillis();		
		//for(int i=0;i<=10;i++)
			//System.out.println(getDecimalFormatValue(val));
		getDecimalFormatValue(val);*/
		//System.out.println(System.currentTimeMillis() - sys);
		//dbl = Double.valueOf(val);
		/*
		System.out.println(Math.floor(dbl));
		if(Math.floor(dbl) == dbl)
			System.out.println(" Int :: " + dbl.intValue());
		else
			System.out.println(" Double :: " + dbl);4.5678235E-9
				
		Map resMap = new HashMap();
		if(resMap != null && resMap.get("errcode") != null && !((String)resMap.get("errcode")).
				equalsIgnoreCase("3232")){
			
			
		}
			*/	
		//hitURL();
		//trimDateTimestamp("1994/10/18 13:03:39", true);
		
		//Calendar cal = Calendar.getInstance();
		
		// TODO Auto-generated method stub
		ArrayList<String> list = new ArrayList();
		list.add("Brn036.effBase");
		list.add("CASE");
		list.add("Cmp020.Fl_I.Ts");
		list.add("Cmp020.Fl_I.Ps");
		list.add("CONFIGMOD_ETDS");
		Collections.sort(list);
		for(int i=0; i<list.size(); i++) {
		System.out.println("list[" + i + "] value ==" + list.get(i));
		}

	}
	
	public static String parseValueType(String strVal)
	{
		String strParsedVal = null;
		Double dbl = 0.0;
		try{
			//Double dbl = new Double(strVal);
			dbl = Double.valueOf(strVal);
			if(Math.floor(dbl) == dbl)
				strParsedVal = String.valueOf(dbl.intValue());
			else
				strParsedVal = dbl.toString();
		}
		catch(NumberFormatException ex){
			strParsedVal = strVal;			
		}
		return strParsedVal;
	}
	
	public static String getDecimalFormatValue(String strVal)
	{
		String strParsedVal = null;
		DecimalFormat dcForm = null;
		try{			
			dcForm = new DecimalFormat("0.000000000E000");
			//strParsedVal = dcForm.format(strVal);
			System.out.println(dcForm.format(123.456));
		}
		catch(Exception ex){
			System.out.println(ex.getMessage());
			strParsedVal = strVal;			
		}
		return strParsedVal;
	}
	
	public static void hitURL()
	{
		try
		{
			URL url = new URL("http://localhost:8080/tdmdataaccess/tdmdata/faces/Login.jsp");
			URLConnection con = url.openConnection();
			Map headerMap = con.getHeaderFields();
			Set entry = headerMap.entrySet();
			
			Iterator keyIter = (headerMap.entrySet()).iterator();
			while (keyIter.hasNext()) {
				Entry entrySet = (Entry) keyIter.next();
				String headerName = (String) entrySet.getKey();
				//ArrayList alistData = entrySet.getValue() != null ? (ArrayList)entrySet.getValue() : null;
				System.out.println(headerName);
			}
			
			for(int i =0; ; i++)
			{
				String name = con.getHeaderFieldKey(i);
				String val = con.getHeaderField(i);
				
				if(name != null && val != null)
					break;
				else
					System.out.println("name: " + name + "val : " + val);
			}
			
			
		}
		catch(MalformedURLException malEx)
		{
			System.out.println(malEx);
		}
		catch(IOException ioEx)
		{
			System.out.println(ioEx);
		}
	}
	
	
	public static String trimDateTimestamp(String dateValue, boolean hasTimeStamp){
		String value = null;		
		value = "1994-03-31 08:57:47.0";
		if(value!=null){
			int position = value.indexOf(".0");
			if(position > -1) {
				value = value.substring(0, position);
			}
			value = value.replaceAll("-", "/");
			SimpleDateFormat sdf = null;
			if(hasTimeStamp) {
				sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss", new Locale("English"));
			} else {
				sdf = new SimpleDateFormat("yyyy/MM/dd", new Locale("English"));
			}
			sdf.setLenient(false);
			try{
				value = sdf.format(sdf.parse(value));//1994-03-31 08:57:47.0
				System.out.println(value);
			}catch(Exception ex){
				 System.out.println(ex.toString());
			}
		}
		return value;
	}
	
}
