// Copyright (C) 2008  General Electric 1.0
// All rights reserved
//
//COMBINED PROPRIETARY INFORMATION & EXPORT CONTROL STATEMENT
//-----------------------------------------------------------
//
//The information contained in this document is GE proprietary
//information and is disclosed in confidence. The technical data
//therein is exported under a U.S. Government License authorization
//[NLR under ECCN  9E991]. It is the property of GE and shall not be
//used, disclosed in whole or in part to others, or reproduced in whole
//or in part without the express written consent of GE including, but
//without limitation, it is not to be used in the creation, manufacture,
//development, or derivation of any repairs, modifications, spare parts,
//designs, or configuration changes or to obtain FAA or any other
//government or regulatory approval to do so. If consent is given for
//reproduction in whole or in part, this notice and the notice set forth
//on each page of this document shall appear in any such reproduction in
//whole or in part. In addition, the technical data therein, and the
//direct product of the data, may not be diverted, transferred,
//re-exported, or disclosed in any manner not provided for by the
//export license without the prior authorization of the U.S. Government.
//
//The countries listed in the ITC Embargo Destination List
//(http://data.supportcentral.ge.com/upload/15129/doc_747452.ppt)
//would not be eligible for 9E991 technical data.
//
//
//	       RESTRICTED RIGHTS LEGEND
//	       ------------------------
//
//Use, duplication or disclosure is subject to restrictions
//stated in Contract No. NAS3-25953 with General Electric Co. in
//accordance with FAR 52.227-14 and Contract No. F33615-91-C-2119
//with General Electric Co. in accordance with DFARS 52.227-7013.
//No other right or license is granted.
//
//
//	  FREEDOM OF INFORMATION ACT MARKING
//	  ----------------------------------
//
//Incorporates General Electric Company confidential trade
//secrets or commercial or financial information.
//
//
//Copyright (c) 2009 General Electric Company, U.S.A.
//All rights reserved.
//
//
//	    COMPETITION SENSITIVE SOFTWARE
//	    ------------------------------
//
/*
 * Modifications :
 *
 *   Sl.No   Who     When        Why
 *   -----   ---     ----        ---
 *   1.      Hebbar  15-Feb-11   created
 *   2.		 Kranthi 24-Feb-11   modified

 **************************************************************************/

package com.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class TdmParseTimeLog
{
	static String[] ReportColNames= null; 

//  Log columns after removal of duplicate proc call
	static String[] QaColumnNames   = {"Date", "Status", "C00", "C10", "C20", "C30", "C40", "J10", "J14", "J20", "J30", "J40", "J50", "N", "D10", "D20", "D30", "D40", "D50", "D60", "D70", "D90", "D80"};// to store all column names
	static String[] ProdColumnNames = {"Date", "Status", "C00", "C10", "C20", "C30", "C40", "J10", "J14", "J20", "J30", "J40", "J50", "N", "D10", "D20", "D30", "D40", "D50", "D60", "D70", "D90", "D80"};// to store all column names//"J45","D93",, "D96"  

	static String StatusColumnName = "C40";
		
	static String[] arrTemp = null;

	static final String C_LOG = "TimeLog : END"; // constant to parse the C-Log

	static final int time_delay = 0;
	
	SimpleDateFormat dtFmtOut = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss", Locale.getDefault());

	public class TdmLogVals implements Comparable<TdmLogVals> {

		Calendar mTime;
		String mColName;
		double mValue;

		public TdmLogVals(Calendar time, String colName, double val)
		{
			mTime = time;
			mColName = colName;
			mValue = val;
		}

		public int compareTo(TdmLogVals tdmLog)
		{
			return getMtime().compareTo(tdmLog.getMtime());			
		}

		public Calendar getMtime()
		{
			return mTime;
		}
	}
	
	public class FinalLogData implements Comparable<FinalLogData>
	{
		Calendar mTime;
		Map<String, String> rowDataMap;
		
		public FinalLogData(Calendar time, Map<String, String> dataMap)
		{
			mTime = time;
			rowDataMap = dataMap;
		}
		
		public int compareTo(FinalLogData finalData)
		{
			return finalData.getMtime().compareTo(getMtime());
		}
		
		public Calendar getMtime()
		{
			return mTime;
		}
	}

	public static void main(String[] args)
	{
		TdmParseTimeLog worker = new TdmParseTimeLog();
		if(args.length == 3)
		{
			ReportColNames = args[0].equalsIgnoreCase("p") ? ProdColumnNames : QaColumnNames;
			worker.process(args[1], args[2]);
		}
		else{
			System.err.println("Usage:\n  TdmParseTimeLog <env> <Input Log file> <Output file> \n\n" +
					"Note: If the output file will be appended if it already exists");
		}
	}

	public void process(String logFile, String outFile)
	{
		String line = null;
		String date = "", time = "", col = "", val = "";
		ArrayList<TdmLogVals> allRecords = new ArrayList<TdmLogVals>();
		SimpleDateFormat tmFmt = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
		PrintStream printStm = null;
		SimpleDateFormat dtFmtJ = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
		String dtLog = null;
		FileOutputStream out = null;
		String nodeName = null;
		try
		{
			//read the log file
			BufferedReader bufRd = new BufferedReader(new FileReader(logFile));
			while((line = (bufRd.readLine())) != null){
				Calendar cal = Calendar.getInstance();
				date = "";
				time = "";
				col = "" ;
				val = "";
				if(line.indexOf(C_LOG) > 0){
					//C log
					String cols[] = line.split(",");
					String fvals[] = cols[0].split(" ");
					date = fvals[1] + " " + fvals[0];
					col = cols[2];
					val = cols[3];
					cal.setTime(dtFmtJ.parse(date));
					if(time_delay != 0)
						cal.set(Calendar.MINUTE, cal.get(Calendar.MINUTE) + time_delay);
				}
				else{
					//Java
					String cols[] = line.split(",");
					if(cols.length == 4){
						Date dt = dtFmtJ.parse(cols[1]);
						dtLog = dt.toString();
						cols[1] = tmFmt.format(dt).toString();
						date = cols[1];
						col = cols[2];
						val = cols[3];
						cal.setTime(dt);
					}
					else{
						System.out.println("Unable to process the line :: " + cols[0]);
						continue;
					}
				}				
				TdmLogVals tdmVals = new TdmLogVals(cal, col, Double.parseDouble(val));
				allRecords.add(tdmVals);
			}
			Collections.sort(allRecords);
			
			boolean writeColumns = true;
			File optFile = new File(outFile);
			printStm = new PrintStream(new FileOutputStream(optFile));//create the file

			if(writeColumns)
			{
				// Write the column names to the file
				for(int j = 0; j <= ReportColNames.length - 1; j++){
					if(j<(ReportColNames.length-1))
						printStm.print(ReportColNames[j] + ",");
					else
						printStm.print(ReportColNames[j]);
				}
			}
			
			Map<String, String> record_data = null;
			List<String> dateList = new ArrayList<String>();
			List<FinalLogData> finalDataList = new ArrayList<FinalLogData>();
			Calendar rowCal = null;
			FinalLogData flData = null;
			
			/*
			for (TdmLogVals tdmLogVals : allRecords) {
				System.out.println(dtFmtOut.format(tdmLogVals.mTime.getTime()) + " " + tdmLogVals.mColName + " " + tdmLogVals.mValue);
			}
			*/
			for (TdmLogVals tdmLogVals : allRecords) {

				if(tdmLogVals.mColName.equals("C10"))
				{
					
					if(record_data != null && !dateList.contains(dtLog)) {
						
						flData = new FinalLogData(rowCal, record_data);
						finalDataList.add(flData);
						dateList.add(dtLog);
					}
					record_data = new HashMap<String, String>();
				}
				if(tdmLogVals.mColName.equals("C00"))
				{
					dtLog = dtFmtOut.format(tdmLogVals.mTime.getTime());
					rowCal = tdmLogVals.mTime;
				}				
				if(record_data != null)
					record_data.put(tdmLogVals.mColName, String.valueOf(tdmLogVals.mValue));
			}
			Collections.sort(finalDataList);
			
			//output to CSV file		
			for (FinalLogData flAllData : finalDataList) {
				dtLog = dtFmtOut.format(flAllData.mTime.getTime());				
				writeRecord(dtLog, printStm, flAllData.rowDataMap);
			}
					
		}
		catch(FileNotFoundException fileEx)		{
			System.out.println("File not found : " + fileEx);
		}
		catch(Exception e)
		{
			System.out.println(" Error : " + e);
		}
		finally
		{
			try
			{
				if(out != null){
					out.flush();
					out.close();
				}
			}
			catch(IOException ioEx){
				System.out.println("Error occurred when closing th eout stream : "+ ioEx.getMessage());				
			}
		}
	}

	private void writeRecord(String dt, PrintStream printStm, Map<String, String> record_data)
	{
		double totalJval = 0;
		double netWorkVal = 0;
		StringBuffer datBuffer = new StringBuffer(); 		
		datBuffer.append(dt);
		datBuffer.append(",");
		for (int i = 1; i < ReportColNames.length ; i++)
		{			
			if(i == 1)
			{
				datBuffer.append(record_data.get(StatusColumnName) == null ? "FAIL," : "PASS,");
				continue;
			}			
			String val = record_data.get(ReportColNames[i]);
			if(val == null){//insert space if the value is null
				val = "";
			}
			if(val != "" && (ReportColNames[i].equals("J10") || ReportColNames[i].equals("J20") || ReportColNames[i].equals("J14") || ReportColNames[i].equals("J30") || ReportColNames[i].equals("J40") || ReportColNames[i].equals("J50") || ReportColNames[i].equals("J45")) )
			{//calculate total J value
				totalJval = totalJval + Double.parseDouble(val);
			}	
			if(ReportColNames[i].equals("N")){//get the c00 value and substract from total jval
				netWorkVal = Double.parseDouble(record_data.get("C00") == null ? "0" : record_data.get("C00")) - totalJval;				
				datBuffer.append(netWorkVal);
				datBuffer.append(",");
				continue;
			}
			if(i<(ReportColNames.length - 1)){
				datBuffer.append(val);
				datBuffer.append(",");
			}
			else
				datBuffer.append(val);
		}
		if(datBuffer.length() > 0 && netWorkVal >= 0){
			printStm.println();
			printStm.print(datBuffer.toString());
		}
	}
}

