package com.test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class TestCalendar {
	static String LOC = "C:/tdm/";
	private static final DateFormat CDF_DATE_FORMAT = new SimpleDateFormat("MMddyy");
	private static final DateFormat CDF_TIME_FORMAT = new SimpleDateFormat("HHmmss.SSS");
	private static final DateFormat IN_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String dtVal = getLastSunday();
		FileWriter flWr = null;
		BufferedWriter bufWr = null;
		
		try
		{
			System.out.println("sndy: " + dtVal);
			
			Date date = IN_DATE_FORMAT.parse("9999-12-31 00:00:00.000000");
			
			System.out.println(CDF_TIME_FORMAT.format(date));
			System.out.println(CDF_DATE_FORMAT.format(date));
			
			/*if(dtVal != null){
				File fl = new File(LOC + dtVal + ".txt");
				if(fl.exists()){
					flWr = new FileWriter(LOC + dtVal + ".txt", true);
				}
				else{
					flWr = new FileWriter(LOC + dtVal + ".txt");
				}
				if(flWr != null){
					bufWr = new BufferedWriter(flWr);
					bufWr.write("This is Kranthi and last sunday is :" + dtVal + "\n");
				}
			}
			*/
		}
		catch (Exception e) {
			System.out.println("Error Occurred : " + e);
		}
		finally{
			try{
			//	bufWr.flush();
				//bufWr.close();
			}
			catch (Exception e) {
				System.out.println("Error Occurred when closing writer: " + e);	
			}
		}
	}
	
	public static String getLastSunday(){
		String sndyDt = null;
		Calendar cal = Calendar.getInstance();
		String currentDate = null;
		int today = 0;
		System.out.println(("Simpl: " + (new SimpleDateFormat("ddMMyyyy HH:mm:ss")).format(new Date())));
		cal.set(Calendar.YEAR, 2012);
		cal.set(Calendar.MONTH, 11);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		currentDate = cal.get(Calendar.DAY_OF_MONTH) + "-" + Integer.valueOf(cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.YEAR);
		System.out.println("Current Date: " + currentDate);
		if(cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY){
			sndyDt = currentDate;
		}
		else{
			today = cal.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY;			
			cal.set(Calendar.DAY_OF_YEAR, Integer.valueOf(cal.get(Calendar.DAY_OF_YEAR) - today));
			sndyDt = cal.get(Calendar.DAY_OF_MONTH) + "-" + Integer.valueOf(cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.YEAR);	
		}
		return sndyDt;		
	}

}
