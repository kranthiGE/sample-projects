package com.test;

public class CreditSystem {

	String strId = null;
	
}
