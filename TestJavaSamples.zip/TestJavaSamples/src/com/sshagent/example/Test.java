package com.sshagent.example;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.regex.Pattern;

import sun.security.rsa.RSAPublicKeyImpl;

public class Test {
	
	private static byte[] m_arrPK;
	
	private static byte[] data;
	
	public static void main(String[] args){
	// TODO Auto-generated method stub
		/*java.util.ArrayList<String> list = new ArrayList<String>();
		list.add("Brn036.effBase");
		list.add("CASE");
		list.add("Cmp020.Fl_I.Ts");
		list.add("Cmp020.Fl_I.Ps");
		list.add("CONFIGMOD_ETDS");
		Collections.sort(list);
		for(int i=0; i<list.size(); i++) {
			System.out.println("list[" + i + "] value ==" + list.get(i));
		}*/
		String optKey = "RDG=19101|ESN=32094";
		String[] optKeyTmp = null;
		if(optKey != null){
			optKeyTmp = optKey.split(Pattern.quote("|"));		
		}
		System.out.println(optKeyTmp.length);
		/*m_arrPK = "AAAAB3NzaC1yc2EAAAABJQAAAIEAgEA0/FzjnAa7a9xEdhDs+R2GqpFHHYL5HxVJ6fIDFQIg/bQCWwk470OXeS6+7LUOKOl7dfqA1iOel7/rsfaWpnIhDw7LLnnfSdA2oyG6Fqp3dC4gbVnggxIWDc47nQPFsy3+gIB53SywZKPmX8PyArzDnWjgTpWEh2wTOwWL9lU=".getBytes();
		
		data = "swapna".getBytes();
		byte[] arr = "".getBytes();
		verifySignature_testing(arr);*/
	}
	
	static void verifySignature_testing(byte[] signature_data) 
	{
	try{
		RSAPublicKeyImpl pub = new RSAPublicKeyImpl( m_arrPK );
	
	/*		
		KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
		kpg.initialize(2048);
		KeyPair kp = kpg.genKeyPair();
		PublicKey pub = kp.getPublic();
		if ( DEBUG ) {
			System.err.println("DEBUG: PK algorithm is " + pub.getAlgorithm() );
			System.err.println("DEBUG: PK format is " + pub.getFormat() );
			byte[] pubV = pub.getEncoded();
			printByteArr( pubV, "DEBUG: PK value is " );
			writeByteArrToFile(pubV, "test.pub");
		}
	*/		
	///		byte[] pubV = readByteArrFromFile("test.pub");
	///		RSAPublicKeyImpl pub = new RSAPublicKeyImpl( pubV );
	
		
		//Signature signature = Signature.getInstance("SHA1withRSA", "BC");
		Signature signature = Signature.getInstance("MD5withRSA");
		signature.initVerify( pub );
		signature.update(data, 0, data.length);
		boolean bOK = signature.verify(signature_data);
		System.out.println("Signature verifies OK?: " + bOK);
		
	}catch(Exception ex){System.out.println(ex);}
	}	
}
