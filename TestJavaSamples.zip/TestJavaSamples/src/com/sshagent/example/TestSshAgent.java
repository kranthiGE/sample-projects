package com.sshagent.example;
/*
import com.jcraft.jsch.agentproxy.AgentProxy;
import com.jcraft.jsch.agentproxy.AgentProxyException;
import com.jcraft.jsch.agentproxy.Connector;
import com.jcraft.jsch.agentproxy.connector.PageantConnector;*/



public class TestSshAgent {

	public static void main(String[] arg){		
		/*try{
			Connector con = new PageantConnector();
			AgentProxy ap = new AgentProxy(con);
			System.out.println("hi..");
			
			 * TestSshAgent -sshAuth
			 * 
			 
			
			
		}
		catch(AgentProxyException ex){
			System.out.println(ex);
		}*/
		
	}
}
