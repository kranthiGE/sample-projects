// Copyright (C) 2008  General Electric 1.0
// All rights reserved
//
//COMBINED PROPRIETARY INFORMATION & EXPORT CONTROL STATEMENT
//-----------------------------------------------------------
//
//The information contained in this document is GE proprietary
//information and is disclosed in confidence. The technical data
//therein is exported under a U.S. Government License authorization
//[NLR under ECCN  9E991]. It is the property of GE and shall not be
//used, disclosed in whole or in part to others, or reproduced in whole
//or in part without the express written consent of GE including, but
//without limitation, it is not to be used in the creation, manufacture,
//development, or derivation of any repairs, modifications, spare parts,
//designs, or configuration changes or to obtain FAA or any other
//government or regulatory approval to do so. If consent is given for
//reproduction in whole or in part, this notice and the notice set forth
//on each page of this document shall appear in any such reproduction in
//whole or in part. In addition, the technical data therein, and the
//direct product of the data, may not be diverted, transferred,
//re-exported, or disclosed in any manner not provided for by the
//export license without the prior authorization of the U.S. Government.
//
//The countries listed in the ITC Embargo Destination List
//(http://data.supportcentral.ge.com/upload/15129/doc_747452.ppt)
//would not be eligible for 9E991 technical data.
//
//
//	       RESTRICTED RIGHTS LEGEND
//	       ------------------------
//
//Use, duplication or disclosure is subject to restrictions
//stated in Contract No. NAS3-25953 with General Electric Co. in
//accordance with FAR 52.227-14 and Contract No. F33615-91-C-2119
//with General Electric Co. in accordance with DFARS 52.227-7013.
//No other right or license is granted.
//
//
//	  FREEDOM OF INFORMATION ACT MARKING
//	  ----------------------------------
//
//Incorporates General Electric Company confidential trade
//secrets or commercial or financial information.
//
//
//Copyright (c) 2009 General Electric Company, U.S.A.
//All rights reserved.
//
//
//	    COMPETITION SENSITIVE SOFTWARE
//	    ------------------------------
//

/*
 * Modifications :
 *
 *   Sl.No   Who     When          Why
 *   -----   ---     ----          ---
 *   1.      Kranthi  18-June-2013   Created
 **************************************************************************/

package com.edw.xml;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="EDW-datagram")
@XmlType(propOrder={"dataDefinition", "data"})
public class EDWdatagram {

	@XmlElement
	Datadefinition dataDefinition;
	
	@XmlElement
	Data data;
	
	EDWdatagram(){
		
	}
	
	EDWdatagram(Datadefinition dataDefinition, Data data){
		this.dataDefinition = dataDefinition;
		this.data = data;
	}
}
