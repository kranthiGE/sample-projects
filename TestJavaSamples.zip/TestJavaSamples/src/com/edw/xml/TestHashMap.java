package com.edw.xml;

import java.util.HashMap;
import java.util.TreeMap;

public class TestHashMap {

	static HashMap<String, Integer> data = null;
	
	static TreeMap<String, Integer> mapData = null;
	
	public static void main(String[] args){
		data = new HashMap<String, Integer>();
		data.put("Kranthi", 1234);
		data.put("Kiran", 89879);
		data.put("Pushkraj", 38484);
		
		System.out.println(data.get("kranthi"));

		mapData = new TreeMap<String, Integer>(String.CASE_INSENSITIVE_ORDER);		
		mapData.putAll(data);
		
		System.out.println(mapData.get("kranthi"));
	}	
}


