// Copyright (C) 2008  General Electric 1.0
// All rights reserved
//
//COMBINED PROPRIETARY INFORMATION & EXPORT CONTROL STATEMENT
//-----------------------------------------------------------
//
//The information contained in this document is GE proprietary
//information and is disclosed in confidence. The technical data
//therein is exported under a U.S. Government License authorization
//[NLR under ECCN  9E991]. It is the property of GE and shall not be
//used, disclosed in whole or in part to others, or reproduced in whole
//or in part without the express written consent of GE including, but
//without limitation, it is not to be used in the creation, manufacture,
//development, or derivation of any repairs, modifications, spare parts,
//designs, or configuration changes or to obtain FAA or any other
//government or regulatory approval to do so. If consent is given for
//reproduction in whole or in part, this notice and the notice set forth
//on each page of this document shall appear in any such reproduction in
//whole or in part. In addition, the technical data therein, and the
//direct product of the data, may not be diverted, transferred,
//re-exported, or disclosed in any manner not provided for by the
//export license without the prior authorization of the U.S. Government.
//
//The countries listed in the ITC Embargo Destination List
//(http://data.supportcentral.ge.com/upload/15129/doc_747452.ppt)
//would not be eligible for 9E991 technical data.
//
//
//	       RESTRICTED RIGHTS LEGEND
//	       ------------------------
//
//Use, duplication or disclosure is subject to restrictions
//stated in Contract No. NAS3-25953 with General Electric Co. in
//accordance with FAR 52.227-14 and Contract No. F33615-91-C-2119
//with General Electric Co. in accordance with DFARS 52.227-7013.
//No other right or license is granted.
//
//
//	  FREEDOM OF INFORMATION ACT MARKING
//	  ----------------------------------
//
//Incorporates General Electric Company confidential trade
//secrets or commercial or financial information.
//
//
//Copyright (c) 2009 General Electric Company, U.S.A.
//All rights reserved.
//
//
//	    COMPETITION SENSITIVE SOFTWARE
//	    ------------------------------
//

/*
 * Modifications :
 *
 *   Sl.No   Who     When          Why
 *   -----   ---     ----          ---
 *   1.      Kranthi  18-June-2013   Created
 **************************************************************************/

package com.edw.xml;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

public class TestXml {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		File file = null;
		//PrintWriter write = null;
		FileOutputStream out = null;
		Marshaller jaxbMarsh = null;
		long startTime = System.currentTimeMillis();
		EdwXmlWriter write = null;
		try{
			file = new File("D://xml1.xml");
			out = new FileOutputStream(file);
			//write = new PrintWriter(file);
		}
		catch(FileNotFoundException ex){
			System.out.println(ex);
		}
		try{
			write = EdwXmlWFactory.createXmlWriter(out);
			write.addKey("MODEL", "S", "NOMODEL");
			write.addKey("TESTTYPE", "S", "DEV");
			write.addKey("RDGTYPE", "S", "SS");
			write.addKey("TEST", "I", "9880");
			write.addKey("RDG", "I", "1");
			for(int i = 0;i< 1000;i++){
				write.addParameter("A02" + i, "R", "int2");
			}
			ArrayList<String> aData = new ArrayList<String>();
			for(int i = 0;i< 1000;i++){
				aData.add(String.valueOf(123+i));
			}
			write.writeRecord(aData);
			/*write.println("<EDW-datagram>");			
			Keys keys = new Keys();
			keys.setKeys(new Key("MODEL", "NOMODEL", "A"));
			keys.setKeys(new Key("TESTTYPE", "DEV", "A"));
			keys.setKeys(new Key("TESTTYPE", "DEV", "A"));
			keys.setMode(ModeForKeys.New);		

			Params params = new Params();
			for(int i = 0;i< 1000;i++){
				params.setParams(new Param("A02" + i, "R", "int2"));
			}
			params.setMode(ModeForKeys.New);			
			
			Datadefinition dataDef = new Datadefinition();
			dataDef.setKeys(keys);
			dataDef.setParams(params);
			jaxbMarsh = getXmlMarshaller(Datadefinition.class);	
			jaxbMarsh.marshal(dataDef, write);
			
			Dataset dataset = null;
			Data data = new Data();
			StringBuilder sBldParamVals = new StringBuilder();
			
			write.println("<data>");
			for(int i = 0;i< 1000;i++){
				dataset = new Dataset();
				dataset.setParamsSize(params.getParamsSize());
				dataset.setRdg(i);
				sBldParamVals.setLength(0);
				for(int j = 0;j< 1000;j++){
					sBldParamVals.append(String.valueOf(123+i+j+1));				
					if(j != 999)
						sBldParamVals.append("||");		
				}
				dataset.setValues(sBldParamVals.toString());
				if(file != null){
					jaxbMarsh = getXmlMarshaller(Dataset.class);	
					jaxbMarsh.marshal(dataset, write);
					//write.println("\n");
				}
				//data.setDataSet(dataset);
			}
			write.println("");
			write.println("</data>");		
			write.println("</EDW-datagram>");*/
		}		
		catch(EdwXmlWException ex){
			System.out.println(ex);
		}
		finally{
			//write.close();
			try{
				out.close();
			}
			catch(IOException ioEx){}
		}
		//EDWdatagram edw = new EDWdatagram(dataDef,data); 		
		System.out.println((System.currentTimeMillis() - startTime)/1000.0);
	}
	
	private static Marshaller getXmlMarshaller(Class clas){
		Marshaller jaxbMarsh = null;
		try{
			JAXBContext jaxbCont = JAXBContext.newInstance(clas);
			jaxbMarsh = jaxbCont.createMarshaller();
			jaxbMarsh.setProperty(Marshaller.JAXB_FRAGMENT, true);
			jaxbMarsh.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);			
		}		
		catch(JAXBException ex){
			System.out.println(ex);
		}
		return jaxbMarsh;
	}
}
