// Copyright (C) 2008  General Electric 1.0
// All rights reserved
//
//COMBINED PROPRIETARY INFORMATION & EXPORT CONTROL STATEMENT
//-----------------------------------------------------------
//
//The information contained in this document is GE proprietary
//information and is disclosed in confidence. The technical data
//therein is exported under a U.S. Government License authorization
//[NLR under ECCN  9E991]. It is the property of GE and shall not be
//used, disclosed in whole or in part to others, or reproduced in whole
//or in part without the express written consent of GE including, but
//without limitation, it is not to be used in the creation, manufacture,
//development, or derivation of any repairs, modifications, spare parts,
//designs, or configuration changes or to obtain FAA or any other
//government or regulatory approval to do so. If consent is given for
//reproduction in whole or in part, this notice and the notice set forth
//on each page of this document shall appear in any such reproduction in
//whole or in part. In addition, the technical data therein, and the
//direct product of the data, may not be diverted, transferred,
//re-exported, or disclosed in any manner not provided for by the
//export license without the prior authorization of the U.S. Government.
//
//The countries listed in the ITC Embargo Destination List
//(http://data.supportcentral.ge.com/upload/15129/doc_747452.ppt)
//would not be eligible for 9E991 technical data.
//
//
//	       RESTRICTED RIGHTS LEGEND
//	       ------------------------
//
//Use, duplication or disclosure is subject to restrictions
//stated in Contract No. NAS3-25953 with General Electric Co. in
//accordance with FAR 52.227-14 and Contract No. F33615-91-C-2119
//with General Electric Co. in accordance with DFARS 52.227-7013.
//No other right or license is granted.
//
//
//	  FREEDOM OF INFORMATION ACT MARKING
//	  ----------------------------------
//
//Incorporates General Electric Company confidential trade
//secrets or commercial or financial information.
//
//
//Copyright (c) 2009 General Electric Company, U.S.A.
//All rights reserved.
//
//
//	    COMPETITION SENSITIVE SOFTWARE
//	    ------------------------------
//

/*
 * Modifications :
 *
 *   Sl.No   Who     When          Why
 *   -----   ---     ----          ---
 *   1.      Kranthi  18-June-2013   Created
 **************************************************************************/

package com.edw.xml;

import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

public class EdwXmlWriterImpl implements EdwXmlWriter{
		
	private Keys keys = null;
	
	private Params params = null;
	
	private PrintWriter write = null;
	
	private static final int MAX_PARAM_LENGTH = 256;
	
	private static final String RDGTYPE_KEY = "rdgtype";
	
	private static final String RDG_KEY = "rdg";
	
	private static final String SCAN_KEY = "scan";
	
	private boolean isNewDatagram = false;
	
	private boolean isRdgTypeSS = false;
	
	private boolean isRdgTypeTR = false;
	
	public EdwXmlWriterImpl(OutputStream outStream) throws EdwXmlWException {
		if(outStream == null){
			throw new EdwXmlWException("Empty stream received. Unable to initialize");
		}
		write = new PrintWriter(outStream);		
		keys = new Keys();
		params = new Params();
		init_Data();
	}
	
	private void init_Data(){
		isNewDatagram = true;
		isRdgTypeSS = false;
		isRdgTypeTR = false;
		if(keys != null)
			keys.clearKeys();
		if(params != null)
			params.clearParams();
		if(write != null){
			write.println("<EDW-datagram>");
		}
	}
	
	public void addKey(String name, String type,String keyValue)
	throws EdwXmlWException{		
		try{
			keys.setKeys(new Key(name, keyValue, type));
		}
		catch(EdwXmlWException ex){throw ex;}
		
	}
	
	public void addKey(Key key)
	throws EdwXmlWException{
		if(key == null)
			throw new EdwXmlWException("Null key object");
		keys.setKeys(key);			
	}
	
	public void addParameter(String name, String type, String units)
	throws EdwXmlWException{		
		if(name.length() > MAX_PARAM_LENGTH)
			throw new EdwXmlWException("Parameter name length should not be greater than 256");
		params.setParams(new Param(name, units, type));
	}
	
	public void addParameter(Param param)
	throws EdwXmlWException{
		params.setParams(param);
	}
	
	public void writeRecord(ArrayList<String> rowdata) 
	throws EdwXmlWException{
		Marshaller jaxbMarsh = null;
		Dataset dataset = null;
		Data data = new Data();
		StringBuilder sBldParamVals = new StringBuilder();
		try{
			//create new datagram only when flag set
			//write init data and create data definition with keys, params
			if(isNewDatagram){
				//printEndXml();
				//init_Data();
				writeDataDefinition();
				write.println("<data>");
			}			
			dataset = new Dataset();
			dataset.setParamsSize(params.getParamsSize());
			setRdgType();
			if(isRdgTypeSS){
				try{
					int rdg = Integer.valueOf(getValue(RDG_KEY));
					if(rdg != 0)
						dataset.setRdg(rdg);
					else
						throw new EdwXmlWException("No RDG key value found, unable to create XML");
				}
				catch(NumberFormatException nEx){
					throw new EdwXmlWException("RDG value is not a number, unable to create XML");
				}
			}
			if(isRdgTypeTR){
				try{
					int scan = Integer.valueOf(getValue(SCAN_KEY));
					if(scan != 0)
						dataset.setScan(scan);
					else
						throw new EdwXmlWException("No SCAN key value found, unable to create XML");
				}
				catch(NumberFormatException nEx){
					throw new EdwXmlWException("SCAN value is not a number, unable to create XML");
				}
			}
			for (String val : rowdata) {
				sBldParamVals.append(val).append("||");
			}
			if(sBldParamVals.length() > 0){
				dataset.setValues(sBldParamVals.substring(0, sBldParamVals.length() - 2).toString());
				jaxbMarsh = getXmlMarshaller(Dataset.class);	
				jaxbMarsh.marshal(dataset, write);
			}
		}
		catch(Exception ex){
			throw new EdwXmlWException("Exception in writeRecord() : " + ex);
		}
		finally{
			write.flush();
			sBldParamVals = null;
		}
	}
	
	private void writeDataDefinition() throws JAXBException,EdwXmlWException{
		Marshaller jaxbMarsh = null;
		Datadefinition dataDef = new Datadefinition();
		try{
			keys.setMode(ModeForKeys.New);
			params.setMode(ModeForKeys.New);
			dataDef.setKeys(keys);
			dataDef.setParams(params);
			jaxbMarsh = getXmlMarshaller(Datadefinition.class);	
			if(jaxbMarsh != null)
				jaxbMarsh.marshal(dataDef, write);
		}
		catch(JAXBException jaxEx){
			throw jaxEx;
		}
		catch(EdwXmlWException ex){
			throw ex;
		}
	}
	
	public void setNewDatagram(){
		isNewDatagram = true;
	}
	
	private void printEndXml(){
		write.println("");
		write.println("</data>");		
		write.println("</EDW-datagram>");		
	}
	
	
	private static Marshaller getXmlMarshaller(Class clas) throws EdwXmlWException {
		Marshaller jaxbMarsh = null;
		try{
			JAXBContext jaxbCont = JAXBContext.newInstance(clas);
			jaxbMarsh = jaxbCont.createMarshaller();
			jaxbMarsh.setProperty(Marshaller.JAXB_FRAGMENT, true);
			jaxbMarsh.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);			
		}		
		catch(JAXBException ex){
			throw new EdwXmlWException("Exception in getXmlMarshaller() : " + ex);
		}
		return jaxbMarsh;
	}
	
	private void setRdgType(){
		if(keys != null && keys.getKeyMapData().size() > 0){
			if((keys.getKeyMapData().get(RDGTYPE_KEY)).value.toLowerCase().equals("SS"))
				isRdgTypeSS = true;
			else if((keys.getKeyMapData().get(RDGTYPE_KEY)).value.toLowerCase().equals("tr"))
				isRdgTypeTR = true;
		}
	}
	
	private String getValue(String keyName){
		String tempVal = null;
		if(keys != null && keys.getKeyMapData().size() > 0){
			if(keys.getKeyMapData().get(keyName) != null)
				tempVal = keys.getKeyMapData().get(keyName).value;			
		}
		return tempVal;
	}
}
