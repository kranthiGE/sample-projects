package com.test.dao;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Semaphore;

public class ConnectionPool implements IConnectionPool {
	private static ConnectionPool conPool = new ConnectionPool();
	List<Connection> cons = new LinkedList<Connection>();
	Semaphore semaphore = null;	
	
	private static final int MAX_CONNECTIONS = 5;
	
	private ConnectionPool(){
		for(int i=0; i < MAX_CONNECTIONS; i++){
			cons.add(new Connection(i+1));
		}
		semaphore = new Semaphore(MAX_CONNECTIONS);
	}
	
	public static ConnectionPool getInstance(){
		if(conPool == null)
					conPool = new ConnectionPool();
		return conPool;		
	}
	
	public synchronized Connection getConnection() throws InterruptedException {
		semaphore.acquire();		
		return cons.remove(0);
		
	}
	
	public void releaseConnection(Connection con){		
		System.out.println("connection "+con.getConnectionId()+"released");
		cons.add(con);		
		semaphore.release();
	}
	
}
