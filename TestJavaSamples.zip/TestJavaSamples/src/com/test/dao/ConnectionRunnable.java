package com.test.dao;

public class ConnectionRunnable implements Runnable{

	public void run()
	{	
		createConnection();
	}
	
	public synchronized void createConnection(){
		Connection con;
		try{
			con = DAOImpl.getConnection();			
			System.out.println(con.getConnectionId());
			Thread.sleep(6000);
			DAOImpl.releaseConnection(con);
		}
		catch(InterruptedException ex){
			System.out.println(ex);
		}
	}
}
