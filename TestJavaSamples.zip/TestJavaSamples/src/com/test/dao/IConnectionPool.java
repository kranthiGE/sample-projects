package com.test.dao;

public interface IConnectionPool {
		
	Connection getConnection() throws InterruptedException ;
	
	void releaseConnection(Connection con);
}
