package com.test.dao;

public class ConnectionTest {

	public static void main(String[] args) throws InterruptedException{		
		/*Connection con1 = DAOImpl.getConnection();		
		Connection con2 = DAOImpl.getConnection();
		Connection con3 = DAOImpl.getConnection();
		Connection con4 = DAOImpl.getConnection();
		Connection con5 = DAOImpl.getConnection();
		//System.out.println(con5.getConnectionId());
		//DAOImpl.releaseConnection(con5);
		Connection con6 = DAOImpl.getConnection();
		System.out.println(con6.getConnectionId());
				*/
		
		Thread t1 = new Thread(new ConnectionRunnable());
		t1.start();
		
		Thread t2 = new Thread(new ConnectionRunnable());
		t2.start();
		
		Thread t3 = new Thread(new ConnectionRunnable());
		t3.start();
		
		Thread t4 = new Thread(new ConnectionRunnable());
		t4.start();
		
		Thread t5 = new Thread(new ConnectionRunnable());
		t5.start();
		
		Thread t6 = new Thread(new ConnectionRunnable());
		t6.start();
		
		
		
	}	
	
}
