package com.test.dao;

import java.sql.ResultSet;

public class ReadClob {

	public void readClob(){
		
		ResultSet rsData = null;
		
		//java.sql.Clob clob = rsData.get 
	}
}
