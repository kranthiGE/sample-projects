package com.test.dao;

public class Connection {
	private int i = 0;
	
	public Connection(int i){
		this.i = i;		
		System.out.println("Connection "+ i +" created in pool");
	}
	
	public int getConnectionId(){
		return i;
	}
	
	public void close(){
		System.out.println("Connection closed");
	}
	
	public void open(){
		System.out.println("Connection opened");
	}
	
}
