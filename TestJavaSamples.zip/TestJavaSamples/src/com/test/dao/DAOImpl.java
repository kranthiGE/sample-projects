package com.test.dao;

public class DAOImpl {

	static int count = 0;
	public static Connection getConnection() throws InterruptedException{
		count++;
		//System.out.println("Connection: "+ count +" requested from pool");
		return ConnectionPool.getInstance().getConnection();		
	}
	
	public static void releaseConnection(Connection con){
		ConnectionPool.getInstance().releaseConnection(con);
	}
	
}
