package com.geaviation.tdm.usersimulation;

public class TestSchedule implements Runnable {
	
	boolean isRunning = false;
	
	int count = 0;
	
	public TestSchedule(boolean isRunning){
		this.isRunning = isRunning;
	}
	
	public void run() {
		count++;
		if(count != 5)
			System.out.println("beep");
		else
			isRunning = true;
	}
 
}
