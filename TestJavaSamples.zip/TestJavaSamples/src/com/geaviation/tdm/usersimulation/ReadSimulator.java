package com.geaviation.tdm.usersimulation;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Random;


public class ReadSimulator {

	/**
	 * @param args
	 */
	
	public static final String PROPTIES_PATH = "properties.txt";
	
	public static final String KEY_FILES_DIR = "keyfilesdir";
	
	public static final String EDWC_PATH = "edwcpath";
	
	public static final String TEMP_PATH = "tempDir";
	
	public static final String CMD_OUTPUT_FILE_SUCESS = "Output file generated";
	
	public static final String SHUTDOWN_LOCATION = "shutdown";
	
	public static final String SLEEP_TIME = "sleeptime";
	
	public static final String INP_KEY_FILE = "keyFileName";
	
	public static final String INP_PARAM_FILE = "paramFile";
		
	public static void main(String[] args) {
		Properties props = null;
		
		String keyfileDir = null, keyfile = null, toolType = null;
		
		ReadSimulator simulator = new ReadSimulator();
		
		boolean runContinuous = true;
		
		long time = 0;
		
		SimLogger.Log(" ***** Started user simulation read /write script **** ");
		
		int cycleNo = 0;
		
		if(checkInputArgs(args)){			
			props = simulator.getProperties();
			
			cycleNo = Integer.valueOf(args[0]);
			
			toolType = args[1];
			
			keyfile = simulator.prepareKeyFile(cycleNo, toolType, props);
			
			/*if(keyfile != null)
				return;*/
			if(props.getProperty(SLEEP_TIME) != null)
				time = Long.valueOf(props.getProperty(SLEEP_TIME));
			SimLogger.Log("Input key file found at " + keyfile);
			try{
				do{
					//force shutdown
					if(simulator.isForceShutdown(props)){
						runContinuous = false;
						SimLogger.Log("Force shutdown");
					}
					
					if(simulator.checkDataExists(props.getProperty(EDWC_PATH), props.getProperty(TEMP_PATH) + keyfile, props.getProperty(TEMP_PATH) + keyfile + "_onlykeys_" + cycleNo + ".txt")){
						SimLogger.Log("Data is available in EDW for the input key");
						simulator.getEDWData(props.getProperty(EDWC_PATH), props.getProperty(TEMP_PATH) + keyfile, props.getProperty(TEMP_PATH) + keyfile + "_data_" + cycleNo + ".csv");
						runContinuous = false;
					}else{
						SimLogger.Log("No data found and so going to sleep for " + time + " milli seconds");
						Thread.sleep(time);
					}
					
				}while(runContinuous);
				SimLogger.Log(" **** Simulation end ****");
			}
			catch(InterruptedException iEx){
				System.err.println(iEx);
			}
		}
	}
	
	/**
	 * This method checks if shutdown file has been placed to forcedly shutdown the scheduler to check for data availability
	 * 
	 */
	public boolean isForceShutdown(Properties props){
		String shutDownLoc = null;
		boolean isShutdown = false;
		File shutDownDir = null;
		File[] listOfFiles = null;
		String fileName = null;
		
		shutDownLoc = SHUTDOWN_LOCATION;
		shutDownDir = new File(shutDownLoc);
		listOfFiles = shutDownDir.listFiles();
		
		if (null != listOfFiles) {
			for (int i = 0; i < listOfFiles.length; i++) {
				fileName = listOfFiles[i].getName();
				if (fileName.equalsIgnoreCase("shutdown")) {
					isShutdown = true;
				}
			}
		}		
		return isShutdown;
	}
	
	public static boolean checkInputArgs(String[] args){
		boolean isValid = false;
		//args - <cycleNo>
		//p r w
		switch(args.length){		
		case 2:	//<toolName>		
			isValid = true;
			break;
		default:
			System.err.println("Usage:\n  ReadSimulator <Cycle no.> <ToolName(READ, PREPROC, NPSS, GPLUS)>\n\n");			
			break;
		}		
		return isValid;
	}
	
	/**
	 * This method can check & load properties file
	 * 
	 */
	public Properties getProperties(){
		File file = new File(PROPTIES_PATH);
		FileInputStream inputst = null;
		Properties props = null;
		
		if(checkFileExists(file)){
			props = new Properties();
			try{
				inputst = new FileInputStream(file);
				props.load(inputst);				
			}
			catch(FileNotFoundException flEx){
				System.err.println(flEx);
			}
			catch(IOException ioEx){
				System.err.println(ioEx);
			}
			finally{
				try{
					if(inputst != null)
						inputst.close();		
				}
				catch(IOException ioEx){
					System.err.println(ioEx);
				}
			}
		}
		return props;
	}
	
	
	/**
	 * This method checks if the given file is present or not.
	 * 
	 * @param file
	 */
	public boolean checkFileExists(File file){
		boolean isExists = false;
		try {
			if (null != file && !file.exists()) 
				System.err.println("Properties file not found. ");
			else
				isExists = true;
		} catch (Exception e) {
			System.err.println(e);
		}
		return isExists;
	}
	
	public boolean checkDataExists(String exePath, String inputKeyfile, String outputPath){
		boolean isDataExists = false;
		StringBuilder strBldCommand = new StringBuilder();
		try{
			SimLogger.Log("Running EDWC to check if data exists in DB");
			strBldCommand.append("edwc.bat -nodata ").append(inputKeyfile).append(" ").append(outputPath);			
			isDataExists = runEDWC(strBldCommand);
		}
		catch(Exception ioEx){
			System.err.println(ioEx);
		}
		return isDataExists;
	}

	public boolean runEDWC(StringBuilder strBldCommand){
		Runtime run = null;
		Process proc = null;
		BufferedReader br = null;
		String line;
		boolean isSuccessful = false;
		try{
			run = Runtime.getRuntime();
			proc = run.exec(strBldCommand.toString());
			SimLogger.Log(strBldCommand.toString());
			proc.waitFor();	
			br = new BufferedReader(new InputStreamReader(proc.getInputStream()));
			while((line = br.readLine()) != null){
				SimLogger.Log(line);
				if(line.startsWith(CMD_OUTPUT_FILE_SUCESS)){					
					isSuccessful = true;
				}
			}	
		}
		catch(IOException ioEx){
			System.err.println(ioEx);
		}
		catch(InterruptedException intEx){
			System.err.println(intEx);
		}
		finally{		
			try{
				if(br != null)
					br.close();
			}
			catch(IOException ioEx){
				System.err.println(ioEx);
			}
			proc.destroy();
			run = null;
		}
		return isSuccessful;
	}
	
	public boolean getEDWData(String exePath, String inputKeyfile, String outputFilePath){
		StringBuilder strBldCommand = new StringBuilder();
		boolean isSuccessful = false;
		SimLogger.Log("Running EDWC to download the data from DB");
		strBldCommand.append("edwc.bat ").append(inputKeyfile).append(" -oCSV ").append(outputFilePath);
		try{
			isSuccessful = runEDWC(strBldCommand);
		}
		catch(Exception ioEx){
			System.err.println(ioEx);
		}
		return isSuccessful;
	}
	
	//Prepare Key file for every cycle no.
	public String prepareKeyFile(int cycleNo, String toolName, Properties props){
		
		String inputKeysDir = props.getProperty(KEY_FILES_DIR), inpKeyFile = props.getProperty(INP_KEY_FILE), inpParamFile = props.getProperty(INP_PARAM_FILE), tmpDir = props.getProperty(TEMP_PATH);
		
		Map<String, String> toolMapMethod = new HashMap<String, String>();
		
		Map<String, String> toolMapDatatype = new HashMap<String, String>();
		
		BufferedReader br = null;
		
		PrintStream outStream = null;// final output key file to be used by the program
		
		//input key file per cycle
		File keyFile = null, paramFile = null;//input parameters file
		
		String flExt = null, finalKeyFile = null, line = null;
		
		boolean isRdg = false, isMethod = false, isDataType = false;
		try{
			
			//Fill method values for each tool
			toolMapMethod.put("PREPROC", "preproc");
			toolMapMethod.put("READ", "testsite");
			toolMapMethod.put("NPSS", "npss");
			toolMapMethod.put("GPLUS", "gplus");
			
			//Fill datatype values for each tool
			toolMapDatatype.put("PREPROC", "ECALC");
			toolMapDatatype.put("READ", "EU");
			toolMapDatatype.put("NPSS", "EU");
			toolMapDatatype.put("GPLUS", "EU");
			
			
			if(inpParamFile != null){
				flExt = inpParamFile.substring(inpParamFile.indexOf('.'), inpParamFile.length()) ;
				inpParamFile = inpParamFile.substring(0, inpParamFile.indexOf('.'));
			}	
	
			inpParamFile = inpParamFile + "_" + String.valueOf(cycleNo) + flExt;
			
			finalKeyFile = getRandomNumber() + "_" + inpKeyFile;		
		
			File logPath = new File(tmpDir, finalKeyFile);
			
			outStream = new PrintStream(new FileOutputStream(logPath, true));
			
			keyFile = new File(inputKeysDir + inpKeyFile);
			
			paramFile = new File(inputKeysDir + inpParamFile);
		
			if(!keyFile.exists() || !paramFile.exists()){
				SimLogger.Log(" key file " + inputKeysDir + inpKeyFile);
				SimLogger.Log(" parameter file " + inputKeysDir + inpParamFile);
				System.err.println("Invalid input key file directory or key file or input parameter file");
			}
			else{
				//read input keyfile
				br = new BufferedReader(new InputStreamReader(new FileInputStream(keyFile)));
				while((line = br.readLine()) != null){
					String[] key = line.split("=");
					if(key != null && key.length > 0){						
						if(key[0].trim().equals("rdg".toLowerCase())){
							line = "RDG = "+cycleNo;
							isRdg = true;
						}
						if(key[0].trim().equals("METHOD".toLowerCase())){
							line = "METHOD = " + toolMapMethod.get(toolName.toUpperCase());
							isMethod = true;
						}
						if(key[0].trim().equals("DATATYPE".toLowerCase())){
							line = "DATATYPE = " + toolMapDatatype.get(toolName.toUpperCase());
							isDataType = true;
						}
					}
					
					outStream.println(line);				
				}
				if(!isRdg)
					outStream.println("RDG = "+cycleNo);
				if(!isMethod)
					outStream.println("METHOD = " + toolMapMethod.get(toolName.toUpperCase()));
				if(!isDataType)
					outStream.println("DATATYPE = " + toolMapDatatype.get(toolName.toUpperCase()));
				
				outStream.println("");
				outStream.println("//Parameters");
				//read params file and merge with key file
				br = new BufferedReader(new InputStreamReader(new FileInputStream(paramFile)));
				while((line = br.readLine()) != null){					
					outStream.println(line);					
				}				
			}
		}
		catch(FileNotFoundException flEx){
			System.err.println("Error occurred in prepareKeyFile : " + flEx);
		}
		catch(IOException ioEx){
			System.err.println("Error occurred in prepareKeyFile : " + ioEx);
		}
		finally{
			try{
				if(br != null)
					br.close();
				if(outStream != null){
					outStream.flush();
					outStream.close();
				}
			}
			catch(IOException ioEx){
				System.err.println("Error occurred in finally of prepareKeyFile : " + ioEx);
			}
		}		
		return finalKeyFile;
	}
	
	public static String getRandomNumber(){
		String rand = null;
		Random rnd = new Random();		
		rand = (new SimpleDateFormat("HHmmss").format((Calendar.getInstance()).getTime())).toString() + rnd.nextLong();
		return rand;
	}
	
}
