package com.geaviation.tdm.usersimulation;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SimLogger {

	private static PrintStream mLogStream = null;
	
	private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyyMMdd");
	
	// Format to print the time in log file
	private static final DateFormat LOG_DATE_FORMAT=new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	
	public static void InitTimeLogger(String filePath)
	{
		try{
			// Get the date details
			Date d = new Date();
			String dateString = DATE_FORMAT.format(new Date());
			
			// create the directory if not exists
			File logPath = new File(filePath);
			
			if(!logPath.exists())
				logPath.mkdirs();
			
			// build the log file name
			File logFile = new File(logPath, dateString+"_simulator.log");
			
			// Open the file in append mode
			mLogStream = new PrintStream(new FileOutputStream(logFile, true));
			
		}
		catch (FileNotFoundException e)
		{
			mLogStream = null;
		}
	}
	
	public static void Log(String message)
	{
			
		StringBuilder write_line = new StringBuilder();
		write_line.append(LOG_DATE_FORMAT.format(new Date())).append(":  ").append(message);
		
		System.out.println(write_line.toString());
		//mLogStream.println(write_line.toString());
		//mLogStream.flush();
	}
}
