package com.geaviation.tdm.usersimulation;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Random;
import java.util.concurrent.TimeoutException;

public class TestMain {
	
	public static void main(String[] args) {
		//System.out.println(getRandomNumber());
		try{
			System.out.println(expandRanges(1,3036));
			//System.out.println(runEDWC(new StringBuilder("edwc.bat -auth")));
		}
		catch(Exception ex){System.err.println(ex);}
	}

	public static String expandRanges (int startVal, int endVal){
		
		StringBuffer expandValBuf = new StringBuffer(startVal+"");
		for(int i=startVal+1; i<=endVal; i++) {
			expandValBuf.append(","+i);
		}
		return expandValBuf.toString();
		
	}

	public static long getRandomNumber(){
		long rand = 0;
		Random rnd = new Random();		
		rand = Long.valueOf((new SimpleDateFormat("HHmmss").format((Calendar.getInstance()).getTime()))) + rnd.nextLong();
		return rand;
	}
	
	public static synchronized int runEDWC(StringBuilder strBldCommand)
	throws InterruptedException, TimeoutException
	{
		Runtime run = null;
		Process proc = null;
		BufferedReader br = null;
		String line;
		
		try{
			run = Runtime.getRuntime();
			proc = run.exec(strBldCommand.toString());	
			Worker work = new Worker(proc);
			work.start();
			try{
				work.join(10000);
				if(work.exit != null)
					return work.exit;
				else{
					work.stopProc();
					work.interrupt();										
					Thread.currentThread().interrupt();
					return 0;

				}
			}catch(InterruptedException intEx){
				work.interrupt();
				Thread.currentThread().interrupt();
				proc.destroy();
				throw intEx;
			}			
		}
		catch(IOException ioEx){
			System.err.println(ioEx);
			return 0;
		}
		
		
			/*       
			br = new BufferedReader(new InputStreamReader(proc.getInputStream()));
			while((line = br.readLine()) != null){	
				System.out.println(line);
			}
			proc.waitFor();	
		
		catch(InterruptedException intEx){
			System.err.println(intEx);
		}
		finally{		
			try{
				if(br != null)
					br.close();
			}
			catch(IOException ioEx){
				System.err.println(ioEx);
			}
			proc.destroy();
			run = null;
		}*/
		
	}
	
	public static int stopEdwc(){
		int exitCode = 0;
		Runtime run = null;
		Process proc = null;
		try{
			run = Runtime.getRuntime();
			proc = run.exec("taskkill /IM tdmdataaccess_1.6.exe /F");
			exitCode = proc.waitFor();
		}
		catch(IOException ioEx){
			System.err.println(ioEx);
		
		}
		catch(InterruptedException intEx){
			System.err.println(intEx);
		
		}
		return exitCode;		
	}
	
	private static class Worker extends Thread{
		
		private Process proc = null;
		Integer exit;
		boolean isExit;
		private Worker(Process proc){
			this.proc = proc; 
		}
		
		public void run(){
			try{
				exit = proc.waitFor();
			}
			catch(InterruptedException intEx){
				return;
			}
		}
		
		public void stopProc()
		{
			stopEdwc();
			if(proc != null){
				proc.destroy();
				proc = null;
			}
		}		
	}
}


