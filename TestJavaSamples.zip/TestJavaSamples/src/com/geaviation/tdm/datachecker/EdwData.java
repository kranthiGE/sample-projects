package com.geaviation.tdm.datachecker;

import java.util.ArrayList;
import java.util.List;

public class EdwData implements EdwKeyState {
	
	private List<EdwObserver> observers = null;
	
	private List<EdwObserver> deleteObservers = null;
	
	public EdwData(){
		observers = new ArrayList<EdwObserver>();
		deleteObservers = new ArrayList<EdwObserver>();
	}
	
	public void addObserver(EdwObserver o){
		observers.add(o);
	}
	
	public void regDeletes(EdwObserver o){
		deleteObservers.add(o);
	}
	
	public void removeObserver(EdwObserver o){
		int index = observers.indexOf(o);
		if(index != -1)			
			observers.remove(index);
	}
	
	public void notifyObservers(){
		for (EdwObserver edwObserver : observers) {
			edwObserver.CheckData();
		}
		for (EdwObserver edwObserver : deleteObservers) {
			removeObserver(edwObserver);
		}
	}
	
	public void setEdwKey(){
		notifyObservers();
	}
	
	public List<EdwObserver> getKeyList(){
		return observers;
	}
}
