package com.geaviation.tdm.datachecker;

public interface EdwObserver {
	
	//Runs EDWC to check if data is available for the given input key file
	void CheckData();
}
