package com.geaviation.tdm.datachecker;

public class EdwDataAvailability implements EdwObserver, EdwDisplay {
	
	private boolean isDataExist = false;
	
	String inputKeyfile = null;
	
	EdwKeyState edwData = null;
	
	public EdwDataAvailability(EdwKeyState edwData, String inputKeyfile){
		this.inputKeyfile = inputKeyfile;
		this.edwData = edwData;
		edwData.addObserver(this);
	}
	
	public void CheckData(){
		EdwLogger.Log("key file : " + inputKeyfile);
		isDataExist = EdwcUtil.checkDataExists(inputKeyfile);
		displayResult();
		isDataExist = false;
	}
	
	public void displayResult(){
		if(isDataExist){
			EdwLogger.Log("Data found for " + inputKeyfile);
			edwData.regDeletes(this);
		}
		else
			EdwLogger.Log("No data found for " + inputKeyfile);
	}

}
