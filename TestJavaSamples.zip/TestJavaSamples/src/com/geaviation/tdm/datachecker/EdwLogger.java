package com.geaviation.tdm.datachecker;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class EdwLogger {

	private static PrintStream mLogStream = null;
	
	// Format to print the time in log file
	private static final DateFormat LOG_DATE_FORMAT=new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	
	private static String UserHome = System.getProperty("user.home");
	
	public static void InitLogger()
	{
		try{
			File edwDataFile = new File(UserHome + File.separator + ".tdm" + File.separator + "edwData.log");
					
			// Open the file in append mode
			mLogStream = new PrintStream(new FileOutputStream(edwDataFile, true));
			
		}
		catch (FileNotFoundException e)
		{
			mLogStream = null;
		}
	}
	
	public static void Log(String message)
	{
			
		StringBuilder write_line = new StringBuilder();
		write_line.append(LOG_DATE_FORMAT.format(new Date())).append(":  ").append(message);
		
		mLogStream.println(write_line.toString());
		mLogStream.flush();
	}
	
	public static void exitLogger(){
		mLogStream.close();
		mLogStream = null;
	}
}
