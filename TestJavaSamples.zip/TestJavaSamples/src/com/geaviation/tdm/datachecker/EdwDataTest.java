package com.geaviation.tdm.datachecker;

import java.io.File;

public class EdwDataTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//start the logger
		EdwLogger.InitLogger();
		if(args == null || args.length <= 0){
			EdwLogger.Log("No input key files directory found");
			EdwLogger.Log("Usage: EdwDataTest <input_keys_dirctory_abolute_path>");
			EdwLogger.exitLogger();
			return;
		}
		//get list of key files and run EdwData to add every key file
		EdwData edw = new EdwData();
		EdwDataAvailability data = null;		
		readKeysDir(args[0], data, edw);
		do{			
			edw.setEdwKey();
			try{
				Thread.sleep(30000);
			}
			catch(InterruptedException iEx){System.err.println(iEx);}
		}while(edw.getKeyList().size() > 0);
		//close the logger
		EdwLogger.exitLogger();
	}
	
	public static void readKeysDir(String keysDir, EdwDataAvailability data, EdwData edw){
		File keyFilesDir = new File(keysDir);
		if(keyFilesDir.isDirectory()){
			File[] keyFiles = keyFilesDir.listFiles();
			for (File file : keyFiles) {
				if(file.isFile())
					data = new EdwDataAvailability(edw, file.getAbsolutePath());
			}
		}
		else
			System.err.println("Invalid key file directory");	
	}
}
