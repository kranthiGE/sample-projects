package com.geaviation.tdm.datachecker;

public interface EdwDisplay {
	//write the result to out stream (console or file)
	void displayResult();
}
