package com.geaviation.tdm.datachecker;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class EdwcUtil {

	public static final String CMD_OUTPUT_FILE_SUCESS = "Output file generated";
	
	public static boolean checkDataExists(String inputKeyfile){
		boolean isDataExist = false;
		StringBuilder strBldCommand = new StringBuilder();
		try{
			strBldCommand.append("edwc.bat -nodata ").append(inputKeyfile).append(" ").append(inputKeyfile + "_nodata_output.csv");			
			isDataExist = runEDWC(strBldCommand);
		}
		catch(Exception ioEx){
			System.err.println(ioEx);
		}
		return isDataExist;
	}

	
	public static boolean runEDWC(StringBuilder strBldCommand){
		Runtime run = null;
		Process proc = null;
		boolean isSuccessful = false;
		try{
			run = Runtime.getRuntime();
			proc = run.exec(strBldCommand.toString());
			Worker work = new Worker(proc);
			work.start();
			try{
				work.join(20000);
				if(work.exit != null)
					isSuccessful = work.isSuccessful;
				else{
					work.stopProc();
					work.interrupt();
					EdwLogger.Log("Unable to run EDWC, please re-authenticate to create cookie");
				}
			}catch(InterruptedException intEx){}			
		}
		catch(IOException ioEx){
			System.err.println(ioEx);
		}		
		finally{		
			proc.destroy();
			run = null;
		}
		return isSuccessful;
	}
	
	private static class Worker extends Thread{
		
		private Process proc = null;
		Integer exit;
		boolean isSuccessful = false;
		BufferedReader br = null;
		String line = null;
		
		private Worker(Process proc){
			this.proc = proc; 
		}
		
		public void run(){
			try{
				if(proc != null){
					exit = proc.waitFor();
					if(proc != null && proc.getInputStream() != null){
						br = new BufferedReader(new InputStreamReader(proc.getInputStream()));
						while((line = br.readLine()) != null){
							if(line.startsWith(CMD_OUTPUT_FILE_SUCESS)){
								isSuccessful = true;
							}
						}
					}
				}
			}
			catch(IOException ioEx){
				System.err.println("Exception in Worker:run() :: " + ioEx);
			}
			catch(InterruptedException intEx){
				return;
			}
		}
		
		public void stopProc()
		{
			stopEdwc();
			if(proc != null){
				proc.destroy();
				proc = null;
			}
		}		
	}
	
	public static int stopEdwc(){
		int exitCode = 0;
		Runtime run = null;
		Process proc = null;
		try{
			run = Runtime.getRuntime();
			proc = run.exec("taskkill /IM tdmdataaccess* /F");
			exitCode = proc.waitFor();
		}
		catch(IOException ioEx){
			System.err.println(ioEx);
		}
		catch(InterruptedException intEx){
			System.err.println(intEx);
		}
		return exitCode;
	}
}
