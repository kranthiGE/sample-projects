package com.geaviation.tdm.datachecker;

public interface EdwKeyState {
	void addObserver(EdwObserver o);
	void removeObserver(EdwObserver o);
	void notifyObservers();
	void regDeletes(EdwObserver o);
}
