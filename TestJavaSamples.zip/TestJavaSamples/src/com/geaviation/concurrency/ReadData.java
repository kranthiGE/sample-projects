package com.geaviation.concurrency;

public class ReadData extends Thread {

	public ReadData(){
		
	}
	
	public void run(){
		for(int i=0; i<10;i++)
	    System.out.println(WriteData.displayData());
	}
	
}
