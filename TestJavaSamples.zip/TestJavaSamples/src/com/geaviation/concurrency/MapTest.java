package com.geaviation.concurrency;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;

public class MapTest {
	static HashMap<String, Integer> data = null;
    
    static TreeMap<String, Integer> mapData = null;
    
    public static void main(String[] args){
          data = new HashMap<String, Integer>();
          data.put("Kranthi", 1234);
          data.put("Kiran", 89879);
          data.put("Pushkraj", 38484);
          data.put("Kiran", 328983);
          
          //System.out.println(data.get("kranthi"));

          mapData = new TreeMap<String, Integer>(String.CASE_INSENSITIVE_ORDER);        
          mapData.putAll(data); 
          
          //System.out.println(mapData.get("kranthi")); 
          
          Iterator it = data.entrySet().iterator();
          while(it.hasNext()){
        	 Entry<String, Integer> pairs = (Map.Entry) it.next();
        	 System.out.println("Key: " + pairs.getKey() + " Value:" + pairs.getValue());        	  
          }          
          
    }     
    
    public static void ListTest(){
    	List<String> link = new LinkedList<String>();
    }

}
