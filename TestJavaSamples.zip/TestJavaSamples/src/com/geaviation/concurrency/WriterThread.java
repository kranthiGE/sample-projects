package com.geaviation.concurrency;

public class WriterThread extends Thread {

	public WriterThread(){
		
	}
	
	public void run(){
		Lock lock = new Lock();
		try{
			for(int i=0; i<10;i++){
				lock.lock();
				WriteData.setData("Hi..."+i);
				//this.sleep(300);
				lock.unlock();
			}
		}
		catch(Exception ex){
			System.err.println(ex);
		}
	}
	
}
