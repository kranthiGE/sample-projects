package com.geaviation.concurrency;

public class RMIConnection {

	private String rmiServer = null;
	
	public RMIConnection(String rmiServer){
		this.rmiServer = rmiServer;
		System.out.println("connection created: + " + rmiServer);
	}
	
	public void waitForSomething(int i){
		try {
			Thread.sleep(i * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
