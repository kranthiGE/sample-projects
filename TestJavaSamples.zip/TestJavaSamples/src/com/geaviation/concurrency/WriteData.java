package com.geaviation.concurrency;

public class WriteData {

	static String strData = "Hi";
	
	public WriteData(){
		
	}
	
	public static void setData(String data){
		
		strData = strData + data;
		//System.out.println(strData);
	}
	
	public static String displayData(){
		
		return strData;
	}
}
