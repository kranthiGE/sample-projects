package com.geaviation.concurrency;

public class TestMain {

	public static void main(String[] args){
		
		WriterThread write = new WriterThread();
		ReadData read = new ReadData();
		
		write.start();
		read.start();
		//System.out.println(WriteData.displayData()) ;
	}
}
