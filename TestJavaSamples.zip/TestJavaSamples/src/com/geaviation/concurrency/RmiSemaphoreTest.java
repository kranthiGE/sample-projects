/**
 * 
 */
package com.geaviation.concurrency;

import java.util.concurrent.Semaphore;

/**
 * @author Kranthi Kiran
 *
 */
public class RmiSemaphoreTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		final Semaphore capacity = new Semaphore(10, false) ;
		int count = 1;
		try {		
			do{
				capacity.acquire(1);
				RMIConnection con = new RMIConnection("V" + count);
				con.waitForSomething(count);
				capacity.release(1);			
				count++;
			}while(count <=15);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
