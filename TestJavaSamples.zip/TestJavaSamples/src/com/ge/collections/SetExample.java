package com.ge.collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;


public class SetExample {

	/**
	 * @param args
	 */
	public static void main(String[] args){
		/*
		 * order, performance, can not remove based on index
		 * EnumSet
		 * HashSet - does not maintain sequence
		 * LinkedHashSet - maintains order in which they are inserted
		 * TreeSet - orders in asc
		 *  
		 */		
		
		//customer1
		CustomerInfo customer1 = new CustomerInfo();
		customer1.setCustomerId(1);
		customer1.setCustomerName("Venu");
		customer1.setVisitDate(new Date());
		
		//customer2
		CustomerInfo customer2 = new CustomerInfo();
		customer2.setCustomerId(2);
		customer2.setCustomerName("Kiran");
		customer2.setVisitDate(new Date());
		
		//customer3
		CustomerInfo customer3 = new CustomerInfo();
		customer3.setCustomerId(3);
		customer3.setCustomerName("sahithi");
		customer3.setVisitDate(new Date());
		
		
		List<CustomerInfo> data = new ArrayList<CustomerInfo>();
		data.add(customer1);
		data.add(customer2);
		data.add(customer3);
		System.out.println(data);
		
		Collections.sort(data);
		for (CustomerInfo customerInfo : data) {
			System.out.println("Sort by name: " + customerInfo.getCustomerName());
		}
		
		
		Map<Integer, CustomerInfo> dataMap = new HashMap<Integer, CustomerInfo>();
		dataMap.put(customer1.getCustomerId(), customer1);
		dataMap.put(customer2.getCustomerId(), customer2);
		
		Set<String> set = new HashSet<String>();
		String val = "cat";
		set.add(val);
		System.out.println(set.contains(val));
		
		List<Integer> intList = new ArrayList<Integer>(Arrays.asList(19,8,1,7,11,2,3,3,4,5,6));
		System.out.println(intList);
		Comparator<CustomerInfo> customerIdComparator = new CustomerIdComparator();
		//Collections.sort(intList, customerIdComparator);
		System.out.println(intList);
		
		//TreeSet
		Set<Integer> treeSet = new TreeSet<Integer>();
		
		int count = 0;
		do{
			count++;
			treeSet.add(count);
		}while(count < 6);
		
		System.out.println("Before adding ");
		for(int number : treeSet){
			System.out.print(number);
		}
		
		treeSet.addAll(Arrays.asList(9,8,10,7,11,6,2,3,3,4,5,6));
		
		System.out.println("After adding ");
		for(int number : treeSet){
			System.out.print(number);
		}
		
		System.out.println("");
		treeSet.removeAll(Arrays.asList(8,7,1,3,8));
		
		System.out.println("After removing ");
		for(int number : treeSet){
			System.out.print(number);
		}
		System.out.println("");
		treeSet.retainAll(Arrays.asList(2,3,4,5,6,7,8));
		
		System.out.println("After retaining ");
		for(int number : treeSet){
			System.out.print(number);
		}
	
	}
	
	public static class CustomerIdComparator implements Comparator<CustomerInfo>
	{
		public int compare(CustomerInfo obj1, CustomerInfo obj2)
		{			
			return ((int)(obj1.getCustomerId() - obj2.getCustomerId()));
		}		
	}
	
}
