package com.ge.collections;

import java.util.Date;

public class CustomerInfo implements Comparable<CustomerInfo> {

	public CustomerInfo(){
		
	}
	
	@Override
	public int compareTo(CustomerInfo o) {
		return customerName.compareTo(o.getCustomerName());
	}	
	
	private int customerId;
	
	private String customerName;
	
	private Date visitDate;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Date getVisitDate() {
		return visitDate;
	}

	public void setVisitDate(Date visitDate) {
		this.visitDate = visitDate;
	}
	
		
	
}
