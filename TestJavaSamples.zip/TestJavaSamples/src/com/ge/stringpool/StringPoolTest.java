package com.ge.stringpool;

public class StringPoolTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String str = "kranthi";
		String str1 = new String("kranthi");
		System.out.println(str.equals(str1));
		
	}

}
