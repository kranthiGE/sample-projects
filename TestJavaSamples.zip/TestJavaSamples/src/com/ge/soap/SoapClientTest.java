/**
 * 
 */
package com.ge.soap;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

/**
 * @author Kranthi Kiran
 *
 */
public class SoapClientTest {

	/**
	 * @param args
	 * @throws Exception 
	 * @throws SOAPException 
	 */
	public static void main(String[] args) throws SOAPException, Exception {

		// Create SOAP Connection
        SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
        SOAPConnection soapConnection = soapConnectionFactory.createConnection();

        // Send SOAP Message to SOAP Server
        String url = "http://pwerld01vn105.pw.ge.com:8025/soa-infra/services/default/TctSendItemToOtmService_WM/tctsendotmbpelprocess_client_ep";
        SOAPMessage soapResponse = soapConnection.call(createSOAPRequest(), url);

        // print SOAP Response
        System.out.print("Response SOAP Message:");
        soapResponse.writeTo(System.out);

        soapConnection.close();
	}

	private static SOAPMessage createSOAPRequest() throws Exception {
        MessageFactory messageFactory = MessageFactory.newInstance();
        SOAPMessage soapMessage = messageFactory.createMessage();
        SOAPPart soapPart = soapMessage.getSOAPPart();

        //String serverURI = "http://pwerld01vn105.pw.ge.com:8025/";

        // SOAP Envelope
        SOAPEnvelope envelope = soapPart.getEnvelope();
        //envelope.addNamespaceDeclaration("", "http://www.gepwtct.org");
        /*
         * Sample XML post
	       <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns="http://www.gepwtct.org">
			   <soapenv:Header/>
			   <soapenv:Body>
			      <PWETPublishSubscribe>
			         <PublishingSystem>TCT</PublishingSystem>
			         <IntegrationID>POC</IntegrationID>
			         <PublishData>
			            <TctItem>
			               <ApplicationType>PGPLM_Part</ApplicationType>
			               <ObjectName>134B292BR</ObjectName>
			               <ObjectDescription>Test 28103</ObjectDescription>
			               <ExportStatus>NLR</ExportStatus>
			               <ECCN>0A018.d.1</ECCN>
			               <Classification>SCOMET LR</Classification>
			               <CountryCode>US</CountryCode>
			            </TctItem>
			            <TctItem>
			               <ApplicationType>PGPLM_Part</ApplicationType>
			               <ObjectName>134B292BR1</ObjectName>
			               <ObjectDescription>Test 28103</ObjectDescription>
			               <ExportStatus>NLR</ExportStatus>
			               <ECCN>0A018.d.1</ECCN>
			               <Classification>SCOMET LR</Classification>
			               <CountryCode>US</CountryCode>
			            </TctItem>
			         </PublishData>
			      </PWETPublishSubscribe>
			   </soapenv:Body>
			</soapenv:Envelope>
         */

        // SOAP Body
        SOAPBody soapBody = envelope.getBody();
        SOAPBodyElement soapBodyElement = soapBody.addBodyElement(envelope.createName("PWETPublishSubscribe"));//creates PWETPublishSubscribe    
        
        SOAPElement soapBodyElemPublish = soapBodyElement.addChildElement("PublishingSystem");//creates node PublishingSystem and adds to prev body element
        soapBodyElemPublish.addTextNode("TCT");
        
        SOAPElement soapBodyElemIntegId = soapBodyElement.addChildElement("IntegrationID");//creates node IntegrationID and adds to prev body element
        soapBodyElemIntegId.addTextNode("POC");
        
        SOAPElement soapBodyElemPubData = soapBodyElement.addChildElement("PublishData");//creates node IntegrationID and adds to prev body element
        SOAPElement SoapEleTctItem = soapBodyElemPubData.addChildElement("TctItem");
        
        SOAPElement soapEleApplicationType =  SoapEleTctItem.addChildElement("ApplicationType");
        soapEleApplicationType.addTextNode("PGPLM_Part");
        
        SOAPElement soapEleObjectName =  SoapEleTctItem.addChildElement("ObjectName");
        soapEleObjectName.addTextNode("134B292BR");
        
        SOAPElement soapEleObjectDescription =  SoapEleTctItem.addChildElement("ObjectDescription");
        soapEleObjectDescription.addTextNode("Test 28103");
        
        SOAPElement soapEleExportStatus =  SoapEleTctItem.addChildElement("ExportStatus");
        soapEleExportStatus.addTextNode("NLR");
        
        SOAPElement soapECCN =  SoapEleTctItem.addChildElement("ECCN");
        soapECCN.addTextNode("0A018.d.1");
        
        SOAPElement soapClassification =  SoapEleTctItem.addChildElement("Classification");
        soapClassification.addTextNode("SCOMET LR");
        
        SOAPElement soapCountryCode =  SoapEleTctItem.addChildElement("CountryCode");
        soapCountryCode.addTextNode("US");
        
        MimeHeaders headers = soapMessage.getMimeHeaders();
        headers.addHeader("soapAction", "http://www.gepwtct.org"  + "process");
        
        
        soapMessage.saveChanges();

        
        /* Print the request message */
        System.out.print("Request SOAP Message:");
        soapMessage.writeTo(System.out);
        System.out.println();

        return soapMessage;
    }
}
