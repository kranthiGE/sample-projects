package com.ge.threadsafe;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import sun.management.Sensor;

public class ProcessingThread implements Runnable {
	private int count = 0; 
	
	private Object lock = new Object();
	
	private static Map<Integer, String> mapData = new HashMap<Integer, String>();
	
	Sesnsor sesnor = null;
	
	@Override
	public void run(){
		runTask();
		sesnor.readSesnsorData();
	}
	
	public void runTask(){
			for(int i = 1; i < 100; i++){
				//waitForSomething(i);
				//count++;
				synchronized (mapData){
					count++;
					mapData.put(count, "Bangalore");
					mapData.put(count, "Hyderabad");
					mapData.put(count, "Chennai");
					mapData.put(count, "Pune");
					mapData.put(count, "Mumbai");
				
					
				}
			}
	}
	
	public int getCount(){
		return count;
	}
	
	public Map<Integer, String> getMapData(){
		Map<Integer, String> tempMap = null;
		synchronized (mapData){
			tempMap = new LinkedHashMap<Integer, String>(mapData);
		}
		return 	tempMap;
	}
	
	private void waitForSomething(int i){
		try {
			Thread.sleep(i * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
