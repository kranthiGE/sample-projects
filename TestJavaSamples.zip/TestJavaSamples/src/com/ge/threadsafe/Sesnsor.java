package com.ge.threadsafe;

public interface Sesnsor {

	void readSesnsorData();
}
