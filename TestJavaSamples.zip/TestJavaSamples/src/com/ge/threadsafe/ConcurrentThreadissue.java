package com.ge.threadsafe;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ConcurrentThreadissue {

	private static Map<String, List<String>> parentFoldersChildCount = new HashMap<String, List<String>>();
	
	public static void main(String args){
		ConcurrentThreadissue obj = new ConcurrentThreadissue();
		
		obj.readWriteHashMapTest();
	}
	
	
	public void readWriteHashMapTest(){
		
		Map<String, List<String>> foldersSubFoldersMap = null;
		
		foldersSubFoldersMap = new LinkedHashMap<String, List<String>>(parentFoldersChildCount);
	}
	
	public void writeData(){
		List<String> folders = null;
		
		folders = new ArrayList<String>();
		folders.add("1001");
		folders.add("1002");
		folders.add("1003");
		folders.add("1004");
		parentFoldersChildCount.put("1",folders);
		
		folders = new ArrayList<String>();
		folders.add("2001");
		folders.add("2002");
		folders.add("2003");
		folders.add("2004");
		parentFoldersChildCount.put("2",folders);
		
	}
}
