package com.ge.threadsafe;

public class SafeProcessingThread {

	ProcessingThread proc;
	
	public SafeProcessingThread(){
		proc = new ProcessingThread();
	}
	
	public synchronized void runTask(){
		proc.runTask();
	}
	
	public synchronized int getCount(){
		return proc.getCount();
	}
}
