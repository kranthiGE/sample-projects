package com.ge.threadsafe;



public class ThreadMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int repeat = 0;
		do{
			repeat++;
			ProcessingThread proc = new ProcessingThread();
			Thread t1 = new Thread(proc, "t1");
			Thread t2 = new Thread(proc, "t2");
			Thread t3 = new Thread(proc, "t3");
			Thread t4 = new Thread(proc, "t4");
			Thread t5 = new Thread(proc, "t5");
			Thread t6 = new Thread(proc, "t6");
			Thread t7 = new Thread(proc, "t7");
			Thread t8 = new Thread(proc, "t8");
			Thread t9 = new Thread(proc, "t9");
			Thread t10 = new Thread(proc, "t10");
			
			
			t1.start();
			t2.start();
			t3.start();
			t4.start();
			System.out.println(proc.getMapData());
			t5.start();
			t6.start();
			t7.start();
			System.out.println(proc.getMapData());
			t8.start();
			t9.start();
			t10.start();
			System.out.println(proc.getMapData());
			try {
				t1.join();
				t2.join();
				t3.join();
				t4.join();
				t5.join();
				t6.join();
				t7.join();
				t8.join();
				t9.join();
				t10.join();
				
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			System.out.println(proc.getCount());
			System.out.println(proc.getMapData());
			
		}while(repeat < 15);

	}
}